import React from 'react';
import useUIStore from '../../store/uiStore';

const ICONS = { success: '✓', error: '✕', warning: '⚠', default: 'ℹ' };

export default function Toast({ toast }) {
  const { removeToast } = useUIStore();
  return (
    <div className={`toast ${toast.type}`} onClick={() => removeToast(toast.id)} style={{ cursor: 'pointer' }}>
      <span>{ICONS[toast.type] || ICONS.default}</span>
      <span style={{ flex: 1 }}>{toast.message}</span>
      <span style={{ opacity: 0.6, fontSize: '0.75rem' }}>✕</span>
    </div>
  );
}
