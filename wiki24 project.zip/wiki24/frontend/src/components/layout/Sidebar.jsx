import React, { useState } from 'react';
import { NavLink, useNavigate, useLocation } from 'react-router-dom';
import useAuthStore from '../../store/authStore';
import useUIStore from '../../store/uiStore';

const NAV = [
  {
    id: 'sales', label: 'Продажи', icon: '🛒',
    children: [
      { label: 'Касса', path: '/sales/pos' },
      { label: 'Все продажи', path: '/sales/list' },
      { label: 'Кассовые операции', path: '/sales/operations' },
      { label: 'Кассовые смены', path: '/sales/shifts' },
    ],
  },
  {
    id: 'warehouse', label: 'Склад', icon: '📦',
    children: [
      { label: 'Каталог товаров', path: '/warehouse/products' },
      { label: 'Закупки', path: '/warehouse/purchases' },
      { label: 'Инвентаризация', path: '/warehouse/inventories' },
      { label: 'Перемещения', path: '/warehouse/transfers' },
      { label: 'Переоценка', path: '/warehouse/repricings' },
      { label: 'Списание', path: '/warehouse/writeoffs' },
      { label: 'Поставщики', path: '/warehouse/suppliers' },
    ],
  },
  {
    id: 'customers', label: 'Покупатели', icon: '👥',
    children: [
      { label: 'Все клиенты', path: '/customers/list' },
      { label: 'Группы и теги', path: '/customers/groups' },
      { label: 'Программа лояльности', path: '/customers/loyalty' },
      { label: 'Долги клиентов', path: '/customers/debts' },
    ],
  },
  {
    id: 'management', label: 'Управление', icon: '🛡️',
    children: [
      { label: 'Персонал', path: '/management/employees' },
      { label: 'Права доступа', path: '/management/roles' },
    ],
  },
  {
    id: 'settings', label: 'Настройки', icon: '⚙️',
    children: [
      { label: 'Профиль', path: '/settings/profile' },
      { label: 'Общие настройки', path: '/settings/general' },
      { label: 'Подписка и оплата', path: '/settings/subscription' },
      { label: 'Касса и продажи', path: '/settings/cash' },
      { label: 'Справочники', path: '/settings/directories' },
      { label: 'Уведомления', path: '/settings/notifications' },
      { label: 'Интеграции', path: '/settings/integrations' },
    ],
  },
];

export default function Sidebar() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuthStore();
  const { sidebarOpen } = useUIStore();

  const getActiveSection = () => {
    const path = location.pathname;
    for (const item of NAV) {
      if (item.children.some(c => path.startsWith(c.path))) return item.id;
    }
    return null;
  };

  const [openSection, setOpenSection] = useState(getActiveSection() || 'sales');

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const getInitials = () => {
    if (!user) return 'U';
    return (user.first_name?.[0] || '') + (user.last_name?.[0] || '');
  };

  if (!sidebarOpen) return null;

  return (
    <aside style={{
      position: 'fixed', top: 0, left: 0, bottom: 0,
      width: 'var(--sidebar-width)',
      background: '#fff',
      borderRight: '1px solid var(--gray-200)',
      display: 'flex', flexDirection: 'column',
      zIndex: 100,
      overflowY: 'auto',
    }}>
      {/* Logo */}
      <div style={{ padding: '16px 16px 12px', borderBottom: '1px solid var(--gray-100)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{
            width: 32, height: 32, borderRadius: 8,
            background: 'var(--orange)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: '#fff', fontWeight: 700, fontSize: '1rem'
          }}>W</div>
          <span style={{ fontWeight: 700, fontSize: '1rem', color: 'var(--gray-900)' }}>WIKI</span>
        </div>
      </div>

      {/* Nav */}
      <nav style={{ flex: 1, padding: '8px 0' }}>
        {NAV.map((section) => {
          const isOpen = openSection === section.id;
          const isActive = section.children.some(c => location.pathname.startsWith(c.path));

          return (
            <div key={section.id}>
              <button
                onClick={() => setOpenSection(isOpen ? null : section.id)}
                style={{
                  display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                  width: '100%', padding: '9px 16px',
                  background: 'none', border: 'none', cursor: 'pointer',
                  fontSize: '0.875rem', fontWeight: 600,
                  color: isActive ? 'var(--orange)' : 'var(--gray-700)',
                  transition: 'color var(--transition)',
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <div style={{
                    width: 28, height: 28,
                    background: isActive ? 'var(--orange)' : 'var(--gray-100)',
                    borderRadius: 7,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: '0.875rem',
                  }}>
                    {section.icon}
                  </div>
                  {section.label}
                </div>
                <span style={{ fontSize: '0.7rem', color: 'var(--gray-400)', transform: isOpen ? 'rotate(180deg)' : '', transition: 'transform 0.2s' }}>▼</span>
              </button>

              {isOpen && (
                <div style={{ paddingLeft: 44 }}>
                  {section.children.map((child) => (
                    <NavLink
                      key={child.path}
                      to={child.path}
                      style={({ isActive }) => ({
                        display: 'block',
                        padding: '7px 12px',
                        fontSize: '0.8125rem',
                        color: isActive ? 'var(--orange)' : 'var(--gray-600)',
                        fontWeight: isActive ? 600 : 400,
                        textDecoration: 'none',
                        borderRadius: 6,
                        margin: '1px 8px 1px 0',
                        background: isActive ? 'var(--orange-light)' : 'transparent',
                        transition: 'all var(--transition)',
                      })}
                    >
                      {child.label}
                    </NavLink>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </nav>

      {/* User */}
      <div style={{ padding: 12, borderTop: '1px solid var(--gray-100)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{
            width: 32, height: 32, borderRadius: '50%',
            background: 'var(--orange)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: '#fff', fontSize: '0.8rem', fontWeight: 700,
            flexShrink: 0,
          }}>
            {getInitials()}
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: '0.8rem', fontWeight: 600, color: 'var(--gray-800)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {user?.first_name} {user?.last_name}
            </div>
            <div style={{ fontSize: '0.7rem', color: 'var(--gray-400)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {user?.email}
            </div>
          </div>
          <button onClick={handleLogout} title="Выйти" style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--gray-400)', fontSize: '1rem', padding: '4px' }}>
            ⎋
          </button>
        </div>
      </div>
    </aside>
  );
}
