import React from 'react';
import { useLocation, Link } from 'react-router-dom';
import useAuthStore from '../../store/authStore';

const ROUTE_LABELS = {
  '/sales/pos': ['Продажи', 'Касса'],
  '/sales/list': ['Продажи', 'Все продажи'],
  '/sales/shifts': ['Продажи', 'Кассовые смены'],
  '/sales/operations': ['Продажи', 'Кассовые операции'],
  '/warehouse/products': ['Склад', 'Каталог товаров'],
  '/warehouse/purchases': ['Склад', 'Закупки'],
  '/warehouse/inventories': ['Склад', 'Инвентаризация'],
  '/warehouse/transfers': ['Склад', 'Перемещения'],
  '/warehouse/repricings': ['Склад', 'Переоценка'],
  '/warehouse/writeoffs': ['Склад', 'Списание'],
  '/warehouse/suppliers': ['Склад', 'Поставщики'],
  '/customers/list': ['Покупатели', 'Все клиенты'],
  '/customers/groups': ['Покупатели', 'Группы и теги'],
  '/customers/loyalty': ['Покупатели', 'Программа лояльности'],
  '/customers/debts': ['Покупатели', 'Долги клиентов'],
  '/management/employees': ['Управление', 'Персонал'],
  '/management/roles': ['Управление', 'Роли'],
  '/settings/profile': ['Настройки', 'Профиль'],
  '/settings/general': ['Настройки', 'Общие настройки'],
  '/settings/cash': ['Настройки', 'Касса и продажи'],
  '/settings/directories': ['Настройки', 'Справочники'],
  '/settings/subscription': ['Настройки', 'Подписка'],
  '/settings/notifications': ['Настройки', 'Уведомления'],
  '/settings/integrations': ['Настройки', 'Интеграции'],
};

export default function Header() {
  const location = useLocation();
  const { user } = useAuthStore();

  const labels = ROUTE_LABELS[location.pathname] || ['Главная'];

  return (
    <header style={{
      height: 'var(--header-height)',
      background: '#fff',
      borderBottom: '1px solid var(--gray-200)',
      display: 'flex', alignItems: 'center',
      padding: '0 24px',
      gap: 8,
      position: 'sticky', top: 0, zIndex: 50,
    }}>
      {/* Breadcrumb */}
      <nav className="breadcrumb" style={{ flex: 1 }}>
        <Link to="/" className="breadcrumb__item">Главная</Link>
        <span className="breadcrumb__sep">›</span>
        {labels.length > 1 ? (
          <>
            <span className="breadcrumb__item">{labels[0]}</span>
            <span className="breadcrumb__sep">›</span>
            <span className="breadcrumb__current">{labels[1]}</span>
          </>
        ) : (
          <span className="breadcrumb__current">{labels[0]}</span>
        )}
      </nav>

      {/* Right side */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{ fontSize: '0.8rem', color: 'var(--gray-500)' }}>
          {user?.company_name}
        </div>
      </div>
    </header>
  );
}
