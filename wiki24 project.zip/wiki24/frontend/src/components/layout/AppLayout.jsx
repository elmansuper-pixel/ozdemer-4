import React from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import Sidebar from './Sidebar';
import Header from './Header';

export default function AppLayout() {
  const location = useLocation();
  const isPOS = location.pathname === '/sales/pos';

  if (isPOS) {
    return (
      <div className="app-layout">
        <Sidebar />
        <main className="main-content" style={{ background: '#F3F4F6' }}>
          <Outlet />
        </main>
      </div>
    );
  }

  return (
    <div className="app-layout">
      <Sidebar />
      <main className="main-content">
        <Header />
        <div className="page-container">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
