import React, { useState, useEffect } from 'react';
import api, { formatKZT, formatDateTime, formatError } from '../../api/axios';
import useUIStore from '../../store/uiStore';

export default function SalesListPage() {
  const { toast } = useUIStore();
  const [data, setData] = useState([]);
  const [stats, setStats] = useState({});
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [filters, setFilters] = useState({
    search: '', date_from: '', date_to: '',
    type: '', store_id: '',
  });
  const [stores, setStores] = useState([]);
  const LIMIT = 20;

  useEffect(() => { api.get('/stores').then(r => setStores(r.data.data || [])).catch(() => {}); }, []);
  useEffect(() => { load(); }, [page, filters]);

  const load = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page, limit: LIMIT, ...filters });
      const res = await api.get(`/sales?${params}`);
      setData(res.data.data || []);
      setTotal(res.data.pagination?.total || 0);
      setStats(res.data.stats || {});
    } catch (e) { toast(formatError(e), 'error'); }
    finally { setLoading(false); }
  };

  const statusBadge = (type) => {
    if (type === 'refund') return <span className="badge badge-red">Возврат</span>;
    return <span className="badge badge-green">Продажа</span>;
  };

  return (
    <div>
      <div className="page-header">
        <div className="page-header__title">
          <h1>Все продажи</h1>
          <p>История транзакций</p>
        </div>
      </div>

      {/* Stats */}
      <div className="stat-cards" style={{ marginBottom: 20 }}>
        {[
          { label: 'Транзакций', value: stats.transactions || 0 },
          { label: 'Выручка', value: formatKZT(stats.total_amount || 0) },
          { label: 'Возвраты', value: formatKZT(stats.refund_amount || 0) },
          { label: 'Наличными', value: formatKZT(stats.cash_amount || 0) },
        ].map(s => (
          <div key={s.label} className="stat-card">
            <div className="stat-card__label">{s.label}</div>
            <div className="stat-card__value">{s.value}</div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="card" style={{ marginBottom: 16 }}>
        <div className="filters-row">
          <div className="search-bar" style={{ flex: 1, minWidth: 200 }}>
            <span className="search-bar__icon">🔍</span>
            <input
              className="form-control"
              placeholder="Номер транзакции..."
              value={filters.search}
              onChange={e => setFilters(p => ({ ...p, search: e.target.value }))}
              style={{ paddingLeft: 34 }}
            />
          </div>
          <input type="date" className="form-control" style={{ width: 150 }}
            value={filters.date_from} onChange={e => setFilters(p => ({ ...p, date_from: e.target.value }))} />
          <input type="date" className="form-control" style={{ width: 150 }}
            value={filters.date_to} onChange={e => setFilters(p => ({ ...p, date_to: e.target.value }))} />
          <select className="form-control" style={{ width: 130 }}
            value={filters.type} onChange={e => setFilters(p => ({ ...p, type: e.target.value }))}>
            <option value="">Все типы</option>
            <option value="sale">Продажи</option>
            <option value="refund">Возвраты</option>
          </select>
          <select className="form-control" style={{ width: 160 }}
            value={filters.store_id} onChange={e => setFilters(p => ({ ...p, store_id: e.target.value }))}>
            <option value="">Все магазины</option>
            {stores.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
          <button className="btn btn-secondary" onClick={() => { setFilters({ search: '', date_from: '', date_to: '', type: '', store_id: '' }); setPage(1); }}>
            Сбросить
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="card">
        {loading ? (
          <div className="loading-center"><div className="spinner spinner-lg" /></div>
        ) : data.length === 0 ? (
          <div className="empty-state">
            <div className="empty-state__icon">🧾</div>
            <h3>Продаж нет</h3>
          </div>
        ) : (
          <div className="table-container">
            <table className="table">
              <thead>
                <tr>
                  <th>№ Транзакции</th>
                  <th>Дата</th>
                  <th>Магазин</th>
                  <th>Тип</th>
                  <th>Позиций</th>
                  <th>Способ оплаты</th>
                  <th>Клиент</th>
                  <th style={{ textAlign: 'right' }}>Сумма</th>
                </tr>
              </thead>
              <tbody>
                {data.map(s => (
                  <tr key={s.id}>
                    <td><span className="link-cell">{s.transaction_no}</span></td>
                    <td style={{ fontSize: '0.8rem', color: 'var(--gray-500)' }}>{formatDateTime(s.created_at)}</td>
                    <td>{s.store_name}</td>
                    <td>{statusBadge(s.type)}</td>
                    <td>{s.items_count || 0}</td>
                    <td><span className="badge badge-gray">{s.payment_method}</span></td>
                    <td style={{ color: 'var(--gray-500)' }}>{s.customer_name?.trim() || '—'}</td>
                    <td style={{ textAlign: 'right', fontWeight: 600, color: s.type === 'refund' ? 'var(--red)' : 'var(--gray-900)' }}>
                      {s.type === 'refund' ? '−' : ''}{formatKZT(s.total)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination */}
        {total > LIMIT && (
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 0 0', borderTop: '1px solid var(--gray-100)' }}>
            <span style={{ fontSize: '0.8rem', color: 'var(--gray-500)' }}>Всего: {total}</span>
            <div className="pagination">
              <button className="pagination__btn" disabled={page === 1} onClick={() => setPage(p => p - 1)}>‹</button>
              <button className="pagination__btn active">{page}</button>
              <button className="pagination__btn" disabled={page * LIMIT >= total} onClick={() => setPage(p => p + 1)}>›</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
