import React, { useState, useEffect } from 'react';
import api, { formatKZT, formatDateTime, formatError } from '../../api/axios';
import useUIStore from '../../store/uiStore';

export default function CashOperationsPage() {
  const { toast } = useUIStore();
  const [data, setData] = useState([]);
  const [stats, setStats] = useState({});
  const [loading, setLoading] = useState(false);
  const [modal, setModal] = useState(false);
  const [stores, setStores] = useState([]);
  const [form, setForm] = useState({ store_id: '', type: 'income', amount: '', category: '', comment: '' });

  useEffect(() => {
    load();
    api.get('/stores').then(r => { setStores(r.data.data || []); if (r.data.data?.[0]) setForm(p => ({ ...p, store_id: r.data.data[0].id })); }).catch(() => {});
  }, []);

  const load = async () => {
    setLoading(true);
    try {
      const res = await api.get('/cash-operations');
      setData(res.data.data || []);
      setStats(res.data.stats || {});
    } catch (e) { toast(formatError(e), 'error'); }
    finally { setLoading(false); }
  };

  const handleCreate = async () => {
    try {
      await api.post('/cash-operations', { ...form, amount: parseFloat(form.amount) });
      toast('Операция добавлена', 'success');
      setModal(false);
      setForm(p => ({ ...p, amount: '', category: '', comment: '' }));
      load();
    } catch (e) { toast(formatError(e), 'error'); }
  };

  return (
    <div>
      <div className="page-header">
        <div className="page-header__title"><h1>Кассовые операции</h1><p>Внесения и изъятия наличных</p></div>
        <div className="page-header__actions">
          <button className="btn btn-primary" onClick={() => setModal(true)}>+ Добавить операцию</button>
        </div>
      </div>

      <div className="stat-cards">
        <div className="stat-card"><div className="stat-card__label">Внесено</div><div className="stat-card__value amount-positive">{formatKZT(stats.total_income || 0)}</div></div>
        <div className="stat-card"><div className="stat-card__label">Изъято</div><div className="stat-card__value amount-negative">{formatKZT(stats.total_expense || 0)}</div></div>
      </div>

      <div className="card">
        {loading ? <div className="loading-center"><div className="spinner spinner-lg" /></div> : data.length === 0 ? (
          <div className="empty-state"><div className="empty-state__icon">💰</div><h3>Операций нет</h3></div>
        ) : (
          <div className="table-container">
            <table className="table">
              <thead><tr><th>Дата</th><th>Тип</th><th>Магазин</th><th>Категория</th><th>Комментарий</th><th>Пользователь</th><th style={{ textAlign: 'right' }}>Сумма</th></tr></thead>
              <tbody>
                {data.map(op => (
                  <tr key={op.id}>
                    <td style={{ fontSize: '0.8rem' }}>{formatDateTime(op.created_at)}</td>
                    <td>{op.type === 'income' ? <span className="badge badge-green">Внесение</span> : <span className="badge badge-red">Изъятие</span>}</td>
                    <td>{op.store_name}</td>
                    <td>{op.category || '—'}</td>
                    <td style={{ color: 'var(--gray-500)' }}>{op.comment || '—'}</td>
                    <td>{op.user_name}</td>
                    <td style={{ textAlign: 'right', fontWeight: 600, color: op.type === 'income' ? 'var(--green)' : 'var(--red)' }}>
                      {op.type === 'income' ? '+' : '−'}{formatKZT(op.amount)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {modal && (
        <div className="modal-overlay" onClick={() => setModal(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-header"><h3>Новая операция</h3><button className="btn btn-ghost btn-icon" onClick={() => setModal(false)}>✕</button></div>
            <div className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div className="form-group">
                <label className="form-label">Магазин</label>
                <select className="form-control" value={form.store_id} onChange={e => setForm(p => ({ ...p, store_id: e.target.value }))}>
                  {stores.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Тип</label>
                <select className="form-control" value={form.type} onChange={e => setForm(p => ({ ...p, type: e.target.value }))}>
                  <option value="income">Внесение</option>
                  <option value="expense">Изъятие</option>
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Сумма (₸)</label>
                <input className="form-control" type="number" value={form.amount} onChange={e => setForm(p => ({ ...p, amount: e.target.value }))} placeholder="0" />
              </div>
              <div className="form-group">
                <label className="form-label">Категория</label>
                <input className="form-control" value={form.category} onChange={e => setForm(p => ({ ...p, category: e.target.value }))} placeholder="Аренда, инкассация..." />
              </div>
              <div className="form-group">
                <label className="form-label">Комментарий</label>
                <textarea className="form-control" value={form.comment} onChange={e => setForm(p => ({ ...p, comment: e.target.value }))} style={{ minHeight: 60 }} />
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={() => setModal(false)}>Отмена</button>
              <button className="btn btn-primary" onClick={handleCreate} disabled={!form.amount}>Сохранить</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
