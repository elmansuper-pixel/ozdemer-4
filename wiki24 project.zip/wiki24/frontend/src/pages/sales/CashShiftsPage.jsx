import React, { useState, useEffect } from 'react';
import api, { formatKZT, formatDateTime, formatError } from '../../api/axios';
import useUIStore from '../../store/uiStore';

export function CashShiftsPage() {
  const { toast } = useUIStore();
  const [data, setData] = useState([]);
  const [stats, setStats] = useState({});
  const [loading, setLoading] = useState(false);
  const [openModal, setOpenModal] = useState(false);
  const [closeModal, setCloseModal] = useState(null);
  const [stores, setStores] = useState([]);
  const [openForm, setOpenForm] = useState({ store_id: '', opening_amount: '0' });
  const [closeAmt, setCloseAmt] = useState('');

  useEffect(() => {
    load();
    api.get('/stores').then(r => setStores(r.data.data || [])).catch(() => {});
  }, []);

  const load = async () => {
    setLoading(true);
    try {
      const res = await api.get('/shifts?limit=50');
      setData(res.data.data || []);
      setStats(res.data.stats || {});
    } catch (e) { toast(formatError(e), 'error'); }
    finally { setLoading(false); }
  };

  const handleOpen = async () => {
    try {
      await api.post('/shifts', { store_id: parseInt(openForm.store_id), opening_amount: parseFloat(openForm.opening_amount) || 0 });
      toast('Смена открыта', 'success');
      setOpenModal(false);
      load();
    } catch (e) { toast(formatError(e), 'error'); }
  };

  const handleClose = async () => {
    try {
      await api.put(`/shifts/${closeModal.id}/close`, { closing_amount: parseFloat(closeAmt) || 0 });
      toast('Смена закрыта', 'success');
      setCloseModal(null);
      setCloseAmt('');
      load();
    } catch (e) { toast(formatError(e), 'error'); }
  };

  const shiftStatus = (s) => {
    if (s.status === 'open') return <span className="badge badge-green">Открыта</span>;
    return <span className="badge badge-gray">Закрыта</span>;
  };

  return (
    <div>
      <div className="page-header">
        <div className="page-header__title"><h1>Кассовые смены</h1></div>
        <div className="page-header__actions">
          <button className="btn btn-primary" onClick={() => setOpenModal(true)}>+ Открыть смену</button>
        </div>
      </div>

      <div className="stat-cards">
        <div className="stat-card"><div className="stat-card__label">Наличных в кассе</div><div className="stat-card__value">{formatKZT(stats.cash_in_register || 0)}</div></div>
        <div className="stat-card"><div className="stat-card__label">Открытые смены</div><div className="stat-card__value">{data.filter(d => d.status === 'open').length}</div></div>
      </div>

      <div className="card">
        {loading ? <div className="loading-center"><div className="spinner spinner-lg" /></div> : (
          <div className="table-container">
            <table className="table">
              <thead><tr><th>Смена</th><th>Магазин</th><th>Кассир</th><th>Открыта</th><th>Закрыта</th><th>Выручка</th><th>Начальная</th><th>Итог</th><th>Статус</th><th></th></tr></thead>
              <tbody>
                {data.map(s => (
                  <tr key={s.id}>
                    <td><span className="link-cell">{s.shift_number}</span></td>
                    <td>{s.store_name}</td>
                    <td>{s.cashier_name}</td>
                    <td style={{ fontSize: '0.8rem' }}>{formatDateTime(s.opened_at)}</td>
                    <td style={{ fontSize: '0.8rem' }}>{s.closed_at ? formatDateTime(s.closed_at) : '—'}</td>
                    <td style={{ fontWeight: 500 }}>{formatKZT(s.revenue || 0)}</td>
                    <td>{formatKZT(s.opening_amount || 0)}</td>
                    <td>{s.closing_amount != null ? formatKZT(s.closing_amount) : '—'}</td>
                    <td>{shiftStatus(s)}</td>
                    <td>
                      {s.status === 'open' && (
                        <button className="btn btn-sm btn-secondary" onClick={() => { setCloseModal(s); setCloseAmt(''); }}>Закрыть</button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {openModal && (
        <div className="modal-overlay" onClick={() => setOpenModal(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-header"><h3>Открыть смену</h3><button className="btn btn-ghost btn-icon" onClick={() => setOpenModal(false)}>✕</button></div>
            <div className="modal-body">
              <div className="form-group" style={{ marginBottom: 14 }}>
                <label className="form-label">Магазин</label>
                <select className="form-control" value={openForm.store_id} onChange={e => setOpenForm(p => ({ ...p, store_id: e.target.value }))}>
                  <option value="">Выберите магазин</option>
                  {stores.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Начальная сумма (₸)</label>
                <input className="form-control" type="number" value={openForm.opening_amount} onChange={e => setOpenForm(p => ({ ...p, opening_amount: e.target.value }))} />
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={() => setOpenModal(false)}>Отмена</button>
              <button className="btn btn-primary" onClick={handleOpen} disabled={!openForm.store_id}>Открыть смену</button>
            </div>
          </div>
        </div>
      )}

      {closeModal && (
        <div className="modal-overlay" onClick={() => setCloseModal(null)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-header"><h3>Закрыть смену</h3><button className="btn btn-ghost btn-icon" onClick={() => setCloseModal(null)}>✕</button></div>
            <div className="modal-body">
              <p style={{ marginBottom: 12 }}>Выручка за смену: <strong>{formatKZT(closeModal.revenue || 0)}</strong></p>
              <div className="form-group">
                <label className="form-label">Фактическая сумма в кассе (₸)</label>
                <input className="form-control" type="number" value={closeAmt} onChange={e => setCloseAmt(e.target.value)} placeholder="0" />
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={() => setCloseModal(null)}>Отмена</button>
              <button className="btn btn-danger" onClick={handleClose}>Закрыть смену</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default CashShiftsPage;
