import React, { useState, useEffect, useRef, useCallback } from 'react';
import api, { formatKZT, formatError } from '../../api/axios';
import useAuthStore from '../../store/authStore';
import useUIStore from '../../store/uiStore';

export default function POSPage() {
  const { user } = useAuthStore();
  const { toast } = useUIStore();

  const [products, setProducts] = useState([]);
  const [searchQ, setSearchQ] = useState('');
  const [cart, setCart] = useState([]);
  const [customer, setCustomer] = useState(null);
  const [customerSearch, setCustomerSearch] = useState('');
  const [customerResults, setCustomerResults] = useState([]);
  const [discount, setDiscount] = useState({ type: 'percent', value: '' });
  const [paymentMethod, setPaymentMethod] = useState('Наличные');
  const [paymentMethods, setPaymentMethods] = useState([]);
  const [stores, setStores] = useState([]);
  const [selectedStore, setSelectedStore] = useState(null);
  const [currentShift, setCurrentShift] = useState(null);
  const [note, setNote] = useState('');
  const [processing, setSaving] = useState(false);
  const [showSuccess, setShowSuccess] = useState(null);
  const [catalogSettings, setCatalogSettings] = useState(null);
  const searchRef = useRef(null);

  useEffect(() => {
    loadInitial();
    if (searchRef.current) searchRef.current.focus();
  }, []);

  const loadInitial = async () => {
    try {
      const [storeRes, pmRes, csRes] = await Promise.all([
        api.get('/stores'),
        api.get('/payment-methods'),
        api.get('/settings/catalog'),
      ]);
      const storeList = storeRes.data.data || [];
      setStores(storeList);
      if (storeList.length > 0) {
        setSelectedStore(storeList[0]);
        loadShift(storeList[0].id);
      }
      setPaymentMethods(pmRes.data.data || []);
      if (pmRes.data.data?.length > 0) setPaymentMethod(pmRes.data.data[0].name);
      setCatalogSettings(csRes.data);
    } catch {}
  };

  const loadShift = async (storeId) => {
    try {
      const res = await api.get(`/shifts/current?store_id=${storeId}`);
      setCurrentShift(res.data);
    } catch {}
  };

  // Debounced product search
  useEffect(() => {
    if (!searchQ) { setProducts([]); return; }
    const timer = setTimeout(async () => {
      try {
        const storeParam = selectedStore ? `&store_id=${selectedStore.id}` : '';
        const res = await api.get(`/products/search?q=${encodeURIComponent(searchQ)}${storeParam}`);
        setProducts(res.data.data || []);
      } catch {}
    }, 250);
    return () => clearTimeout(timer);
  }, [searchQ, selectedStore]);

  // Customer search
  useEffect(() => {
    if (customerSearch.length < 2) { setCustomerResults([]); return; }
    const timer = setTimeout(async () => {
      try {
        const res = await api.get(`/customers?search=${encodeURIComponent(customerSearch)}&limit=5`);
        setCustomerResults(res.data.data || []);
      } catch {}
    }, 300);
    return () => clearTimeout(timer);
  }, [customerSearch]);

  const addToCart = (product) => {
    setCart(prev => {
      const existing = prev.find(i => i.product_id === product.id);
      if (existing) {
        return prev.map(i => i.product_id === product.id
          ? { ...i, quantity: i.quantity + 1, total: (i.quantity + 1) * i.unit_price - i.discount_amount }
          : i
        );
      }
      return [...prev, {
        product_id: product.id,
        product_name: product.name,
        article: product.article,
        unit_abbr: product.unit_abbr || 'шт',
        quantity: 1,
        unit_price: parseFloat(product.sale_price),
        discount_amount: 0,
        total: parseFloat(product.sale_price),
      }];
    });
    setSearchQ('');
    setProducts([]);
    if (searchRef.current) searchRef.current.focus();
  };

  const updateQty = (productId, qty) => {
    if (qty <= 0) { removeFromCart(productId); return; }
    setCart(prev => prev.map(i => i.product_id === productId
      ? { ...i, quantity: qty, total: qty * i.unit_price - i.discount_amount }
      : i
    ));
  };

  const updateItemDiscount = (productId, discPercent) => {
    setCart(prev => prev.map(i => {
      if (i.product_id !== productId) return i;
      const da = (i.unit_price * i.quantity * (parseFloat(discPercent) || 0)) / 100;
      return { ...i, discount_amount: da, total: i.unit_price * i.quantity - da };
    }));
  };

  const removeFromCart = (productId) => {
    setCart(prev => prev.filter(i => i.product_id !== productId));
  };

  const getSubtotal = () => cart.reduce((s, i) => s + i.total, 0);
  const getOrderDiscount = () => {
    const sub = getSubtotal();
    if (!discount.value) return 0;
    return discount.type === 'percent'
      ? sub * parseFloat(discount.value) / 100
      : Math.min(parseFloat(discount.value), sub);
  };
  const getTotal = () => Math.max(0, getSubtotal() - getOrderDiscount());

  const applyQuickDiscount = (pct) => setDiscount({ type: 'percent', value: String(pct) });

  const openShift = async () => {
    if (!selectedStore) return toast('Выберите магазин', 'error');
    try {
      const res = await api.post('/shifts', { store_id: selectedStore.id, opening_amount: 0 });
      setCurrentShift(res.data);
      toast('Смена открыта', 'success');
    } catch (e) { toast(formatError(e), 'error'); }
  };

  const handleSale = async () => {
    if (cart.length === 0) return toast('Корзина пуста', 'error');
    if (!selectedStore) return toast('Выберите магазин', 'error');
    if (!currentShift) return toast('Сначала откройте смену', 'error');

    setSaving(true);
    try {
      const res = await api.post('/sales', {
        store_id: selectedStore.id,
        shift_id: currentShift.id,
        customer_id: customer?.id || null,
        items: cart,
        discount_type: discount.type,
        discount_value: parseFloat(discount.value) || 0,
        payment_method: paymentMethod,
        note: note || null,
      });

      setShowSuccess(res.data);
      setCart([]);
      setCustomer(null);
      setDiscount({ type: 'percent', value: '' });
      setNote('');
      toast('Продажа оформлена!', 'success');

      setTimeout(() => setShowSuccess(null), 4000);
    } catch (e) {
      toast(formatError(e), 'error');
    } finally {
      setSaving(false);
    }
  };

  const discountBtns = catalogSettings
    ? [catalogSettings.quick_discount_1, catalogSettings.quick_discount_2, catalogSettings.quick_discount_3, catalogSettings.quick_discount_4]
    : [10, 20, 30, 50];

  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'hidden' }}>
      {/* Left panel — products & cart */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', borderRight: '1px solid var(--gray-200)' }}>
        {/* Header */}
        <div style={{ padding: '12px 16px', background: '#fff', borderBottom: '1px solid var(--gray-200)', display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ fontWeight: 700, color: 'var(--orange)' }}>Касса</div>
          <select
            className="form-control"
            style={{ maxWidth: 180, fontSize: '0.8rem' }}
            value={selectedStore?.id || ''}
            onChange={e => {
              const s = stores.find(s => s.id === parseInt(e.target.value));
              setSelectedStore(s);
              if (s) loadShift(s.id);
            }}
          >
            {stores.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
          {!currentShift ? (
            <button className="btn btn-primary btn-sm" onClick={openShift}>Открыть смену</button>
          ) : (
            <span className="badge badge-green">Смена открыта</span>
          )}
        </div>

        {/* Search */}
        <div style={{ padding: '12px 16px', background: '#fff', borderBottom: '1px solid var(--gray-100)', position: 'relative' }}>
          <div className="search-bar">
            <span className="search-bar__icon">🔍</span>
            <input
              ref={searchRef}
              className="form-control"
              placeholder="Поиск по названию, артикулу, штрихкоду..."
              value={searchQ}
              onChange={e => setSearchQ(e.target.value)}
              style={{ paddingLeft: 34 }}
            />
          </div>
          {/* Dropdown */}
          {products.length > 0 && (
            <div style={{
              position: 'absolute', top: '100%', left: 16, right: 16,
              background: '#fff', boxShadow: 'var(--shadow-lg)', borderRadius: 8,
              zIndex: 200, maxHeight: 320, overflowY: 'auto',
              border: '1px solid var(--gray-200)',
            }}>
              {products.map(p => (
                <div
                  key={p.id}
                  onClick={() => addToCart(p)}
                  style={{
                    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                    padding: '10px 14px', cursor: 'pointer', borderBottom: '1px solid var(--gray-100)',
                  }}
                  onMouseEnter={e => e.currentTarget.style.background = 'var(--gray-50)'}
                  onMouseLeave={e => e.currentTarget.style.background = '#fff'}
                >
                  <div>
                    <div style={{ fontWeight: 500, fontSize: '0.875rem' }}>{p.name}</div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--gray-400)' }}>
                      {p.article} · Остаток: {p.stock} {p.unit_abbr}
                    </div>
                  </div>
                  <div style={{ color: 'var(--orange)', fontWeight: 600, fontSize: '0.875rem' }}>
                    {formatKZT(p.sale_price)}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Cart */}
        <div style={{ flex: 1, overflowY: 'auto', padding: 16 }}>
          {cart.length === 0 ? (
            <div className="empty-state">
              <div className="empty-state__icon">🛒</div>
              <h3>Корзина пуста</h3>
              <p>Найдите и добавьте товар</p>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {cart.map((item, idx) => (
                <div key={item.product_id} style={{
                  background: '#fff', borderRadius: 8, padding: '12px 14px',
                  boxShadow: 'var(--shadow)', display: 'flex', gap: 10, alignItems: 'center'
                }}>
                  <div style={{
                    width: 28, height: 28, borderRadius: 6,
                    background: 'var(--orange-light)', color: 'var(--orange)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: '0.75rem', fontWeight: 700, flexShrink: 0,
                  }}>{idx + 1}</div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontWeight: 500, fontSize: '0.875rem', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item.product_name}</div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--gray-400)' }}>
                      {formatKZT(item.unit_price)} × {item.unit_abbr}
                    </div>
                  </div>
                  {/* Qty controls */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                    <button className="btn btn-secondary btn-icon btn-sm" onClick={() => updateQty(item.product_id, item.quantity - 1)}>−</button>
                    <input
                      type="number"
                      value={item.quantity}
                      onChange={e => updateQty(item.product_id, parseFloat(e.target.value) || 1)}
                      style={{ width: 48, textAlign: 'center', padding: '4px', border: '1px solid var(--gray-300)', borderRadius: 6, fontSize: '0.875rem' }}
                    />
                    <button className="btn btn-secondary btn-icon btn-sm" onClick={() => updateQty(item.product_id, item.quantity + 1)}>+</button>
                  </div>
                  <div style={{ textAlign: 'right', minWidth: 80 }}>
                    <div style={{ fontWeight: 600, color: 'var(--gray-900)' }}>{formatKZT(item.total)}</div>
                    {item.discount_amount > 0 && (
                      <div style={{ fontSize: '0.7rem', color: 'var(--red)' }}>−{formatKZT(item.discount_amount)}</div>
                    )}
                  </div>
                  <button className="btn btn-ghost btn-icon btn-sm" onClick={() => removeFromCart(item.product_id)} style={{ color: 'var(--gray-400)' }}>✕</button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Cart totals */}
        {cart.length > 0 && (
          <div style={{ padding: 16, background: '#fff', borderTop: '1px solid var(--gray-200)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.875rem', color: 'var(--gray-500)', marginBottom: 4 }}>
              <span>Подытог ({cart.length} позиций)</span>
              <span>{formatKZT(getSubtotal())}</span>
            </div>
            {getOrderDiscount() > 0 && (
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.875rem', color: 'var(--red)', marginBottom: 4 }}>
                <span>Скидка</span>
                <span>−{formatKZT(getOrderDiscount())}</span>
              </div>
            )}
            <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 700, fontSize: '1.1rem' }}>
              <span>ИТОГО</span>
              <span style={{ color: 'var(--orange)' }}>{formatKZT(getTotal())}</span>
            </div>
          </div>
        )}
      </div>

      {/* Right panel — customer, discount, payment */}
      <div style={{ width: 320, display: 'flex', flexDirection: 'column', background: '#fff', overflowY: 'auto' }}>
        <div style={{ padding: 16, flex: 1 }}>

          {/* Customer */}
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: '0.8rem', fontWeight: 600, color: 'var(--gray-500)', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Клиент</div>
            {customer ? (
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 12px', background: 'var(--orange-light)', borderRadius: 8 }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 500, fontSize: '0.875rem' }}>{customer.first_name} {customer.last_name}</div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--gray-500)' }}>{customer.phone}</div>
                </div>
                <button onClick={() => setCustomer(null)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--gray-400)' }}>✕</button>
              </div>
            ) : (
              <div style={{ position: 'relative' }}>
                <input
                  className="form-control"
                  placeholder="Имя или телефон клиента"
                  value={customerSearch}
                  onChange={e => setCustomerSearch(e.target.value)}
                  style={{ fontSize: '0.875rem' }}
                />
                {customerResults.length > 0 && (
                  <div style={{
                    position: 'absolute', top: '100%', left: 0, right: 0,
                    background: '#fff', boxShadow: 'var(--shadow-lg)', borderRadius: 8,
                    zIndex: 200, border: '1px solid var(--gray-200)',
                  }}>
                    {customerResults.map(c => (
                      <div
                        key={c.id}
                        onClick={() => { setCustomer(c); setCustomerSearch(''); setCustomerResults([]); }}
                        style={{ padding: '8px 12px', cursor: 'pointer', fontSize: '0.875rem', borderBottom: '1px solid var(--gray-100)' }}
                        onMouseEnter={e => e.currentTarget.style.background = 'var(--gray-50)'}
                        onMouseLeave={e => e.currentTarget.style.background = '#fff'}
                      >
                        <div style={{ fontWeight: 500 }}>{c.first_name} {c.last_name}</div>
                        <div style={{ fontSize: '0.75rem', color: 'var(--gray-400)' }}>{c.phone}</div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Discount */}
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: '0.8rem', fontWeight: 600, color: 'var(--gray-500)', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Скидка на заказ</div>
            <div style={{ display: 'flex', gap: 6, marginBottom: 8 }}>
              {discountBtns.map(pct => (
                <button
                  key={pct}
                  className={`btn btn-sm ${discount.value === String(pct) && discount.type === 'percent' ? 'btn-primary' : 'btn-secondary'}`}
                  onClick={() => applyQuickDiscount(pct)}
                  style={{ flex: 1, padding: '5px 4px', fontSize: '0.78rem' }}
                >
                  {pct}%
                </button>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 6 }}>
              <select
                className="form-control"
                style={{ width: 80, fontSize: '0.8rem' }}
                value={discount.type}
                onChange={e => setDiscount(p => ({ ...p, type: e.target.value }))}
              >
                <option value="percent">%</option>
                <option value="fixed">₸</option>
              </select>
              <input
                className="form-control"
                type="number"
                placeholder="0"
                value={discount.value}
                onChange={e => setDiscount(p => ({ ...p, value: e.target.value }))}
                style={{ flex: 1, fontSize: '0.875rem' }}
              />
            </div>
          </div>

          {/* Payment method */}
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: '0.8rem', fontWeight: 600, color: 'var(--gray-500)', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Способ оплаты</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
              {paymentMethods.filter(pm => pm.is_active).map(pm => (
                <button
                  key={pm.id}
                  className={`btn btn-sm ${paymentMethod === pm.name ? 'btn-primary' : 'btn-secondary'}`}
                  onClick={() => setPaymentMethod(pm.name)}
                >
                  {pm.name}
                </button>
              ))}
            </div>
          </div>

          {/* Note */}
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: '0.8rem', fontWeight: 600, color: 'var(--gray-500)', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Комментарий</div>
            <textarea
              className="form-control"
              placeholder="Заметка к продаже..."
              value={note}
              onChange={e => setNote(e.target.value)}
              style={{ fontSize: '0.875rem', minHeight: 60 }}
            />
          </div>
        </div>

        {/* Total + Submit */}
        <div style={{ padding: 16, borderTop: '1px solid var(--gray-200)' }}>
          <div style={{ marginBottom: 12, textAlign: 'center' }}>
            <div style={{ fontSize: '0.8rem', color: 'var(--gray-500)' }}>К оплате</div>
            <div style={{ fontSize: '2rem', fontWeight: 800, color: 'var(--orange)' }}>{formatKZT(getTotal())}</div>
          </div>
          <button
            className="btn btn-primary btn-lg"
            style={{ width: '100%', fontSize: '1rem', padding: '12px' }}
            onClick={handleSale}
            disabled={processing || cart.length === 0}
          >
            {processing ? <span className="spinner" /> : `Принять оплату · ${paymentMethod}`}
          </button>
        </div>

        {/* Success overlay */}
        {showSuccess && (
          <div style={{
            position: 'absolute', inset: 0,
            background: 'rgba(255,255,255,0.95)',
            display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
            gap: 12, textAlign: 'center', padding: 32, zIndex: 300,
          }}>
            <div style={{ fontSize: '4rem' }}>✅</div>
            <h2 style={{ color: 'var(--green)' }}>Продажа оформлена!</h2>
            <div style={{ fontSize: '1.5rem', fontWeight: 700 }}>{formatKZT(showSuccess.total)}</div>
            <div style={{ color: 'var(--gray-500)', fontSize: '0.875rem' }}>{showSuccess.transaction_no}</div>
          </div>
        )}
      </div>
    </div>
  );
}
