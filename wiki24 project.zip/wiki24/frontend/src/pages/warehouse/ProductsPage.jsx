import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api, { formatKZT, formatError } from '../../api/axios';
import useUIStore from '../../store/uiStore';

export default function ProductsPage() {
  const navigate = useNavigate();
  const { toast } = useUIStore();
  const [data, setData] = useState([]);
  const [stats, setStats] = useState({});
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [filters, setFilters] = useState({ search: '', category_id: '', brand_id: '', status: '' });
  const [categories, setCategories] = useState([]);
  const [brands, setBrands] = useState([]);
  const [showStats, setShowStats] = useState(true);
  const LIMIT = 20;

  useEffect(() => {
    api.get('/categories').then(r => setCategories(r.data.data || [])).catch(() => {});
    api.get('/brands').then(r => setBrands(r.data.data || [])).catch(() => {});
  }, []);

  useEffect(() => { load(); }, [page, filters]);

  const load = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page, limit: LIMIT, ...filters });
      const res = await api.get(`/products?${params}`);
      setData(res.data.data || []);
      setTotal(res.data.pagination?.total || 0);
      setStats(res.data.stats || {});
    } catch (e) { toast(formatError(e), 'error'); }
    finally { setLoading(false); }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Удалить товар?')) return;
    try {
      await api.delete(`/products/${id}`);
      toast('Товар удалён', 'success');
      load();
    } catch (e) { toast(formatError(e), 'error'); }
  };

  const stockBadge = (qty) => {
    if (qty <= 0) return <span className="badge badge-red">0</span>;
    if (qty <= 5) return <span className="badge badge-yellow">{qty}</span>;
    return <span className="badge badge-green">{qty}</span>;
  };

  return (
    <div>
      <div className="page-header">
        <div className="page-header__title">
          <h1>Каталог товаров</h1>
          <p>Управление ассортиментом</p>
        </div>
        <div className="page-header__actions">
          <button className="btn btn-secondary btn-sm" onClick={() => setShowStats(!showStats)}>
            {showStats ? 'Скрыть' : 'Показать'} статистику
          </button>
          <button className="btn btn-primary" onClick={() => navigate('/warehouse/products/new')}>
            + Новый товар
          </button>
        </div>
      </div>

      {showStats && (
        <div className="stat-cards">
          <div className="stat-card">
            <div className="stat-card__label">Всего товаров</div>
            <div className="stat-card__value">{parseInt(stats.total_products || 0).toLocaleString('ru')} шт</div>
          </div>
          <div className="stat-card">
            <div className="stat-card__label">Ед. на складе</div>
            <div className="stat-card__value">{parseFloat(stats.total_units || 0).toLocaleString('ru')}</div>
          </div>
          <div className="stat-card">
            <div className="stat-card__label">По закупочной</div>
            <div className="stat-card__value" style={{ fontSize: '1rem' }}>{formatKZT(stats.purchase_value || 0)}</div>
          </div>
          <div className="stat-card">
            <div className="stat-card__label">По продажной</div>
            <div className="stat-card__value" style={{ fontSize: '1rem' }}>{formatKZT(stats.sale_value || 0)}</div>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="card" style={{ marginBottom: 16 }}>
        <div className="filters-row">
          <div className="search-bar" style={{ flex: 1, minWidth: 200 }}>
            <span className="search-bar__icon">🔍</span>
            <input className="form-control" placeholder="Название, артикул, штрихкод..."
              value={filters.search} onChange={e => setFilters(p => ({ ...p, search: e.target.value }))}
              style={{ paddingLeft: 34 }} />
          </div>
          <select className="form-control" style={{ width: 150 }}
            value={filters.category_id} onChange={e => setFilters(p => ({ ...p, category_id: e.target.value }))}>
            <option value="">Все категории</option>
            {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <select className="form-control" style={{ width: 130 }}
            value={filters.brand_id} onChange={e => setFilters(p => ({ ...p, brand_id: e.target.value }))}>
            <option value="">Все бренды</option>
            {brands.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
          </select>
          <select className="form-control" style={{ width: 130 }}
            value={filters.status} onChange={e => setFilters(p => ({ ...p, status: e.target.value }))}>
            <option value="">Все статусы</option>
            <option value="active">Активные</option>
            <option value="inactive">Неактивные</option>
          </select>
          <button className="btn btn-secondary" onClick={() => { setFilters({ search: '', category_id: '', brand_id: '', status: '' }); setPage(1); }}>
            Сбросить
          </button>
        </div>
      </div>

      <div className="card">
        {loading ? (
          <div className="loading-center"><div className="spinner spinner-lg" /></div>
        ) : data.length === 0 ? (
          <div className="empty-state">
            <div className="empty-state__icon">📦</div>
            <h3>Товаров нет</h3>
            <p>Добавьте первый товар</p>
            <button className="btn btn-primary" onClick={() => navigate('/warehouse/products/new')}>+ Новый товар</button>
          </div>
        ) : (
          <div className="table-container">
            <table className="table">
              <thead>
                <tr>
                  <th>Фото</th>
                  <th>Название</th>
                  <th>Артикул</th>
                  <th>Категория</th>
                  <th>Бренд</th>
                  <th style={{ textAlign: 'right' }}>Закуп.</th>
                  <th style={{ textAlign: 'right' }}>Продажа</th>
                  <th style={{ textAlign: 'center' }}>Остаток</th>
                  <th>Статус</th>
                  <th>Действия</th>
                </tr>
              </thead>
              <tbody>
                {data.map(p => (
                  <tr key={p.id}>
                    <td>
                      {p.image_url ? (
                        <img src={p.image_url} alt="" style={{ width: 36, height: 36, objectFit: 'cover', borderRadius: 6 }} />
                      ) : (
                        <div style={{ width: 36, height: 36, borderRadius: 6, background: 'var(--gray-100)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1rem' }}>📦</div>
                      )}
                    </td>
                    <td>
                      <span className="link-cell" onClick={() => navigate(`/warehouse/products/${p.id}/edit`)}>{p.name}</span>
                      {p.variants_count > 0 && <span className="badge badge-blue" style={{ marginLeft: 4 }}>+{p.variants_count}</span>}
                    </td>
                    <td style={{ color: 'var(--gray-500)', fontSize: '0.8rem' }}>{p.article || '—'}</td>
                    <td style={{ color: 'var(--gray-500)' }}>{p.category_name || '—'}</td>
                    <td style={{ color: 'var(--gray-500)' }}>{p.brand_name || '—'}</td>
                    <td style={{ textAlign: 'right', color: 'var(--gray-500)' }}>{formatKZT(p.purchase_price)}</td>
                    <td style={{ textAlign: 'right', fontWeight: 600, color: 'var(--orange)' }}>{formatKZT(p.sale_price)}</td>
                    <td style={{ textAlign: 'center' }}>{stockBadge(p.total_stock)}</td>
                    <td>
                      {p.status === 'active'
                        ? <span className="badge badge-green">Активен</span>
                        : <span className="badge badge-gray">Неактивен</span>}
                    </td>
                    <td>
                      <div style={{ display: 'flex', gap: 4 }}>
                        <button className="btn btn-secondary btn-sm" onClick={() => navigate(`/warehouse/products/${p.id}/edit`)}>✏️</button>
                        <button className="btn btn-secondary btn-sm" onClick={() => handleDelete(p.id)}>🗑</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {total > LIMIT && (
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 0 0', borderTop: '1px solid var(--gray-100)' }}>
            <span style={{ fontSize: '0.8rem', color: 'var(--gray-500)' }}>Всего: {total}</span>
            <div className="pagination">
              <button className="pagination__btn" disabled={page === 1} onClick={() => setPage(p => p - 1)}>‹</button>
              <button className="pagination__btn active">{page}</button>
              <button className="pagination__btn" disabled={page * LIMIT >= total} onClick={() => setPage(p => p + 1)}>›</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
