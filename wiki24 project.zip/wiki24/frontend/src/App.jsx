import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import useAuthStore from './store/authStore';
import useUIStore from './store/uiStore';

// Layout
import AppLayout from './components/layout/AppLayout';
import Toast from './components/common/Toast';

// Auth
import LoginPage from './pages/LoginPage';

// Sales
import POSPage from './pages/sales/POSPage';
import SalesListPage from './pages/sales/SalesListPage';
import CashShiftsPage from './pages/sales/CashShiftsPage';
import CashOperationsPage from './pages/sales/CashOperationsPage';

// Warehouse
import ProductsPage from './pages/warehouse/ProductsPage';
import ProductFormPage from './pages/warehouse/ProductFormPage';
import PurchasesPage from './pages/warehouse/PurchasesPage';
import InventoriesPage from './pages/warehouse/InventoriesPage';
import TransfersPage from './pages/warehouse/TransfersPage';
import WriteoffsPage from './pages/warehouse/WriteoffsPage';
import RepricingsPage from './pages/warehouse/RepricingsPage';
import SuppliersPage from './pages/warehouse/SuppliersPage';

// Customers
import CustomersPage from './pages/customers/CustomersPage';
import CustomerGroupsPage from './pages/customers/CustomerGroupsPage';
import LoyaltyPage from './pages/customers/LoyaltyPage';
import DebtsPage from './pages/customers/DebtsPage';

// Management
import EmployeesPage from './pages/management/EmployeesPage';
import RolesPage from './pages/management/RolesPage';

// Settings
import ProfilePage from './pages/settings/ProfilePage';
import GeneralSettingsPage from './pages/settings/GeneralSettingsPage';
import CashSettingsPage from './pages/settings/CashSettingsPage';
import DirectoriesPage from './pages/settings/DirectoriesPage';
import SubscriptionPage from './pages/settings/SubscriptionPage';
import NotificationsPage from './pages/settings/NotificationsPage';
import IntegrationsPage from './pages/settings/IntegrationsPage';

// Loading
const Loader = () => (
  <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
    <div className="spinner spinner-lg" />
  </div>
);

// Auth guard
const PrivateRoute = ({ children }) => {
  const { isAuthenticated, loading } = useAuthStore();
  if (loading) return <Loader />;
  return isAuthenticated ? children : <Navigate to="/login" replace />;
};

function App() {
  const { initAuth, loading } = useAuthStore();
  const { toasts } = useUIStore();

  useEffect(() => { initAuth(); }, []);

  if (loading) return <Loader />;

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        
        <Route path="/" element={
          <PrivateRoute><AppLayout /></PrivateRoute>
        }>
          {/* Dashboard → redirect to sales */}
          <Route index element={<Navigate to="/sales/pos" replace />} />

          {/* Sales */}
          <Route path="sales/pos" element={<POSPage />} />
          <Route path="sales/list" element={<SalesListPage />} />
          <Route path="sales/shifts" element={<CashShiftsPage />} />
          <Route path="sales/operations" element={<CashOperationsPage />} />

          {/* Warehouse */}
          <Route path="warehouse/products" element={<ProductsPage />} />
          <Route path="warehouse/products/new" element={<ProductFormPage />} />
          <Route path="warehouse/products/:id/edit" element={<ProductFormPage />} />
          <Route path="warehouse/purchases" element={<PurchasesPage />} />
          <Route path="warehouse/inventories" element={<InventoriesPage />} />
          <Route path="warehouse/transfers" element={<TransfersPage />} />
          <Route path="warehouse/writeoffs" element={<WriteoffsPage />} />
          <Route path="warehouse/repricings" element={<RepricingsPage />} />
          <Route path="warehouse/suppliers" element={<SuppliersPage />} />

          {/* Customers */}
          <Route path="customers/list" element={<CustomersPage />} />
          <Route path="customers/groups" element={<CustomerGroupsPage />} />
          <Route path="customers/loyalty" element={<LoyaltyPage />} />
          <Route path="customers/debts" element={<DebtsPage />} />

          {/* Management */}
          <Route path="management/employees" element={<EmployeesPage />} />
          <Route path="management/roles" element={<RolesPage />} />

          {/* Settings */}
          <Route path="settings/profile" element={<ProfilePage />} />
          <Route path="settings/general" element={<GeneralSettingsPage />} />
          <Route path="settings/cash" element={<CashSettingsPage />} />
          <Route path="settings/directories" element={<DirectoriesPage />} />
          <Route path="settings/subscription" element={<SubscriptionPage />} />
          <Route path="settings/notifications" element={<NotificationsPage />} />
          <Route path="settings/integrations" element={<IntegrationsPage />} />
        </Route>

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>

      {/* Toasts */}
      <div className="toast-container">
        {toasts.map((t) => <Toast key={t.id} toast={t} />)}
      </div>
    </BrowserRouter>
  );
}

export default App;
