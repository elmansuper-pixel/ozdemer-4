const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { query } = require('../config/database');

const generateTokens = (userId, email, role) => {
  const accessToken = jwt.sign(
    { userId, email, role },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '15m' }
  );
  const refreshToken = jwt.sign(
    { userId, email, role },
    process.env.JWT_REFRESH_SECRET,
    { expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d' }
  );
  return { accessToken, refreshToken };
};

const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ message: 'Email и пароль обязательны' });
    }

    const { rows } = await query(
      `SELECT u.*, c.name AS company_name, c.base_currency, c.sales_currency
       FROM users u
       LEFT JOIN companies c ON c.id = u.company_id
       WHERE u.email = $1`,
      [email.toLowerCase().trim()]
    );

    if (rows.length === 0) {
      return res.status(401).json({ message: 'Неверный email или пароль' });
    }

    const user = rows[0];

    if (!user.is_active) {
      return res.status(401).json({ message: 'Аккаунт заблокирован' });
    }

    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) {
      return res.status(401).json({ message: 'Неверный email или пароль' });
    }

    const { accessToken, refreshToken } = generateTokens(user.id, user.email, user.role);

    // Save refresh token
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    await query(
      'INSERT INTO refresh_tokens (user_id, token, expires_at) VALUES ($1, $2, $3)',
      [user.id, refreshToken, expiresAt]
    );

    // Update last login
    await query('UPDATE users SET updated_at = NOW() WHERE id = $1', [user.id]);

    const { password: _, ...userWithoutPassword } = user;

    res.json({
      accessToken,
      refreshToken,
      user: userWithoutPassword,
    });
  } catch (error) {
    console.error('Login error:', error.message);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
};

const refresh = async (req, res) => {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      return res.status(401).json({ message: 'Refresh token не предоставлен' });
    }

    let decoded;
    try {
      decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
    } catch (err) {
      return res.status(401).json({ message: 'Неверный или истёкший refresh token', code: 'REFRESH_EXPIRED' });
    }

    // Check if token exists in DB
    const { rows } = await query(
      'SELECT * FROM refresh_tokens WHERE token = $1 AND expires_at > NOW()',
      [refreshToken]
    );

    if (rows.length === 0) {
      return res.status(401).json({ message: 'Refresh token не найден', code: 'REFRESH_NOT_FOUND' });
    }

    // Get user
    const { rows: users } = await query(
      'SELECT id, email, role, is_active FROM users WHERE id = $1',
      [decoded.userId]
    );

    if (users.length === 0 || !users[0].is_active) {
      return res.status(401).json({ message: 'Пользователь не найден' });
    }

    const user = users[0];
    const tokens = generateTokens(user.id, user.email, user.role);

    // Replace old refresh token
    await query('DELETE FROM refresh_tokens WHERE token = $1', [refreshToken]);
    
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    await query(
      'INSERT INTO refresh_tokens (user_id, token, expires_at) VALUES ($1, $2, $3)',
      [user.id, tokens.refreshToken, expiresAt]
    );

    res.json(tokens);
  } catch (error) {
    console.error('Refresh error:', error.message);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
};

const logout = async (req, res) => {
  try {
    const { refreshToken } = req.body;
    if (refreshToken) {
      await query('DELETE FROM refresh_tokens WHERE token = $1', [refreshToken]);
    }
    res.json({ message: 'Вы вышли из системы' });
  } catch (error) {
    res.status(500).json({ message: 'Ошибка сервера' });
  }
};

const me = async (req, res) => {
  try {
    const { rows } = await query(
      `SELECT u.id, u.email, u.first_name, u.last_name, u.phone, u.avatar_url,
              u.role, u.theme, u.language, u.is_active, u.company_id,
              c.name AS company_name, c.base_currency, c.sales_currency,
              c.physical_address, c.logo_url AS company_logo
       FROM users u
       LEFT JOIN companies c ON c.id = u.company_id
       WHERE u.id = $1`,
      [req.user.id]
    );
    
    if (rows.length === 0) {
      return res.status(404).json({ message: 'Пользователь не найден' });
    }
    
    res.json({ user: rows[0] });
  } catch (error) {
    console.error('Me error:', error.message);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
};

module.exports = { login, refresh, logout, me };
