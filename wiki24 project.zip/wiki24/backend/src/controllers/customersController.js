const { query } = require('../config/database');

const getCustomers = async (req, res) => {
  try {
    const companyId = req.user.company_id;
    const { page = 1, limit = 10, search = '', group_id } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);
    const params = [companyId];
    let conditions = ['c.company_id = $1', 'c.is_active = true'];
    let idx = 2;

    if (search) {
      conditions.push(`(c.first_name ILIKE $${idx} OR c.last_name ILIKE $${idx} OR c.phone ILIKE $${idx})`);
      params.push(`%${search}%`);
      idx++;
    }
    if (group_id) {
      conditions.push(`EXISTS (SELECT 1 FROM customer_group_members WHERE customer_id = c.id AND group_id = $${idx})`);
      params.push(parseInt(group_id));
      idx++;
    }

    const where = conditions.join(' AND ');

    const { rows: countRows } = await query(`SELECT COUNT(*) FROM customers c WHERE ${where}`, params);

    const { rows } = await query(`
      SELECT
        c.*,
        COALESCE(array_agg(DISTINCT cg.name) FILTER (WHERE cg.name IS NOT NULL), '{}') AS groups
      FROM customers c
      LEFT JOIN customer_group_members cgm ON cgm.customer_id = c.id
      LEFT JOIN customer_groups cg ON cg.id = cgm.group_id
      WHERE ${where}
      GROUP BY c.id
      ORDER BY c.id DESC
      LIMIT $${idx} OFFSET $${idx + 1}
    `, [...params, parseInt(limit), offset]);

    // Stats
    const { rows: stats } = await query(`
      SELECT
        COUNT(*) AS total,
        COUNT(*) FILTER (WHERE created_at >= NOW() - interval '7 days') AS new_this_week,
        COUNT(*) FILTER (WHERE last_purchase_at IS NULL) AS non_returning,
        COUNT(*) FILTER (
          WHERE birthday IS NOT NULL
          AND EXTRACT(MONTH FROM birthday) = EXTRACT(MONTH FROM NOW())
          AND EXTRACT(DAY FROM birthday) >= EXTRACT(DAY FROM NOW())
          AND EXTRACT(DAY FROM birthday) <= EXTRACT(DAY FROM NOW()) + 7
        ) AS birthdays_soon
      FROM customers
      WHERE company_id = $1 AND is_active = true
    `, [companyId]);

    res.json({
      data: rows,
      pagination: {
        total: parseInt(countRows[0].count),
        page: parseInt(page),
        limit: parseInt(limit),
        pages: Math.ceil(parseInt(countRows[0].count) / parseInt(limit)),
      },
      stats: stats[0],
    });
  } catch (error) {
    console.error('getCustomers error:', error.message);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
};

const getCustomer = async (req, res) => {
  try {
    const { id } = req.params;
    const companyId = req.user.company_id;

    const { rows } = await query(
      'SELECT * FROM customers WHERE id = $1 AND company_id = $2',
      [id, companyId]
    );
    if (rows.length === 0) return res.status(404).json({ message: 'Клиент не найден' });

    const { rows: sales } = await query(`
      SELECT s.id, s.transaction_no, s.total, s.payment_method, s.created_at,
             st.name AS store_name
      FROM sales s
      JOIN stores st ON st.id = s.store_id
      WHERE s.customer_id = $1 AND s.type = 'sale'
      ORDER BY s.created_at DESC
      LIMIT 10
    `, [id]);

    res.json({ ...rows[0], recent_sales: sales });
  } catch (error) {
    console.error('getCustomer error:', error.message);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
};

const createCustomer = async (req, res) => {
  try {
    const companyId = req.user.company_id;
    const { first_name, last_name, phone, email, birthday, gender, address, discount_percent } = req.body;

    if (!first_name) return res.status(400).json({ message: 'Имя обязательно' });

    const { rows } = await query(`
      INSERT INTO customers (company_id, first_name, last_name, phone, email, birthday, gender, address, discount_percent)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
      RETURNING *
    `, [companyId, first_name, last_name || null, phone || null, email || null,
        birthday || null, gender || null, address || null, parseFloat(discount_percent) || 0]);

    res.status(201).json(rows[0]);
  } catch (error) {
    console.error('createCustomer error:', error.message);
    res.status(500).json({ message: 'Ошибка создания клиента' });
  }
};

const updateCustomer = async (req, res) => {
  try {
    const { id } = req.params;
    const companyId = req.user.company_id;
    const { first_name, last_name, phone, email, birthday, gender, address, discount_percent } = req.body;

    const { rows } = await query(`
      UPDATE customers SET
        first_name = COALESCE($1, first_name),
        last_name = $2,
        phone = $3,
        email = $4,
        birthday = $5,
        gender = $6,
        address = $7,
        discount_percent = COALESCE($8, discount_percent),
        updated_at = NOW()
      WHERE id = $9 AND company_id = $10
      RETURNING *
    `, [first_name, last_name || null, phone || null, email || null,
        birthday || null, gender || null, address || null,
        discount_percent ? parseFloat(discount_percent) : null, id, companyId]);

    if (rows.length === 0) return res.status(404).json({ message: 'Клиент не найден' });

    res.json(rows[0]);
  } catch (error) {
    console.error('updateCustomer error:', error.message);
    res.status(500).json({ message: 'Ошибка обновления клиента' });
  }
};

const deleteCustomer = async (req, res) => {
  try {
    const { id } = req.params;
    const companyId = req.user.company_id;

    const { rows } = await query(
      'UPDATE customers SET is_active = false, updated_at = NOW() WHERE id = $1 AND company_id = $2 RETURNING id',
      [id, companyId]
    );
    if (rows.length === 0) return res.status(404).json({ message: 'Клиент не найден' });

    res.json({ message: 'Клиент удалён', id: parseInt(id) });
  } catch (error) {
    console.error('deleteCustomer error:', error.message);
    res.status(500).json({ message: 'Ошибка удаления клиента' });
  }
};

module.exports = { getCustomers, getCustomer, createCustomer, updateCustomer, deleteCustomer };
