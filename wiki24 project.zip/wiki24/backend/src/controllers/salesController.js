const { query, getClient } = require('../config/database');

const getSales = async (req, res) => {
  try {
    const companyId = req.user.company_id;
    const {
      page = 1, limit = 10, search = '',
      date_from, date_to, store_id, type, cashier_id,
    } = req.query;

    const offset = (parseInt(page) - 1) * parseInt(limit);
    const params = [companyId];
    let conditions = ['s.store_id IN (SELECT id FROM stores WHERE company_id = $1)'];
    let idx = 2;

    if (search) {
      conditions.push(`s.transaction_no ILIKE $${idx}`);
      params.push(`%${search}%`);
      idx++;
    }
    if (date_from) {
      conditions.push(`s.created_at >= $${idx}`);
      params.push(date_from);
      idx++;
    }
    if (date_to) {
      conditions.push(`s.created_at < $${idx}::date + interval '1 day'`);
      params.push(date_to);
      idx++;
    }
    if (store_id) {
      conditions.push(`s.store_id = $${idx}`);
      params.push(parseInt(store_id));
      idx++;
    }
    if (type) {
      conditions.push(`s.type = $${idx}`);
      params.push(type);
      idx++;
    }
    if (cashier_id) {
      conditions.push(`s.cashier_id = $${idx}`);
      params.push(parseInt(cashier_id));
      idx++;
    }

    const where = conditions.join(' AND ');

    const { rows: countRows } = await query(
      `SELECT COUNT(*) FROM sales s WHERE ${where}`,
      params
    );

    const { rows } = await query(`
      SELECT
        s.*,
        st.name AS store_name,
        c.first_name || ' ' || COALESCE(c.last_name, '') AS customer_name,
        u.first_name || ' ' || u.last_name AS cashier_name,
        (SELECT COUNT(*) FROM sale_items WHERE sale_id = s.id) AS items_count,
        (SELECT SUM(quantity) FROM sale_items WHERE sale_id = s.id) AS total_qty
      FROM sales s
      JOIN stores st ON st.id = s.store_id
      LEFT JOIN customers c ON c.id = s.customer_id
      JOIN users u ON u.id = s.cashier_id
      WHERE ${where}
      ORDER BY s.created_at DESC
      LIMIT $${idx} OFFSET $${idx + 1}
    `, [...params, parseInt(limit), offset]);

    // Summary stats for the period
    const { rows: stats } = await query(`
      SELECT
        COUNT(*) FILTER (WHERE type = 'sale') AS transactions,
        COUNT(*) FILTER (WHERE type = 'sale') AS products_count,
        COALESCE(SUM(total) FILTER (WHERE type = 'sale'), 0) AS total_amount,
        COALESCE(SUM(total) FILTER (WHERE type = 'refund'), 0) AS refund_amount,
        COALESCE(SUM(total) FILTER (WHERE payment_method = 'Наличные' AND type = 'sale'), 0) AS cash_amount
      FROM sales s
      WHERE ${where}
    `, params);

    res.json({
      data: rows,
      pagination: {
        total: parseInt(countRows[0].count),
        page: parseInt(page),
        limit: parseInt(limit),
        pages: Math.ceil(parseInt(countRows[0].count) / parseInt(limit)),
      },
      stats: stats[0],
    });
  } catch (error) {
    console.error('getSales error:', error.message);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
};

const getSale = async (req, res) => {
  try {
    const { id } = req.params;
    const companyId = req.user.company_id;

    const { rows } = await query(`
      SELECT s.*,
        st.name AS store_name,
        c.first_name || ' ' || COALESCE(c.last_name, '') AS customer_name,
        c.phone AS customer_phone,
        u.first_name || ' ' || u.last_name AS cashier_name
      FROM sales s
      JOIN stores st ON st.id = s.store_id
      LEFT JOIN customers c ON c.id = s.customer_id
      JOIN users u ON u.id = s.cashier_id
      WHERE s.id = $1 AND st.company_id = $2
    `, [id, companyId]);

    if (rows.length === 0) {
      return res.status(404).json({ message: 'Продажа не найдена' });
    }

    const { rows: items } = await query(
      'SELECT * FROM sale_items WHERE sale_id = $1',
      [id]
    );

    res.json({ ...rows[0], items });
  } catch (error) {
    console.error('getSale error:', error.message);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
};

const createSale = async (req, res) => {
  const client = await getClient();
  try {
    await client.query('BEGIN');

    const companyId = req.user.company_id;
    const {
      store_id, customer_id, items, discount_type, discount_value,
      payment_method, note, is_draft, shift_id,
    } = req.body;

    if (!store_id || !items || items.length === 0) {
      return res.status(400).json({ message: 'Магазин и товары обязательны' });
    }

    // Verify store belongs to company
    const { rows: stores } = await client.query(
      'SELECT id FROM stores WHERE id = $1 AND company_id = $2',
      [store_id, companyId]
    );
    if (stores.length === 0) {
      return res.status(403).json({ message: 'Магазин не найден' });
    }

    // Generate transaction number
    const date = new Date();
    const dateStr = date.toISOString().slice(0, 10).replace(/-/g, '');
    const { rows: lastSale } = await client.query(
      "SELECT transaction_no FROM sales WHERE transaction_no LIKE $1 ORDER BY id DESC LIMIT 1",
      [`RCP-${date.getFullYear()}-TENA-%`]
    );
    let seqNum = 1;
    if (lastSale.length > 0) {
      const parts = lastSale[0].transaction_no.split('-');
      seqNum = parseInt(parts[parts.length - 1]) + 1;
    }
    const transactionNo = `RCP-${date.getFullYear()}-TENA-${String(seqNum).padStart(5, '0')}-${Date.now().toString().slice(-5)}`;

    // Calculate totals
    let subtotal = 0;
    const processedItems = [];

    for (const item of items) {
      const { rows: products } = await client.query(
        'SELECT id, name, article, sale_price, purchase_price FROM products WHERE id = $1 AND company_id = $2',
        [item.product_id, companyId]
      );
      if (products.length === 0) {
        throw new Error(`Товар ${item.product_id} не найден`);
      }
      const product = products[0];
      const unitPrice = parseFloat(item.unit_price || product.sale_price);
      const quantity = parseFloat(item.quantity);
      const itemDiscount = parseFloat(item.discount_amount || 0);
      const itemTotal = unitPrice * quantity - itemDiscount;
      subtotal += itemTotal;

      processedItems.push({
        product_id: product.id,
        product_name: product.name,
        article: product.article,
        quantity,
        unit_price: unitPrice,
        discount_amount: itemDiscount,
        total: itemTotal,
        purchase_price: product.purchase_price,
      });
    }

    // Apply order discount
    let discountAmount = 0;
    const discType = discount_type || 'percent';
    const discValue = parseFloat(discount_value || 0);
    if (discType === 'percent' && discValue > 0) {
      discountAmount = subtotal * discValue / 100;
    } else if (discType === 'fixed' && discValue > 0) {
      discountAmount = discValue;
    }

    const total = Math.max(0, subtotal - discountAmount);

    // Create sale
    const { rows: sale } = await client.query(`
      INSERT INTO sales (
        transaction_no, store_id, shift_id, cashier_id, customer_id,
        type, status, subtotal, discount_amount, discount_type, discount_value,
        total, payment_method, note, is_draft
      ) VALUES ($1,$2,$3,$4,$5,'sale','completed',$6,$7,$8,$9,$10,$11,$12,$13)
      RETURNING *
    `, [
      transactionNo, store_id, shift_id || null, req.user.id,
      customer_id || null, subtotal, discountAmount, discType, discValue,
      total, payment_method || 'Наличные', note || null, is_draft || false,
    ]);

    const saleId = sale[0].id;

    // Create sale items and update stock
    for (const item of processedItems) {
      await client.query(`
        INSERT INTO sale_items (sale_id, product_id, product_name, article, quantity, unit_price, discount_amount, total, purchase_price)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
      `, [saleId, item.product_id, item.product_name, item.article, item.quantity, item.unit_price, item.discount_amount, item.total, item.purchase_price]);

      // Deduct from stock
      await client.query(`
        UPDATE product_stock SET quantity = GREATEST(0, quantity - $1), updated_at = NOW()
        WHERE product_id = $2 AND store_id = $3
      `, [item.quantity, item.product_id, store_id]);
    }

    // Update customer stats
    if (customer_id) {
      await client.query(`
        UPDATE customers SET
          total_spent = total_spent + $1,
          last_purchase_at = NOW(),
          updated_at = NOW()
        WHERE id = $2
      `, [total, customer_id]);
    }

    // Update shift revenue
    if (shift_id) {
      await client.query(
        'UPDATE cash_shifts SET revenue = revenue + $1 WHERE id = $2',
        [total, shift_id]
      );
    }

    await client.query('COMMIT');

    // Return full sale with items
    const { rows: fullSale } = await query(
      'SELECT * FROM sales WHERE id = $1',
      [saleId]
    );
    const { rows: saleItems } = await query(
      'SELECT * FROM sale_items WHERE sale_id = $1',
      [saleId]
    );

    res.status(201).json({ ...fullSale[0], items: saleItems });
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('createSale error:', error.message);
    res.status(500).json({ message: error.message || 'Ошибка создания продажи' });
  } finally {
    client.release();
  }
};

const createRefund = async (req, res) => {
  const client = await getClient();
  try {
    await client.query('BEGIN');

    const { id } = req.params;
    const companyId = req.user.company_id;
    const { items, note } = req.body;

    // Get original sale
    const { rows: originalSales } = await client.query(`
      SELECT s.* FROM sales s
      JOIN stores st ON st.id = s.store_id
      WHERE s.id = $1 AND st.company_id = $2 AND s.type = 'sale'
    `, [id, companyId]);

    if (originalSales.length === 0) {
      return res.status(404).json({ message: 'Продажа не найдена' });
    }

    const original = originalSales[0];

    // Get items to refund
    const { rows: originalItems } = await client.query(
      'SELECT * FROM sale_items WHERE sale_id = $1',
      [id]
    );

    const refundItems = items || originalItems.map(i => ({
      product_id: i.product_id,
      quantity: i.quantity,
      unit_price: i.unit_price,
    }));

    let refundTotal = 0;
    for (const item of refundItems) {
      refundTotal += parseFloat(item.unit_price) * parseFloat(item.quantity);
    }

    // Create refund transaction
    const transactionNo = `RFD-${Date.now()}`;
    const { rows: refund } = await client.query(`
      INSERT INTO sales (
        transaction_no, store_id, cashier_id, customer_id,
        type, status, subtotal, total, payment_method, note, original_sale_id
      ) VALUES ($1,$2,$3,$4,'refund','completed',$5,$5,$6,$7,$8)
      RETURNING *
    `, [
      transactionNo, original.store_id, req.user.id, original.customer_id,
      refundTotal, original.payment_method, note || null, id,
    ]);

    // Return items to stock
    for (const item of refundItems) {
      await client.query(`
        INSERT INTO sale_items (sale_id, product_id, product_name, article, quantity, unit_price, total)
        SELECT $1, $2, product_name, article, $3, $4, $5
        FROM sale_items WHERE sale_id = $6 AND product_id = $2 LIMIT 1
      `, [refund[0].id, item.product_id, item.quantity, item.unit_price, item.unit_price * item.quantity, id]);

      await client.query(`
        UPDATE product_stock SET quantity = quantity + $1
        WHERE product_id = $2 AND store_id = $3
      `, [item.quantity, item.product_id, original.store_id]);
    }

    await client.query('COMMIT');
    res.status(201).json(refund[0]);
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('createRefund error:', error.message);
    res.status(500).json({ message: 'Ошибка создания возврата' });
  } finally {
    client.release();
  }
};

module.exports = { getSales, getSale, createSale, createRefund };
