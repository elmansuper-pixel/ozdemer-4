const { query, getClient } = require('../config/database');

const getProducts = async (req, res) => {
  try {
    const companyId = req.user.company_id;
    const {
      page = 1,
      limit = 50,
      search = '',
      category_id,
      brand_id,
      status,
      store_id,
      stock_filter,
    } = req.query;

    const offset = (parseInt(page) - 1) * parseInt(limit);
    const params = [companyId];
    let conditions = ['p.company_id = $1', 'p.is_deleted = false', 'p.parent_id IS NULL'];
    let idx = 2;

    if (search) {
      conditions.push(`(p.name ILIKE $${idx} OR p.article ILIKE $${idx} OR p.barcode ILIKE $${idx})`);
      params.push(`%${search}%`);
      idx++;
    }
    if (category_id) {
      conditions.push(`p.category_id = $${idx}`);
      params.push(parseInt(category_id));
      idx++;
    }
    if (brand_id) {
      conditions.push(`p.brand_id = $${idx}`);
      params.push(parseInt(brand_id));
      idx++;
    }
    if (status) {
      conditions.push(`p.status = $${idx}`);
      params.push(status);
      idx++;
    }

    const whereClause = conditions.join(' AND ');
    const storeJoin = store_id
      ? `LEFT JOIN product_stock ps ON ps.product_id = p.id AND ps.store_id = ${parseInt(store_id)}`
      : `LEFT JOIN product_stock ps ON ps.product_id = p.id`;

    let stockCondition = '';
    if (stock_filter === 'low') {
      stockCondition = 'HAVING COALESCE(SUM(ps.quantity), 0) > 0 AND COALESCE(SUM(ps.quantity), 0) <= 5';
    } else if (stock_filter === 'zero') {
      stockCondition = 'HAVING COALESCE(SUM(ps.quantity), 0) = 0';
    } else if (stock_filter === 'active') {
      stockCondition = 'HAVING COALESCE(SUM(ps.quantity), 0) > 0';
    }

    const countQuery = `
      SELECT COUNT(*) AS total
      FROM products p
      WHERE ${whereClause}
    `;
    const { rows: countRows } = await query(countQuery, params);

    const dataQuery = `
      SELECT
        p.id, p.article, p.name, p.barcode, p.sale_price, p.purchase_price,
        p.wholesale_price, p.status, p.is_variant, p.created_at,
        c.name AS category_name,
        b.name AS brand_name,
        u.abbreviation AS unit_abbr,
        COALESCE(SUM(ps.quantity), 0) AS total_stock,
        pi.url AS image_url,
        (SELECT COUNT(*) FROM products child WHERE child.parent_id = p.id AND child.is_deleted = false) AS variants_count
      FROM products p
      ${storeJoin}
      LEFT JOIN categories c ON c.id = p.category_id
      LEFT JOIN brands b ON b.id = p.brand_id
      LEFT JOIN units_of_measure u ON u.id = p.unit_id
      LEFT JOIN LATERAL (
        SELECT url FROM product_images WHERE product_id = p.id AND is_primary = true LIMIT 1
      ) pi ON true
      WHERE ${whereClause}
      GROUP BY p.id, c.name, b.name, u.abbreviation, pi.url
      ${stockCondition}
      ORDER BY p.id DESC
      LIMIT $${idx} OFFSET $${idx + 1}
    `;

    params.push(parseInt(limit), offset);
    const { rows } = await query(dataQuery, params);

    // Summary stats
    const { rows: stats } = await query(`
      SELECT
        COUNT(DISTINCT p.id) AS total_products,
        COALESCE(SUM(ps.quantity), 0) AS total_units,
        COALESCE(SUM(ps.quantity * p.purchase_price), 0) AS purchase_value,
        COALESCE(SUM(ps.quantity * p.sale_price), 0) AS sale_value
      FROM products p
      LEFT JOIN product_stock ps ON ps.product_id = p.id
      WHERE p.company_id = $1 AND p.is_deleted = false AND p.parent_id IS NULL
    `, [companyId]);

    res.json({
      data: rows,
      pagination: {
        total: parseInt(countRows[0].total),
        page: parseInt(page),
        limit: parseInt(limit),
        pages: Math.ceil(parseInt(countRows[0].total) / parseInt(limit)),
      },
      stats: stats[0],
    });
  } catch (error) {
    console.error('getProducts error:', error.message);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
};

const getProduct = async (req, res) => {
  try {
    const { id } = req.params;
    const companyId = req.user.company_id;

    const { rows } = await query(`
      SELECT
        p.*,
        c.name AS category_name,
        b.name AS brand_name,
        u.name AS unit_name,
        u.abbreviation AS unit_abbr
      FROM products p
      LEFT JOIN categories c ON c.id = p.category_id
      LEFT JOIN brands b ON b.id = p.brand_id
      LEFT JOIN units_of_measure u ON u.id = p.unit_id
      WHERE p.id = $1 AND p.company_id = $2 AND p.is_deleted = false
    `, [id, companyId]);

    if (rows.length === 0) {
      return res.status(404).json({ message: 'Товар не найден' });
    }

    const product = rows[0];

    // Get images
    const { rows: images } = await query(
      'SELECT * FROM product_images WHERE product_id = $1 ORDER BY sort_order',
      [id]
    );

    // Get stock by store
    const { rows: stock } = await query(`
      SELECT ps.*, s.name AS store_name
      FROM product_stock ps
      JOIN stores s ON s.id = ps.store_id
      WHERE ps.product_id = $1
    `, [id]);

    // Get variants if is_variant
    const { rows: variants } = await query(`
      SELECT p2.*, COALESCE(SUM(ps.quantity), 0) AS total_stock
      FROM products p2
      LEFT JOIN product_stock ps ON ps.product_id = p2.id
      WHERE p2.parent_id = $1 AND p2.is_deleted = false
      GROUP BY p2.id
      ORDER BY p2.id
    `, [id]);

    res.json({ ...product, images, stock, variants });
  } catch (error) {
    console.error('getProduct error:', error.message);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
};

const createProduct = async (req, res) => {
  const client = await getClient();
  try {
    await client.query('BEGIN');
    
    const companyId = req.user.company_id;
    const {
      article, name, barcode, category_id, brand_id, unit_id,
      purchase_price, sale_price, wholesale_price, description,
      is_variant, parent_id, status, initial_stock, store_id,
    } = req.body;

    if (!name) {
      return res.status(400).json({ message: 'Название товара обязательно' });
    }

    // Generate article if not provided
    let finalArticle = article;
    if (!finalArticle) {
      const { rows: lastArticle } = await client.query(
        "SELECT article FROM products WHERE company_id = $1 AND article ~ '^[0-9]+$' ORDER BY article::int DESC LIMIT 1",
        [companyId]
      );
      finalArticle = lastArticle.length > 0
        ? String(parseInt(lastArticle[0].article) + 1)
        : '10000';
    }

    const { rows } = await client.query(`
      INSERT INTO products (
        company_id, article, name, barcode, category_id, brand_id, unit_id,
        purchase_price, sale_price, wholesale_price, description,
        is_variant, parent_id, status
      ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)
      RETURNING *
    `, [
      companyId, finalArticle, name, barcode || null,
      category_id || null, brand_id || null, unit_id || null,
      parseFloat(purchase_price) || 0,
      parseFloat(sale_price) || 0,
      parseFloat(wholesale_price) || 0,
      description || null, is_variant || false, parent_id || null, status || 'active',
    ]);

    const product = rows[0];

    // Set initial stock if provided
    if (initial_stock && store_id) {
      await client.query(`
        INSERT INTO product_stock (product_id, store_id, quantity)
        VALUES ($1, $2, $3)
        ON CONFLICT (product_id, store_id) DO UPDATE SET quantity = $3
      `, [product.id, store_id, parseFloat(initial_stock)]);
    } else if (req.user.company_id) {
      // Create stock record for all stores
      const { rows: stores } = await client.query(
        'SELECT id FROM stores WHERE company_id = $1 AND status = $2',
        [companyId, 'active']
      );
      for (const store of stores) {
        await client.query(`
          INSERT INTO product_stock (product_id, store_id, quantity)
          VALUES ($1, $2, 0)
          ON CONFLICT (product_id, store_id) DO NOTHING
        `, [product.id, store.id]);
      }
    }

    await client.query('COMMIT');
    res.status(201).json(product);
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('createProduct error:', error.message);
    res.status(500).json({ message: 'Ошибка создания товара' });
  } finally {
    client.release();
  }
};

const updateProduct = async (req, res) => {
  try {
    const { id } = req.params;
    const companyId = req.user.company_id;
    const {
      article, name, barcode, category_id, brand_id, unit_id,
      purchase_price, sale_price, wholesale_price, description, status,
    } = req.body;

    const { rows } = await query(`
      UPDATE products SET
        article = COALESCE($1, article),
        name = COALESCE($2, name),
        barcode = $3,
        category_id = $4,
        brand_id = $5,
        unit_id = $6,
        purchase_price = COALESCE($7, purchase_price),
        sale_price = COALESCE($8, sale_price),
        wholesale_price = COALESCE($9, wholesale_price),
        description = $10,
        status = COALESCE($11, status),
        updated_at = NOW()
      WHERE id = $12 AND company_id = $13 AND is_deleted = false
      RETURNING *
    `, [
      article, name, barcode || null, category_id || null,
      brand_id || null, unit_id || null,
      purchase_price ? parseFloat(purchase_price) : null,
      sale_price ? parseFloat(sale_price) : null,
      wholesale_price ? parseFloat(wholesale_price) : null,
      description || null, status, id, companyId,
    ]);

    if (rows.length === 0) {
      return res.status(404).json({ message: 'Товар не найден' });
    }

    res.json(rows[0]);
  } catch (error) {
    console.error('updateProduct error:', error.message);
    res.status(500).json({ message: 'Ошибка обновления товара' });
  }
};

const deleteProduct = async (req, res) => {
  try {
    const { id } = req.params;
    const companyId = req.user.company_id;

    const { rows } = await query(
      'UPDATE products SET is_deleted = true, updated_at = NOW() WHERE id = $1 AND company_id = $2 RETURNING id',
      [id, companyId]
    );

    if (rows.length === 0) {
      return res.status(404).json({ message: 'Товар не найден' });
    }

    res.json({ message: 'Товар удалён', id: parseInt(id) });
  } catch (error) {
    console.error('deleteProduct error:', error.message);
    res.status(500).json({ message: 'Ошибка удаления товара' });
  }
};

const updateStock = async (req, res) => {
  try {
    const { id } = req.params;
    const companyId = req.user.company_id;
    const { store_id, quantity } = req.body;

    // Verify product belongs to company
    const { rows: product } = await query(
      'SELECT id FROM products WHERE id = $1 AND company_id = $2',
      [id, companyId]
    );
    if (product.length === 0) {
      return res.status(404).json({ message: 'Товар не найден' });
    }

    const { rows } = await query(`
      INSERT INTO product_stock (product_id, store_id, quantity)
      VALUES ($1, $2, $3)
      ON CONFLICT (product_id, store_id) DO UPDATE SET quantity = $3, updated_at = NOW()
      RETURNING *
    `, [id, store_id, parseFloat(quantity)]);

    res.json(rows[0]);
  } catch (error) {
    console.error('updateStock error:', error.message);
    res.status(500).json({ message: 'Ошибка обновления остатков' });
  }
};

const searchProducts = async (req, res) => {
  try {
    const companyId = req.user.company_id;
    const { q, store_id } = req.query;

    if (!q || q.length < 1) {
      return res.json({ data: [] });
    }

    const storeFilter = store_id
      ? `AND ps.store_id = ${parseInt(store_id)}`
      : '';

    const { rows } = await query(`
      SELECT
        p.id, p.article, p.name, p.barcode, p.sale_price, p.purchase_price,
        p.is_variant,
        u.abbreviation AS unit_abbr,
        pi.url AS image_url,
        COALESCE(ps.quantity, 0) AS stock
      FROM products p
      LEFT JOIN product_stock ps ON ps.product_id = p.id ${storeFilter}
      LEFT JOIN units_of_measure u ON u.id = p.unit_id
      LEFT JOIN LATERAL (
        SELECT url FROM product_images WHERE product_id = p.id AND is_primary = true LIMIT 1
      ) pi ON true
      WHERE p.company_id = $1
        AND p.is_deleted = false
        AND p.status = 'active'
        AND p.parent_id IS NULL
        AND (p.name ILIKE $2 OR p.article ILIKE $2 OR p.barcode = $3)
      LIMIT 20
    `, [companyId, `%${q}%`, q]);

    res.json({ data: rows });
  } catch (error) {
    console.error('searchProducts error:', error.message);
    res.status(500).json({ message: 'Ошибка поиска' });
  }
};

module.exports = {
  getProducts,
  getProduct,
  createProduct,
  updateProduct,
  deleteProduct,
  updateStock,
  searchProducts,
};
