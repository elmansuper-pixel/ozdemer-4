const { query, getClient } = require('../config/database');

const getShifts = async (req, res) => {
  try {
    const companyId = req.user.company_id;
    const { page = 1, limit = 10, date_from, date_to, store_id, status } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);

    const params = [companyId];
    let conditions = ['st.company_id = $1'];
    let idx = 2;

    if (date_from) { conditions.push(`cs.opened_at >= $${idx}`); params.push(date_from); idx++; }
    if (date_to) { conditions.push(`cs.opened_at < $${idx}::date + interval '1 day'`); params.push(date_to); idx++; }
    if (store_id) { conditions.push(`cs.store_id = $${idx}`); params.push(parseInt(store_id)); idx++; }
    if (status) { conditions.push(`cs.status = $${idx}`); params.push(status); idx++; }

    const where = conditions.join(' AND ');

    const { rows: countRows } = await query(
      `SELECT COUNT(*) FROM cash_shifts cs JOIN stores st ON st.id = cs.store_id WHERE ${where}`,
      params
    );

    const { rows } = await query(`
      SELECT
        cs.*,
        st.name AS store_name,
        u.first_name || ' ' || u.last_name AS cashier_name
      FROM cash_shifts cs
      JOIN stores st ON st.id = cs.store_id
      JOIN users u ON u.id = cs.cashier_id
      WHERE ${where}
      ORDER BY cs.opened_at DESC
      LIMIT $${idx} OFFSET $${idx + 1}
    `, [...params, parseInt(limit), offset]);

    // Summary
    const { rows: stats } = await query(`
      SELECT
        COALESCE(SUM(CASE WHEN cs.status = 'open' THEN cs.opening_amount ELSE 0 END), 0) AS cash_in_register,
        0 AS deficit,
        COUNT(*) FILTER (WHERE cs.opened_at >= $2 AND cs.opened_at < $3::date + interval '1 day') AS shifts_count,
        BOOL_OR(cs.status = 'open') AS has_open_shift
      FROM cash_shifts cs
      JOIN stores st ON st.id = cs.store_id
      WHERE st.company_id = $1
    `, [companyId, date_from || '2000-01-01', date_to || new Date().toISOString().slice(0, 10)]);

    res.json({
      data: rows,
      pagination: {
        total: parseInt(countRows[0].count),
        page: parseInt(page),
        limit: parseInt(limit),
      },
      stats: stats[0],
    });
  } catch (error) {
    console.error('getShifts error:', error.message);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
};

const openShift = async (req, res) => {
  try {
    const companyId = req.user.company_id;
    const { store_id, opening_amount, register_id } = req.body;

    if (!store_id) return res.status(400).json({ message: 'Магазин обязателен' });

    // Check for already open shift
    const { rows: existing } = await query(`
      SELECT cs.id FROM cash_shifts cs
      JOIN stores st ON st.id = cs.store_id
      WHERE st.company_id = $1 AND cs.store_id = $2 AND cs.status = 'open'
    `, [companyId, store_id]);

    if (existing.length > 0) {
      return res.status(400).json({ message: 'Смена уже открыта' });
    }

    const date = new Date();
    const shiftNumber = `SHIFT-${date.getFullYear()}${String(date.getMonth()+1).padStart(2,'0')}${String(date.getDate()).padStart(2,'0')}-${Date.now().toString().slice(-5)}`;

    const { rows } = await query(`
      INSERT INTO cash_shifts (shift_number, store_id, cashier_id, register_id, status, opening_amount)
      VALUES ($1, $2, $3, $4, 'open', $5)
      RETURNING *
    `, [shiftNumber, store_id, req.user.id, register_id || null, parseFloat(opening_amount) || 0]);

    res.status(201).json(rows[0]);
  } catch (error) {
    console.error('openShift error:', error.message);
    res.status(500).json({ message: 'Ошибка открытия смены' });
  }
};

const closeShift = async (req, res) => {
  const client = await getClient();
  try {
    await client.query('BEGIN');

    const { id } = req.params;
    const companyId = req.user.company_id;
    const { closing_amount } = req.body;

    const { rows: shifts } = await client.query(`
      SELECT cs.* FROM cash_shifts cs
      JOIN stores st ON st.id = cs.store_id
      WHERE cs.id = $1 AND st.company_id = $2 AND cs.status = 'open'
    `, [id, companyId]);

    if (shifts.length === 0) {
      return res.status(404).json({ message: 'Открытая смена не найдена' });
    }

    const shift = shifts[0];
    const closingAmt = parseFloat(closing_amount || 0);

    // Calculate expected amount (opening + revenue - expenses)
    const { rows: ops } = await client.query(`
      SELECT
        COALESCE(SUM(amount) FILTER (WHERE type = 'income'), 0) AS income,
        COALESCE(SUM(amount) FILTER (WHERE type = 'expense'), 0) AS expense
      FROM cash_register_operations
      WHERE shift_id = $1
    `, [id]);

    const expectedAmount = parseFloat(shift.opening_amount) +
      parseFloat(ops[0].income) - parseFloat(ops[0].expense) +
      parseFloat(shift.revenue || 0);

    const discrepancy = closingAmt - expectedAmount;

    const { rows } = await client.query(`
      UPDATE cash_shifts SET
        status = 'closed',
        closing_amount = $1,
        expected_amount = $2,
        discrepancy = $3,
        closed_at = NOW()
      WHERE id = $4
      RETURNING *
    `, [closingAmt, expectedAmount, discrepancy, id]);

    await client.query('COMMIT');
    res.json(rows[0]);
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('closeShift error:', error.message);
    res.status(500).json({ message: 'Ошибка закрытия смены' });
  } finally {
    client.release();
  }
};

const getCurrentShift = async (req, res) => {
  try {
    const companyId = req.user.company_id;
    const { store_id } = req.query;

    const params = [companyId];
    let storeFilter = '';
    if (store_id) {
      storeFilter = 'AND cs.store_id = $2';
      params.push(parseInt(store_id));
    }

    const { rows } = await query(`
      SELECT cs.*, st.name AS store_name, u.first_name || ' ' || u.last_name AS cashier_name
      FROM cash_shifts cs
      JOIN stores st ON st.id = cs.store_id
      JOIN users u ON u.id = cs.cashier_id
      WHERE st.company_id = $1 ${storeFilter} AND cs.status = 'open'
      ORDER BY cs.opened_at DESC
      LIMIT 1
    `, params);

    res.json(rows[0] || null);
  } catch (error) {
    console.error('getCurrentShift error:', error.message);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
};

module.exports = { getShifts, openShift, closeShift, getCurrentShift };
