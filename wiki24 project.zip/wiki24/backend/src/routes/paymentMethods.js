const express = require('express');
const router = express.Router();
const { query } = require('../config/database');
const { authenticate, requireCompany } = require('../middleware/auth');

router.use(authenticate, requireCompany);

router.get('/', async (req, res) => {
  try {
    const { rows } = await query(
      'SELECT * FROM payment_methods WHERE company_id=$1 ORDER BY sort_order, id',
      [req.user.company_id]
    );
    res.json({ data: rows });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.post('/', async (req, res) => {
  try {
    const { name, icon, is_active } = req.body;
    if (!name) return res.status(400).json({ message: 'Название обязательно' });
    const { rows } = await query(
      'INSERT INTO payment_methods (company_id, name, icon, type, is_active) VALUES ($1,$2,$3,\'custom\',$4) RETURNING *',
      [req.user.company_id, name, icon||'card', is_active??true]
    );
    res.status(201).json(rows[0]);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.put('/:id', async (req, res) => {
  try {
    const { name, icon, is_active, sort_order } = req.body;
    const { rows } = await query(
      'UPDATE payment_methods SET name=COALESCE($1,name), icon=COALESCE($2,icon), is_active=COALESCE($3,is_active), sort_order=COALESCE($4,sort_order) WHERE id=$5 AND company_id=$6 RETURNING *',
      [name, icon, is_active, sort_order, req.params.id, req.user.company_id]
    );
    if (!rows.length) return res.status(404).json({ message: 'Не найдено' });
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.delete('/:id', async (req, res) => {
  try {
    await query('DELETE FROM payment_methods WHERE id=$1 AND company_id=$2', [req.params.id, req.user.company_id]);
    res.json({ message: 'Удалено', id: parseInt(req.params.id) });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

module.exports = router;
