const express = require('express');
const router = express.Router();
const { authenticate, requireCompany } = require('../middleware/auth');

router.use(authenticate, requireCompany);

router.post('/products', async (req, res) => {
  res.json({ message: 'Импорт товаров — функция в разработке', imported: 0 });
});

module.exports = router;
