const express = require('express');
const router = express.Router();
const { query } = require('../config/database');
const { authenticate, requireCompany } = require('../middleware/auth');

router.use(authenticate, requireCompany);

router.get('/', async (req, res) => {
  try {
    const cid = req.user.company_id;
    const { search, has_debt, archived } = req.query;
    const params = [cid];
    let cond = ['company_id = $1'];
    let idx = 2;
    
    cond.push(`is_archived = ${archived === 'true'}`);
    
    if (search) { cond.push(`name ILIKE $${idx}`); params.push(`%${search}%`); idx++; }
    if (has_debt === 'true') { cond.push('balance < 0'); }

    const { rows } = await query(`
      SELECT s.*,
        (SELECT COUNT(*) FROM purchase_orders WHERE supplier_id = s.id) AS orders_count
      FROM suppliers s
      WHERE ${cond.join(' AND ')}
      ORDER BY s.name
    `, params);

    const { rows: stats } = await query(`
      SELECT COUNT(*) AS total, COALESCE(SUM(CASE WHEN balance < 0 THEN ABS(balance) ELSE 0 END),0) AS total_debt,
        COALESCE(SUM(po.total),0) AS total_orders, COALESCE(SUM(po.paid_amount),0) AS total_paid
      FROM suppliers s
      LEFT JOIN purchase_orders po ON po.supplier_id = s.id
      WHERE s.company_id = $1 AND s.is_archived = false
    `, [cid]);

    res.json({ data: rows, stats: stats[0] });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.post('/', async (req, res) => {
  try {
    const { name, phone, email, address } = req.body;
    if (!name) return res.status(400).json({ message: 'Название обязательно' });
    const { rows } = await query(
      'INSERT INTO suppliers (company_id, name, phone, email, address) VALUES ($1,$2,$3,$4,$5) RETURNING *',
      [req.user.company_id, name, phone || null, email || null, address || null]
    );
    res.status(201).json(rows[0]);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.put('/:id', async (req, res) => {
  try {
    const { name, phone, email, address } = req.body;
    const { rows } = await query(
      'UPDATE suppliers SET name=COALESCE($1,name), phone=$2, email=$3, address=$4, updated_at=NOW() WHERE id=$5 AND company_id=$6 RETURNING *',
      [name, phone || null, email || null, address || null, req.params.id, req.user.company_id]
    );
    if (!rows.length) return res.status(404).json({ message: 'Не найдено' });
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.delete('/:id', async (req, res) => {
  try {
    await query('UPDATE suppliers SET is_archived = true WHERE id=$1 AND company_id=$2', [req.params.id, req.user.company_id]);
    res.json({ message: 'Архивирован', id: parseInt(req.params.id) });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

module.exports = router;
