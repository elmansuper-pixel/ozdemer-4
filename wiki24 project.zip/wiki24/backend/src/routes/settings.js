const express = require('express');
const router = express.Router();
const { query } = require('../config/database');
const { authenticate, requireCompany } = require('../middleware/auth');
const upload = require('../middleware/upload');

router.use(authenticate, requireCompany);

// Get company settings
router.get('/company', async (req, res) => {
  try {
    const { rows } = await query('SELECT * FROM companies WHERE id=$1', [req.user.company_id]);
    if (!rows.length) return res.status(404).json({ message: 'Компания не найдена' });
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.put('/company', async (req, res) => {
  try {
    const {
      name, legal_name, bin_inn, legal_address, physical_address,
      country, region, postal_code, timezone, public_email, phone,
      subdomain, base_currency, sales_currency
    } = req.body;

    const { rows } = await query(`
      UPDATE companies SET
        name = COALESCE($1, name),
        legal_name = $2,
        bin_inn = $3,
        legal_address = $4,
        physical_address = $5,
        country = COALESCE($6, country),
        region = $7,
        postal_code = $8,
        timezone = COALESCE($9, timezone),
        public_email = $10,
        phone = $11,
        subdomain = $12,
        base_currency = COALESCE($13, base_currency),
        sales_currency = COALESCE($14, sales_currency),
        updated_at = NOW()
      WHERE id = $15
      RETURNING *
    `, [name, legal_name||null, bin_inn||null, legal_address||null, physical_address||null,
        country, region||null, postal_code||null, timezone, public_email||null,
        phone||null, subdomain||null, base_currency, sales_currency, req.user.company_id]);

    res.json(rows[0]);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// Upload company logo
router.post('/company/logo', upload.single('logo'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ message: 'Файл не загружен' });
    const url = `/uploads/logos/${req.file.filename}`;
    await query('UPDATE companies SET logo_url=$1, updated_at=NOW() WHERE id=$2', [url, req.user.company_id]);
    res.json({ url });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// Catalog settings
router.get('/catalog', async (req, res) => {
  try {
    const { rows } = await query('SELECT * FROM catalog_settings WHERE company_id=$1', [req.user.company_id]);
    res.json(rows[0] || {});
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.put('/catalog', async (req, res) => {
  try {
    const {
      wholesale_price_enabled, low_stock_warning, quick_add_enabled,
      negative_margin_allowed, free_price_enabled, sell_at_zero_stock,
      quick_discount_1, quick_discount_2, quick_discount_3, quick_discount_4, card_fields
    } = req.body;

    const { rows } = await query(`
      INSERT INTO catalog_settings (company_id, wholesale_price_enabled, low_stock_warning,
        quick_add_enabled, negative_margin_allowed, free_price_enabled, sell_at_zero_stock,
        quick_discount_1, quick_discount_2, quick_discount_3, quick_discount_4, card_fields)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
      ON CONFLICT (company_id) DO UPDATE SET
        wholesale_price_enabled=EXCLUDED.wholesale_price_enabled,
        low_stock_warning=EXCLUDED.low_stock_warning,
        quick_add_enabled=EXCLUDED.quick_add_enabled,
        negative_margin_allowed=EXCLUDED.negative_margin_allowed,
        free_price_enabled=EXCLUDED.free_price_enabled,
        sell_at_zero_stock=EXCLUDED.sell_at_zero_stock,
        quick_discount_1=EXCLUDED.quick_discount_1,
        quick_discount_2=EXCLUDED.quick_discount_2,
        quick_discount_3=EXCLUDED.quick_discount_3,
        quick_discount_4=EXCLUDED.quick_discount_4,
        card_fields=EXCLUDED.card_fields,
        updated_at=NOW()
      RETURNING *
    `, [req.user.company_id, wholesale_price_enabled??false, low_stock_warning??false,
        quick_add_enabled??false, negative_margin_allowed??false, free_price_enabled??false,
        sell_at_zero_stock??true,
        quick_discount_1??10, quick_discount_2??20, quick_discount_3??30, quick_discount_4??50,
        JSON.stringify(card_fields||[])]);

    res.json(rows[0]);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// Receipt settings
router.get('/receipt/:storeId', async (req, res) => {
  try {
    const { rows } = await query(
      'SELECT rs.* FROM receipt_settings rs JOIN stores st ON st.id = rs.store_id WHERE rs.store_id=$1 AND st.company_id=$2',
      [req.params.storeId, req.user.company_id]
    );
    res.json(rows[0] || {});
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.put('/receipt/:storeId', async (req, res) => {
  try {
    const {
      tape_width, show_logo, show_store_info, show_store_name,
      show_address, show_contacts, show_schedule, footer_text
    } = req.body;

    const { rows } = await query(`
      INSERT INTO receipt_settings (store_id, tape_width, show_logo, show_store_info,
        show_store_name, show_address, show_contacts, show_schedule, footer_text)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
      ON CONFLICT (store_id) DO UPDATE SET
        tape_width=EXCLUDED.tape_width, show_logo=EXCLUDED.show_logo,
        show_store_info=EXCLUDED.show_store_info, show_store_name=EXCLUDED.show_store_name,
        show_address=EXCLUDED.show_address, show_contacts=EXCLUDED.show_contacts,
        show_schedule=EXCLUDED.show_schedule, footer_text=EXCLUDED.footer_text,
        updated_at=NOW()
      RETURNING *
    `, [req.params.storeId, tape_width||'80mm', show_logo??false,
        show_store_info??true, show_store_name??true, show_address??true,
        show_contacts??true, show_schedule??false, footer_text||'СПАСИБО ЗА ПОКУПКУ!']);

    res.json(rows[0]);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// Subscription
router.get('/subscription', async (req, res) => {
  try {
    const { rows } = await query(`
      SELECT cs.*, sp.name AS plan_name, sp.price_monthly, sp.stores_limit,
             sp.employees_limit, sp.customers_limit, sp.products_limit
      FROM company_subscriptions cs
      JOIN subscription_plans sp ON sp.id = cs.plan_id
      WHERE cs.company_id = $1 AND cs.status = 'active'
      ORDER BY cs.id DESC LIMIT 1
    `, [req.user.company_id]);

    const { rows: plans } = await query('SELECT * FROM subscription_plans WHERE is_active=true ORDER BY price_monthly');

    res.json({ subscription: rows[0] || null, plans });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// Product attributes
router.get('/attributes', async (req, res) => {
  try {
    const { rows } = await query(
      'SELECT * FROM product_attributes WHERE company_id=$1 ORDER BY sort_order, id',
      [req.user.company_id]
    );
    res.json({ data: rows });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.post('/attributes', async (req, res) => {
  try {
    const { name, field_type, is_visible } = req.body;
    if (!name) return res.status(400).json({ message: 'Название обязательно' });
    const { rows } = await query(
      'INSERT INTO product_attributes (company_id, name, field_type, type, is_visible) VALUES ($1,$2,$3,\'custom\',$4) RETURNING *',
      [req.user.company_id, name, field_type||'text', is_visible??true]
    );
    res.status(201).json(rows[0]);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.put('/attributes/:id', async (req, res) => {
  try {
    const { is_visible } = req.body;
    const { rows } = await query(
      'UPDATE product_attributes SET is_visible=$1 WHERE id=$2 AND company_id=$3 RETURNING *',
      [is_visible, req.params.id, req.user.company_id]
    );
    if (!rows.length) return res.status(404).json({ message: 'Не найдено' });
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// Bank accounts
router.get('/bank-accounts', async (req, res) => {
  try {
    const { rows } = await query('SELECT * FROM bank_accounts WHERE company_id=$1', [req.user.company_id]);
    res.json({ data: rows });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.post('/bank-accounts', async (req, res) => {
  try {
    const { bank_name, account_no, bik } = req.body;
    const { rows } = await query(
      'INSERT INTO bank_accounts (company_id, bank_name, account_no, bik) VALUES ($1,$2,$3,$4) RETURNING *',
      [req.user.company_id, bank_name||null, account_no||null, bik||null]
    );
    res.status(201).json(rows[0]);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.delete('/bank-accounts/:id', async (req, res) => {
  try {
    await query('DELETE FROM bank_accounts WHERE id=$1 AND company_id=$2', [req.params.id, req.user.company_id]);
    res.json({ message: 'Удалено' });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

module.exports = router;
