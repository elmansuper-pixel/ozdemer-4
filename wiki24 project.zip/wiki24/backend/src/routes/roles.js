const express = require('express');
const router = express.Router();
const { query } = require('../config/database');
const { authenticate, requireCompany } = require('../middleware/auth');

router.use(authenticate, requireCompany);

router.get('/', async (req, res) => {
  try {
    const { deleted } = req.query;
    const { rows } = await query(
      `SELECT r.*,
        (SELECT COUNT(*) FROM store_employees WHERE role_id = r.id) AS employees_count
       FROM roles r
       WHERE r.company_id = $1 AND r.is_deleted = $2
       ORDER BY r.id`,
      [req.user.company_id, deleted === 'true']
    );
    res.json({ data: rows });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.post('/', async (req, res) => {
  try {
    const { name, description } = req.body;
    if (!name) return res.status(400).json({ message: 'Название обязательно' });
    const { rows } = await query(
      'INSERT INTO roles (company_id, name, description) VALUES ($1,$2,$3) RETURNING *',
      [req.user.company_id, name, description || null]
    );
    res.status(201).json(rows[0]);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.put('/:id', async (req, res) => {
  try {
    const { name, description } = req.body;
    const { rows } = await query(
      'UPDATE roles SET name=COALESCE($1,name), description=$2 WHERE id=$3 AND company_id=$4 AND is_system=false RETURNING *',
      [name, description || null, req.params.id, req.user.company_id]
    );
    if (!rows.length) return res.status(404).json({ message: 'Не найдено или системная роль' });
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.delete('/:id', async (req, res) => {
  try {
    const { rows } = await query(
      'UPDATE roles SET is_deleted=true WHERE id=$1 AND company_id=$2 AND is_system=false RETURNING id',
      [req.params.id, req.user.company_id]
    );
    if (!rows.length) return res.status(404).json({ message: 'Не найдено или системная роль' });
    res.json({ message: 'Удалено', id: parseInt(req.params.id) });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

module.exports = router;
