const express = require('express');
const router = express.Router();
const { getShifts, openShift, closeShift, getCurrentShift } = require('../controllers/shiftsController');
const { authenticate, requireCompany } = require('../middleware/auth');

router.use(authenticate, requireCompany);

router.get('/current', getCurrentShift);
router.get('/', getShifts);
router.post('/', openShift);
router.put('/:id/close', closeShift);

module.exports = router;
