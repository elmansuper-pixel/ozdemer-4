const express = require('express');
const router = express.Router();
const { query, getClient } = require('../config/database');
const { authenticate, requireCompany } = require('../middleware/auth');

router.use(authenticate, requireCompany);

// ─── CATEGORIES ────────────────────────────────────────────
router.get('/', async (req, res) => {
  try {
    const { search } = req.query;
    let conditions = ['company_id = $1'];
    const params = [req.user.company_id];
    let idx = 2;
    if (search) { conditions.push(`name ILIKE $${idx}`); params.push(`%${search}%`); idx++; }

    const { rows } = await query(`
      SELECT c.*,
        (SELECT COUNT(*) FROM products WHERE category_id = c.id AND is_deleted = false) AS products_count
      FROM categories c
      WHERE ${conditions.join(' AND ')}
      ORDER BY c.sort_order, c.name
    `, params);
    res.json({ data: rows });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.post('/', async (req, res) => {
  try {
    const { name, parent_id, status } = req.body;
    if (!name) return res.status(400).json({ message: 'Название обязательно' });
    const { rows } = await query(
      'INSERT INTO categories (company_id, name, parent_id, status) VALUES ($1,$2,$3,$4) RETURNING *',
      [req.user.company_id, name, parent_id || null, status || 'active']
    );
    res.status(201).json(rows[0]);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.put('/:id', async (req, res) => {
  try {
    const { name, parent_id, status } = req.body;
    const { rows } = await query(
      'UPDATE categories SET name = COALESCE($1,name), parent_id = $2, status = COALESCE($3,status) WHERE id = $4 AND company_id = $5 RETURNING *',
      [name, parent_id || null, status, req.params.id, req.user.company_id]
    );
    if (!rows.length) return res.status(404).json({ message: 'Не найдено' });
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.delete('/:id', async (req, res) => {
  try {
    await query('DELETE FROM categories WHERE id = $1 AND company_id = $2', [req.params.id, req.user.company_id]);
    res.json({ message: 'Удалено', id: parseInt(req.params.id) });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

module.exports = router;
