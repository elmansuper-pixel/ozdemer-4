const express = require('express');
const router = express.Router();
const { getSales, getSale, createSale, createRefund } = require('../controllers/salesController');
const { authenticate, requireCompany } = require('../middleware/auth');

router.use(authenticate, requireCompany);

router.get('/', getSales);
router.get('/:id', getSale);
router.post('/', createSale);
router.post('/:id/refund', createRefund);

module.exports = router;
