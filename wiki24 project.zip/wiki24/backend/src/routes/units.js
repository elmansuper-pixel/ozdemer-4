const express = require('express');
const router = express.Router();
const { query } = require('../config/database');
const { authenticate, requireCompany } = require('../middleware/auth');

router.use(authenticate, requireCompany);

router.get('/', async (req, res) => {
  try {
    const { rows } = await query(
      'SELECT * FROM units_of_measure WHERE company_id = $1 OR company_id IS NULL ORDER BY type DESC, name',
      [req.user.company_id]
    );
    res.json({ data: rows });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.post('/', async (req, res) => {
  try {
    const { name, abbreviation, precision } = req.body;
    if (!name || !abbreviation) return res.status(400).json({ message: 'Название и сокращение обязательны' });
    const { rows } = await query(
      'INSERT INTO units_of_measure (company_id, name, abbreviation, precision, type) VALUES ($1,$2,$3,$4,$5) RETURNING *',
      [req.user.company_id, name, abbreviation, parseInt(precision) || 0, 'custom']
    );
    res.status(201).json(rows[0]);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.put('/:id', async (req, res) => {
  try {
    const { name, abbreviation, precision } = req.body;
    const { rows } = await query(
      'UPDATE units_of_measure SET name=COALESCE($1,name), abbreviation=COALESCE($2,abbreviation), precision=COALESCE($3,precision) WHERE id=$4 AND company_id=$5 AND type=\'custom\' RETURNING *',
      [name, abbreviation, precision !== undefined ? parseInt(precision) : null, req.params.id, req.user.company_id]
    );
    if (!rows.length) return res.status(404).json({ message: 'Не найдено или системная единица' });
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.delete('/:id', async (req, res) => {
  try {
    const { rows } = await query(
      "DELETE FROM units_of_measure WHERE id=$1 AND company_id=$2 AND type='custom' RETURNING id",
      [req.params.id, req.user.company_id]
    );
    if (!rows.length) return res.status(404).json({ message: 'Не найдено' });
    res.json({ message: 'Удалено', id: parseInt(req.params.id) });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

module.exports = router;
