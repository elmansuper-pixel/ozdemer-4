const express = require('express');
const router = express.Router();
const { query } = require('../config/database');
const bcrypt = require('bcryptjs');
const { authenticate } = require('../middleware/auth');
const upload = require('../middleware/upload');

router.use(authenticate);

router.get('/', async (req, res) => {
  try {
    const { rows } = await query(
      'SELECT id, email, first_name, last_name, phone, avatar_url, role, theme, language FROM users WHERE id=$1',
      [req.user.id]
    );
    if (!rows.length) return res.status(404).json({ message: 'Не найдено' });
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.put('/', async (req, res) => {
  try {
    const { first_name, last_name, phone, theme, language } = req.body;
    const { rows } = await query(
      'UPDATE users SET first_name=COALESCE($1,first_name), last_name=COALESCE($2,last_name), phone=$3, theme=COALESCE($4,theme), language=COALESCE($5,language), updated_at=NOW() WHERE id=$6 RETURNING id, email, first_name, last_name, phone, avatar_url, role, theme, language',
      [first_name, last_name, phone||null, theme, language, req.user.id]
    );
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.put('/password', async (req, res) => {
  try {
    const { current_password, new_password } = req.body;
    if (!current_password || !new_password) {
      return res.status(400).json({ message: 'Текущий и новый пароль обязательны' });
    }
    if (new_password.length < 8) {
      return res.status(400).json({ message: 'Пароль должен быть не менее 8 символов' });
    }

    const { rows } = await query('SELECT password FROM users WHERE id=$1', [req.user.id]);
    const valid = await bcrypt.compare(current_password, rows[0].password);
    if (!valid) return res.status(400).json({ message: 'Неверный текущий пароль' });

    const hashed = await bcrypt.hash(new_password, 12);
    await query('UPDATE users SET password=$1, updated_at=NOW() WHERE id=$2', [hashed, req.user.id]);

    res.json({ message: 'Пароль изменён' });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.post('/avatar', upload.single('avatar'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ message: 'Файл не загружен' });
    const url = `/uploads/logos/${req.file.filename}`;
    await query('UPDATE users SET avatar_url=$1 WHERE id=$2', [url, req.user.id]);
    res.json({ url });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.delete('/avatar', async (req, res) => {
  try {
    await query('UPDATE users SET avatar_url=NULL WHERE id=$1', [req.user.id]);
    res.json({ message: 'Аватар удалён' });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

module.exports = router;
