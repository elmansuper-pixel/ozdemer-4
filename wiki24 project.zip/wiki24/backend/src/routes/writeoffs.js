const express = require('express');
const router = express.Router();
const { query, getClient } = require('../config/database');
const { authenticate, requireCompany } = require('../middleware/auth');

router.use(authenticate, requireCompany);

router.get('/', async (req, res) => {
  try {
    const { page=1, limit=20, search, store_id } = req.query;
    const offset = (parseInt(page)-1)*parseInt(limit);
    const params = [req.user.company_id];
    let cond = ['w.company_id = $1'];
    let idx = 2;
    if (search) { cond.push(`w.writeoff_number ILIKE $${idx}`); params.push(`%${search}%`); idx++; }
    if (store_id) { cond.push(`w.store_id = $${idx}`); params.push(parseInt(store_id)); idx++; }

    const { rows } = await query(`
      SELECT w.*, st.name AS store_name
      FROM writeoffs w JOIN stores st ON st.id = w.store_id
      WHERE ${cond.join(' AND ')}
      ORDER BY w.created_at DESC LIMIT $${idx} OFFSET $${idx+1}
    `, [...params, parseInt(limit), offset]);
    res.json({ data: rows });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.post('/', async (req, res) => {
  const client = await getClient();
  try {
    await client.query('BEGIN');
    const cid = req.user.company_id;
    const { store_id, items, type, note } = req.body;
    if (!store_id || !items?.length) return res.status(400).json({ message: 'Магазин и товары обязательны' });

    const num = `СПИС-${String(Date.now()).slice(-4).padStart(4,'0')}`;
    let totalQty = 0, totalAmount = 0;
    const { rows: wo } = await client.query(
      'INSERT INTO writeoffs (company_id, store_id, writeoff_number, type, note, created_by) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *',
      [cid, store_id, num, type||'defect', note||null, req.user.id]
    );

    for (const item of items) {
      const qty = parseFloat(item.quantity);
      const { rows: prod } = await client.query('SELECT name, purchase_price FROM products WHERE id=$1', [item.product_id]);
      const unitPrice = parseFloat(item.unit_price || prod[0]?.purchase_price || 0);
      const total = qty * unitPrice;
      totalQty += qty;
      totalAmount += total;

      await client.query(
        'INSERT INTO writeoff_items (writeoff_id, product_id, product_name, quantity, unit_price, total_amount) VALUES ($1,$2,$3,$4,$5,$6)',
        [wo[0].id, item.product_id, prod[0]?.name||'', qty, unitPrice, total]
      );
      await client.query(
        'UPDATE product_stock SET quantity = GREATEST(0, quantity - $1) WHERE product_id = $2 AND store_id = $3',
        [qty, item.product_id, store_id]
      );
    }

    const { rows } = await client.query(
      'UPDATE writeoffs SET total_qty=$1, total_amount=$2, status=\'completed\' WHERE id=$3 RETURNING *',
      [totalQty, totalAmount, wo[0].id]
    );
    await client.query('COMMIT');
    res.status(201).json(rows[0]);
  } catch (e) {
    await client.query('ROLLBACK');
    res.status(500).json({ message: e.message });
  } finally { client.release(); }
});

module.exports = router;
