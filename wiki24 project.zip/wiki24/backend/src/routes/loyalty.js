const express = require('express');
const router = express.Router();
const { query } = require('../config/database');
const { authenticate, requireCompany } = require('../middleware/auth');

router.use(authenticate, requireCompany);

router.get('/', async (req, res) => {
  try {
    const { rows: program } = await query(
      'SELECT * FROM loyalty_programs WHERE company_id=$1',
      [req.user.company_id]
    );
    const programData = program[0] || null;
    let levels = [];
    if (programData) {
      const { rows } = await query(
        'SELECT * FROM loyalty_levels WHERE program_id=$1 ORDER BY min_amount',
        [programData.id]
      );
      levels = rows;
    }
    res.json({ program: programData, levels });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.put('/', async (req, res) => {
  try {
    const { type, is_active, levels } = req.body;
    const { rows: existing } = await query(
      'SELECT id FROM loyalty_programs WHERE company_id=$1',
      [req.user.company_id]
    );

    let programId;
    if (existing.length > 0) {
      await query(
        'UPDATE loyalty_programs SET type=COALESCE($1,type), is_active=COALESCE($2,is_active), updated_at=NOW() WHERE company_id=$3',
        [type, is_active, req.user.company_id]
      );
      programId = existing[0].id;
    } else {
      const { rows } = await query(
        'INSERT INTO loyalty_programs (company_id, type, is_active) VALUES ($1,$2,$3) RETURNING id',
        [req.user.company_id, type||'discount', is_active??true]
      );
      programId = rows[0].id;
    }

    if (levels && Array.isArray(levels)) {
      await query('DELETE FROM loyalty_levels WHERE program_id=$1', [programId]);
      for (const level of levels) {
        await query(
          'INSERT INTO loyalty_levels (program_id, name, min_amount, discount_percent, bonus_percent, sort_order) VALUES ($1,$2,$3,$4,$5,$6)',
          [programId, level.name, level.min_amount||0, level.discount_percent||0, level.bonus_percent||0, level.sort_order||0]
        );
      }
    }

    res.json({ message: 'Обновлено' });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

module.exports = router;
