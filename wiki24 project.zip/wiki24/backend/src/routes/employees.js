const express = require('express');
const router = express.Router();
const { query } = require('../config/database');
const bcrypt = require('bcryptjs');
const { authenticate, requireCompany } = require('../middleware/auth');

router.use(authenticate, requireCompany);

router.get('/', async (req, res) => {
  try {
    const cid = req.user.company_id;
    const { status, role_id, store_id } = req.query;
    const params = [cid];
    let cond = ['u.company_id = $1'];
    let idx = 2;
    if (status === 'blocked') { cond.push('u.is_active = false'); }
    else { cond.push('u.is_active = true'); }
    if (role_id) { cond.push(`se.role_id = $${idx}`); params.push(parseInt(role_id)); idx++; }
    if (store_id) { cond.push(`se.store_id = $${idx}`); params.push(parseInt(store_id)); idx++; }

    const { rows } = await query(`
      SELECT DISTINCT u.id, u.first_name, u.last_name, u.email, u.phone, u.role, u.is_active, u.created_at,
        r.name AS role_name,
        STRING_AGG(DISTINCT st.name, ', ') AS stores
      FROM users u
      LEFT JOIN store_employees se ON se.user_id = u.id
      LEFT JOIN stores st ON st.id = se.store_id
      LEFT JOIN roles r ON r.id = se.role_id
      WHERE ${cond.join(' AND ')}
      GROUP BY u.id, r.name
      ORDER BY u.id DESC
    `, params);

    res.json({ data: rows, total: rows.length });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.post('/', async (req, res) => {
  try {
    const cid = req.user.company_id;
    const { first_name, last_name, email, phone, password, role_id, store_id } = req.body;
    if (!first_name || !email || !password) {
      return res.status(400).json({ message: 'Имя, email и пароль обязательны' });
    }

    const hashedPassword = await bcrypt.hash(password, 12);
    const { rows } = await query(`
      INSERT INTO users (email, password, first_name, last_name, phone, role, company_id)
      VALUES ($1,$2,$3,$4,$5,'cashier',$6) RETURNING id, email, first_name, last_name, phone
    `, [email.toLowerCase().trim(), hashedPassword, first_name, last_name||'', phone||null, cid]);

    if (store_id && role_id) {
      await query(
        'INSERT INTO store_employees (store_id, user_id, role_id, status) VALUES ($1,$2,$3,\'active\')',
        [store_id, rows[0].id, role_id]
      );
    }

    res.status(201).json(rows[0]);
  } catch (e) {
    if (e.code === '23505') return res.status(400).json({ message: 'Email уже используется' });
    res.status(500).json({ message: e.message });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const { first_name, last_name, phone, is_active } = req.body;
    const { rows } = await query(
      'UPDATE users SET first_name=COALESCE($1,first_name), last_name=COALESCE($2,last_name), phone=$3, is_active=COALESCE($4,is_active), updated_at=NOW() WHERE id=$5 AND company_id=$6 RETURNING id, first_name, last_name, email, phone, is_active',
      [first_name, last_name, phone||null, is_active, req.params.id, req.user.company_id]
    );
    if (!rows.length) return res.status(404).json({ message: 'Не найдено' });
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.delete('/:id', async (req, res) => {
  try {
    if (parseInt(req.params.id) === req.user.id) {
      return res.status(400).json({ message: 'Нельзя удалить себя' });
    }
    await query('UPDATE users SET is_active=false WHERE id=$1 AND company_id=$2', [req.params.id, req.user.company_id]);
    res.json({ message: 'Сотрудник заблокирован', id: parseInt(req.params.id) });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

module.exports = router;
