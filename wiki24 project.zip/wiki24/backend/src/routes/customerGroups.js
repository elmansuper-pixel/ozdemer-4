const express = require('express');
const router = express.Router();
const { query } = require('../config/database');
const { authenticate, requireCompany } = require('../middleware/auth');

router.use(authenticate, requireCompany);

router.get('/', async (req, res) => {
  try {
    const { type } = req.query; // 'groups' or 'tags'
    
    if (type === 'tags') {
      const { rows } = await query('SELECT * FROM customer_tags WHERE company_id=$1 ORDER BY name', [req.user.company_id]);
      return res.json({ data: rows, type: 'tags' });
    }

    const { rows } = await query(`
      SELECT cg.*,
        (SELECT COUNT(*) FROM customer_group_members WHERE group_id = cg.id) AS customers_count
      FROM customer_groups cg
      WHERE cg.company_id=$1
      ORDER BY cg.id
    `, [req.user.company_id]);

    const { rows: tags } = await query('SELECT * FROM customer_tags WHERE company_id=$1 ORDER BY name', [req.user.company_id]);

    res.json({
      groups: rows,
      tags,
      stats: { total_groups: rows.length, total_tags: tags.length }
    });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.post('/', async (req, res) => {
  try {
    const { name, bonus_percent, type } = req.body;
    if (!name) return res.status(400).json({ message: 'Название обязательно' });

    if (type === 'tag') {
      const { rows } = await query(
        'INSERT INTO customer_tags (company_id, name) VALUES ($1,$2) RETURNING *',
        [req.user.company_id, name]
      );
      return res.status(201).json(rows[0]);
    }

    const { rows } = await query(
      'INSERT INTO customer_groups (company_id, name, bonus_percent) VALUES ($1,$2,$3) RETURNING *',
      [req.user.company_id, name, parseFloat(bonus_percent)||0]
    );
    res.status(201).json(rows[0]);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.put('/:id', async (req, res) => {
  try {
    const { name, bonus_percent, status } = req.body;
    const { rows } = await query(
      'UPDATE customer_groups SET name=COALESCE($1,name), bonus_percent=COALESCE($2,bonus_percent), status=COALESCE($3,status) WHERE id=$4 AND company_id=$5 RETURNING *',
      [name, bonus_percent ? parseFloat(bonus_percent) : null, status, req.params.id, req.user.company_id]
    );
    if (!rows.length) return res.status(404).json({ message: 'Не найдено' });
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.delete('/:id', async (req, res) => {
  try {
    await query('DELETE FROM customer_groups WHERE id=$1 AND company_id=$2', [req.params.id, req.user.company_id]);
    res.json({ message: 'Удалено', id: parseInt(req.params.id) });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

module.exports = router;
