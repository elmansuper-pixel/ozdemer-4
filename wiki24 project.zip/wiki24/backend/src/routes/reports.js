const express = require('express');
const router = express.Router();
const { query } = require('../config/database');
const { authenticate, requireCompany } = require('../middleware/auth');

router.use(authenticate, requireCompany);

router.get('/sales', async (req, res) => {
  try {
    const cid = req.user.company_id;
    const { date_from, date_to, store_id, group_by = 'day' } = req.query;

    const from = date_from || new Date(Date.now() - 30*24*60*60*1000).toISOString().slice(0,10);
    const to = date_to || new Date().toISOString().slice(0,10);

    const params = [cid, from, to];
    let storeFilter = '';
    if (store_id) { storeFilter = `AND s.store_id = ${parseInt(store_id)}`; }

    const trunc = group_by === 'month' ? 'month' : group_by === 'week' ? 'week' : 'day';

    const { rows: chart } = await query(`
      SELECT
        DATE_TRUNC('${trunc}', s.created_at)::date AS period,
        COUNT(*) FILTER (WHERE s.type='sale') AS transactions,
        COALESCE(SUM(s.total) FILTER (WHERE s.type='sale'), 0) AS revenue,
        COALESCE(SUM(s.total) FILTER (WHERE s.type='refund'), 0) AS refunds,
        COALESCE(SUM(si.quantity * si.purchase_price), 0) AS cost
      FROM sales s
      LEFT JOIN sale_items si ON si.sale_id = s.id AND s.type='sale'
      JOIN stores st ON st.id = s.store_id
      WHERE st.company_id=$1 AND s.created_at >= $2 AND s.created_at < $3::date + interval '1 day' ${storeFilter}
      GROUP BY period ORDER BY period
    `, params);

    const { rows: totals } = await query(`
      SELECT
        COUNT(*) FILTER (WHERE s.type='sale') AS transactions,
        COALESCE(SUM(s.total) FILTER (WHERE s.type='sale'), 0) AS revenue,
        COALESCE(SUM(s.total) FILTER (WHERE s.type='refund'), 0) AS refunds,
        COALESCE(SUM(si.quantity * si.purchase_price), 0) AS cost,
        AVG(s.total) FILTER (WHERE s.type='sale') AS avg_check
      FROM sales s
      LEFT JOIN sale_items si ON si.sale_id = s.id
      JOIN stores st ON st.id = s.store_id
      WHERE st.company_id=$1 AND s.created_at >= $2 AND s.created_at < $3::date + interval '1 day' ${storeFilter}
    `, params);

    const { rows: topProducts } = await query(`
      SELECT
        p.id, p.name, p.article,
        SUM(si.quantity) AS qty_sold,
        SUM(si.total) AS revenue
      FROM sale_items si
      JOIN sales s ON s.id = si.sale_id
      JOIN stores st ON st.id = s.store_id
      JOIN products p ON p.id = si.product_id
      WHERE st.company_id=$1 AND s.created_at >= $2 AND s.created_at < $3::date + interval '1 day' AND s.type='sale' ${storeFilter}
      GROUP BY p.id, p.name, p.article
      ORDER BY revenue DESC LIMIT 10
    `, params);

    const { rows: byPayment } = await query(`
      SELECT
        s.payment_method,
        COUNT(*) AS count,
        SUM(s.total) AS total
      FROM sales s
      JOIN stores st ON st.id = s.store_id
      WHERE st.company_id=$1 AND s.created_at >= $2 AND s.created_at < $3::date + interval '1 day' AND s.type='sale' ${storeFilter}
      GROUP BY s.payment_method ORDER BY total DESC
    `, params);

    res.json({ chart, totals: totals[0], topProducts, byPayment });
  } catch (e) {
    console.error('reports/sales error:', e.message);
    res.status(500).json({ message: e.message });
  }
});

router.get('/warehouse', async (req, res) => {
  try {
    const cid = req.user.company_id;
    const { store_id } = req.query;

    const storeFilter = store_id ? `AND ps.store_id = ${parseInt(store_id)}` : '';

    const { rows: stockSummary } = await query(`
      SELECT
        COUNT(DISTINCT p.id) AS total_products,
        COALESCE(SUM(ps.quantity * p.purchase_price), 0) AS purchase_value,
        COALESCE(SUM(ps.quantity * p.sale_price), 0) AS sale_value,
        COUNT(DISTINCT CASE WHEN ps.quantity = 0 THEN p.id END) AS zero_stock,
        COUNT(DISTINCT CASE WHEN ps.quantity > 0 AND ps.quantity <= 5 THEN p.id END) AS low_stock
      FROM products p
      LEFT JOIN product_stock ps ON ps.product_id = p.id ${storeFilter}
      WHERE p.company_id=$1 AND p.is_deleted=false AND p.parent_id IS NULL
    `, [cid]);

    res.json({ stockSummary: stockSummary[0] });
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
});

module.exports = router;
