const express = require('express');
const router = express.Router();
const {
  getProducts, getProduct, createProduct, updateProduct, deleteProduct, updateStock, searchProducts
} = require('../controllers/productsController');
const { authenticate, requireCompany } = require('../middleware/auth');
const upload = require('../middleware/upload');

router.use(authenticate, requireCompany);

router.get('/search', searchProducts);
router.get('/', getProducts);
router.get('/:id', getProduct);
router.post('/', createProduct);
router.put('/:id', updateProduct);
router.delete('/:id', deleteProduct);
router.put('/:id/stock', updateStock);

module.exports = router;
