const express = require('express');
const router = express.Router();
const { query } = require('../config/database');
const { authenticate, requireCompany } = require('../middleware/auth');

router.use(authenticate, requireCompany);

router.get('/', async (req, res) => {
  try {
    const { search } = req.query;
    const params = [req.user.company_id];
    let cond = ['company_id = $1'];
    if (search) { cond.push('name ILIKE $2'); params.push(`%${search}%`); }
    const { rows } = await query(`SELECT * FROM brands WHERE ${cond.join(' AND ')} ORDER BY name`, params);
    res.json({ data: rows });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.post('/', async (req, res) => {
  try {
    const { name, slug, description } = req.body;
    if (!name) return res.status(400).json({ message: 'Название обязательно' });
    const { rows } = await query(
      'INSERT INTO brands (company_id, name, slug, description) VALUES ($1,$2,$3,$4) RETURNING *',
      [req.user.company_id, name, slug || name.toLowerCase().replace(/\s+/g, '-'), description || null]
    );
    res.status(201).json(rows[0]);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.put('/:id', async (req, res) => {
  try {
    const { name, slug, description } = req.body;
    const { rows } = await query(
      'UPDATE brands SET name=COALESCE($1,name), slug=$2, description=$3 WHERE id=$4 AND company_id=$5 RETURNING *',
      [name, slug || null, description || null, req.params.id, req.user.company_id]
    );
    if (!rows.length) return res.status(404).json({ message: 'Не найдено' });
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.delete('/:id', async (req, res) => {
  try {
    await query('DELETE FROM brands WHERE id=$1 AND company_id=$2', [req.params.id, req.user.company_id]);
    res.json({ message: 'Удалено', id: parseInt(req.params.id) });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

module.exports = router;
