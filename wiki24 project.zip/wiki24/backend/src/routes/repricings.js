const express = require('express');
const router = express.Router();
const { query, getClient } = require('../config/database');
const { authenticate, requireCompany } = require('../middleware/auth');

router.use(authenticate, requireCompany);

router.get('/', async (req, res) => {
  try {
    const { search, store_id } = req.query;
    const params = [req.user.company_id];
    let cond = ['r.company_id = $1'];
    let idx = 2;
    if (search) { cond.push(`r.repricing_number ILIKE $${idx}`); params.push(`%${search}%`); idx++; }
    if (store_id) { cond.push(`r.store_id = $${idx}`); params.push(parseInt(store_id)); idx++; }

    const { rows } = await query(
      `SELECT r.*, st.name AS store_name FROM repricings r JOIN stores st ON st.id = r.store_id WHERE ${cond.join(' AND ')} ORDER BY r.created_at DESC`,
      params
    );
    res.json({ data: rows });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.post('/', async (req, res) => {
  const client = await getClient();
  try {
    await client.query('BEGIN');
    const cid = req.user.company_id;
    const { store_id, items, type, note, name } = req.body;
    if (!store_id || !items?.length) return res.status(400).json({ message: 'Магазин и товары обязательны' });

    const { rows: lastNum } = await client.query("SELECT repricing_number FROM repricings WHERE company_id=$1 ORDER BY id DESC LIMIT 1", [cid]);
    let seqNum = 1;
    if (lastNum.length > 0) {
      const parts = lastNum[0].repricing_number.split('-');
      seqNum = parseInt(parts[parts.length-1]) + 1;
    }
    const num = `ЦЕН-${String(seqNum).padStart(4,'0')}`;

    const { rows: rp } = await client.query(
      'INSERT INTO repricings (company_id, store_id, repricing_number, name, type, note, total_qty, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *',
      [cid, store_id, num, name || `Быстрая переоценка: ${new Date().toLocaleDateString('ru-RU')}`, type||'fixed', note||null, items.length, req.user.id]
    );

    for (const item of items) {
      const { rows: prod } = await client.query('SELECT name, sale_price FROM products WHERE id=$1', [item.product_id]);
      const oldPrice = parseFloat(prod[0]?.sale_price || 0);
      const newPrice = parseFloat(item.new_price);

      await client.query(
        'INSERT INTO repricing_items (repricing_id, product_id, product_name, old_price, new_price) VALUES ($1,$2,$3,$4,$5)',
        [rp[0].id, item.product_id, prod[0]?.name||'', oldPrice, newPrice]
      );
      await client.query('UPDATE products SET sale_price=$1, updated_at=NOW() WHERE id=$2', [newPrice, item.product_id]);
    }

    await client.query('COMMIT');
    res.status(201).json(rp[0]);
  } catch (e) {
    await client.query('ROLLBACK');
    res.status(500).json({ message: e.message });
  } finally { client.release(); }
});

module.exports = router;
