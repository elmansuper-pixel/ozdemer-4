const express = require('express');
const router = express.Router();
const { query, getClient } = require('../config/database');
const { authenticate, requireCompany } = require('../middleware/auth');

router.use(authenticate, requireCompany);

router.get('/', async (req, res) => {
  try {
    const cid = req.user.company_id;
    const { page=1, limit=20, search, status } = req.query;
    const offset = (parseInt(page)-1)*parseInt(limit);
    const params = [cid];
    let cond = ['po.company_id = $1'];
    let idx = 2;
    if (search) { cond.push(`(po.order_number ILIKE $${idx} OR s.name ILIKE $${idx})`); params.push(`%${search}%`); idx++; }
    if (status) { cond.push(`po.status = $${idx}`); params.push(status); idx++; }

    const { rows: countRows } = await query(`SELECT COUNT(*) FROM purchase_orders po LEFT JOIN suppliers s ON s.id = po.supplier_id WHERE ${cond.join(' AND ')}`, params);
    const { rows } = await query(`
      SELECT po.*, s.name AS supplier_name, st.name AS store_name
      FROM purchase_orders po
      LEFT JOIN suppliers s ON s.id = po.supplier_id
      JOIN stores st ON st.id = po.store_id
      WHERE ${cond.join(' AND ')}
      ORDER BY po.created_at DESC
      LIMIT $${idx} OFFSET $${idx+1}
    `, [...params, parseInt(limit), offset]);

    res.json({
      data: rows,
      pagination: { total: parseInt(countRows[0].count), page: parseInt(page), limit: parseInt(limit) }
    });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.get('/:id', async (req, res) => {
  try {
    const { rows } = await query('SELECT po.*, s.name AS supplier_name FROM purchase_orders po LEFT JOIN suppliers s ON s.id = po.supplier_id WHERE po.id=$1 AND po.company_id=$2', [req.params.id, req.user.company_id]);
    if (!rows.length) return res.status(404).json({ message: 'Не найдено' });
    const { rows: items } = await query('SELECT * FROM purchase_order_items WHERE order_id=$1', [req.params.id]);
    res.json({ ...rows[0], items });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.post('/', async (req, res) => {
  const client = await getClient();
  try {
    await client.query('BEGIN');
    const cid = req.user.company_id;
    const { store_id, supplier_id, items, note, expected_date } = req.body;
    if (!store_id) return res.status(400).json({ message: 'Магазин обязателен' });

    const orderNum = `PO-${Date.now()}`;
    let total = 0;
    const { rows: po } = await client.query(
      'INSERT INTO purchase_orders (company_id, store_id, supplier_id, order_number, status, note, expected_date, created_by) VALUES ($1,$2,$3,$4,\'unpaid\',$5,$6,$7) RETURNING *',
      [cid, store_id, supplier_id||null, orderNum, note||null, expected_date||null, req.user.id]
    );

    for (const item of (items||[])) {
      const qty = parseFloat(item.quantity);
      const price = parseFloat(item.unit_price);
      const itemTotal = qty * price;
      total += itemTotal;
      const { rows: prod } = await client.query('SELECT name FROM products WHERE id=$1', [item.product_id]);
      await client.query(
        'INSERT INTO purchase_order_items (order_id, product_id, product_name, quantity, unit_price, total) VALUES ($1,$2,$3,$4,$5,$6)',
        [po[0].id, item.product_id, prod[0]?.name||'', qty, price, itemTotal]
      );
      // Add to stock
      await client.query(
        'INSERT INTO product_stock (product_id, store_id, quantity) VALUES ($1,$2,$3) ON CONFLICT (product_id, store_id) DO UPDATE SET quantity = product_stock.quantity + $3',
        [item.product_id, store_id, qty]
      );
    }

    await client.query('UPDATE purchase_orders SET total=$1 WHERE id=$2', [total, po[0].id]);
    await client.query('COMMIT');
    res.status(201).json({ ...po[0], total });
  } catch (e) {
    await client.query('ROLLBACK');
    res.status(500).json({ message: e.message });
  } finally { client.release(); }
});

router.put('/:id', async (req, res) => {
  try {
    const { status, paid_amount } = req.body;
    const { rows } = await query(
      'UPDATE purchase_orders SET status=COALESCE($1,status), paid_amount=COALESCE($2,paid_amount), updated_at=NOW() WHERE id=$3 AND company_id=$4 RETURNING *',
      [status, paid_amount ? parseFloat(paid_amount) : null, req.params.id, req.user.company_id]
    );
    if (!rows.length) return res.status(404).json({ message: 'Не найдено' });
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

module.exports = router;
