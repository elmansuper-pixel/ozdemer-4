const express = require('express');
const router = express.Router();
const { query } = require('../config/database');
const { authenticate, requireCompany } = require('../middleware/auth');

router.use(authenticate, requireCompany);

router.get('/', async (req, res) => {
  try {
    const cid = req.user.company_id;
    const { date_from, date_to, store_id, type, category } = req.query;
    const params = [cid];
    let cond = ['st.company_id = $1'];
    let idx = 2;

    if (date_from) { cond.push(`op.created_at >= $${idx}`); params.push(date_from); idx++; }
    if (date_to) { cond.push(`op.created_at < $${idx}::date + interval '1 day'`); params.push(date_to); idx++; }
    if (store_id) { cond.push(`op.store_id = $${idx}`); params.push(parseInt(store_id)); idx++; }
    if (type) { cond.push(`op.type = $${idx}`); params.push(type); idx++; }

    const { rows } = await query(`
      SELECT op.*, st.name AS store_name, u.first_name || ' ' || u.last_name AS user_name
      FROM cash_register_operations op
      JOIN stores st ON st.id = op.store_id
      JOIN users u ON u.id = op.user_id
      WHERE ${cond.join(' AND ')}
      ORDER BY op.created_at DESC
    `, params);

    const { rows: stats } = await query(`
      SELECT
        COALESCE(SUM(amount) FILTER (WHERE type='income'),0) AS total_income,
        COALESCE(SUM(amount) FILTER (WHERE type='expense'),0) AS total_expense
      FROM cash_register_operations op
      JOIN stores st ON st.id = op.store_id
      WHERE ${cond.join(' AND ')}
    `, params);

    res.json({ data: rows, stats: stats[0] });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.post('/', async (req, res) => {
  try {
    const { shift_id, store_id, type, amount, category, comment } = req.body;
    if (!store_id || !type || !amount) {
      return res.status(400).json({ message: 'Магазин, тип и сумма обязательны' });
    }
    const { rows } = await query(`
      INSERT INTO cash_register_operations (shift_id, store_id, user_id, type, amount, category, comment)
      VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *
    `, [shift_id || null, store_id, req.user.id, type, parseFloat(amount), category || null, comment || null]);
    res.status(201).json(rows[0]);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

module.exports = router;
