const express = require('express');
const router = express.Router();
const { query, getClient } = require('../config/database');
const { authenticate, requireCompany } = require('../middleware/auth');

router.use(authenticate, requireCompany);

router.get('/', async (req, res) => {
  try {
    const cid = req.user.company_id;
    const { page = 1, limit = 20, search, store_id } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);
    const params = [cid];
    let cond = ['i.company_id = $1'];
    let idx = 2;
    if (search) { cond.push(`i.name ILIKE $${idx}`); params.push(`%${search}%`); idx++; }
    if (store_id) { cond.push(`i.store_id = $${idx}`); params.push(parseInt(store_id)); idx++; }

    const { rows } = await query(`
      SELECT i.*, st.name AS store_name, u.first_name || ' ' || u.last_name AS created_by_name
      FROM inventories i
      JOIN stores st ON st.id = i.store_id
      LEFT JOIN users u ON u.id = i.created_by
      WHERE ${cond.join(' AND ')}
      ORDER BY i.created_at DESC
      LIMIT $${idx} OFFSET $${idx+1}
    `, [...params, parseInt(limit), offset]);

    res.json({ data: rows });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.get('/:id', async (req, res) => {
  try {
    const { rows: inv } = await query(
      'SELECT i.*, st.name AS store_name FROM inventories i JOIN stores st ON st.id = i.store_id WHERE i.id = $1 AND i.company_id = $2',
      [req.params.id, req.user.company_id]
    );
    if (!inv.length) return res.status(404).json({ message: 'Не найдено' });
    const { rows: items } = await query('SELECT * FROM inventory_items WHERE inventory_id = $1', [req.params.id]);
    res.json({ ...inv[0], items });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.post('/', async (req, res) => {
  const client = await getClient();
  try {
    await client.query('BEGIN');
    const cid = req.user.company_id;
    const { store_id, items } = req.body;
    if (!store_id) return res.status(400).json({ message: 'Магазин обязателен' });

    const name = `Инвентаризация ${new Date().toLocaleString('ru-RU')}`;
    let totalQty = 0, diffPlus = 0, diffMinus = 0, diffAmount = 0;

    const { rows: inv } = await client.query(
      'INSERT INTO inventories (company_id, store_id, name, type, status, created_by) VALUES ($1,$2,$3,\'inventory\',\'in_progress\',$4) RETURNING *',
      [cid, store_id, name, req.user.id]
    );
    const inventoryId = inv[0].id;

    if (items && items.length > 0) {
      for (const item of items) {
        const actualQty = parseFloat(item.actual_qty || 0);
        const { rows: stockRows } = await client.query(
          'SELECT quantity, p.sale_price FROM product_stock ps JOIN products p ON p.id = ps.product_id WHERE ps.product_id = $1 AND ps.store_id = $2',
          [item.product_id, store_id]
        );
        const expectedQty = stockRows.length ? parseFloat(stockRows[0].quantity) : 0;
        const unitPrice = stockRows.length ? parseFloat(stockRows[0].sale_price) : 0;
        const diff = actualQty - expectedQty;
        const dAmount = diff * unitPrice;

        totalQty += actualQty;
        if (diff > 0) diffPlus += diff;
        if (diff < 0) diffMinus += Math.abs(diff);
        diffAmount += dAmount;

        const { rows: prod } = await client.query('SELECT name FROM products WHERE id = $1', [item.product_id]);
        await client.query(
          'INSERT INTO inventory_items (inventory_id, product_id, product_name, expected_qty, actual_qty, difference, unit_price, diff_amount) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)',
          [inventoryId, item.product_id, prod[0]?.name || '', expectedQty, actualQty, diff, unitPrice, dAmount]
        );
      }

      await client.query(
        'UPDATE inventories SET total_qty=$1, diff_plus=$2, diff_minus=$3, diff_amount=$4, status=\'completed\', updated_at=NOW() WHERE id=$5',
        [totalQty, diffPlus, diffMinus, diffAmount, inventoryId]
      );
    }

    await client.query('COMMIT');
    res.status(201).json(inv[0]);
  } catch (e) {
    await client.query('ROLLBACK');
    res.status(500).json({ message: e.message });
  } finally { client.release(); }
});

module.exports = router;
