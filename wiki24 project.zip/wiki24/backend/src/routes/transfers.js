const express = require('express');
const router = express.Router();
const { query, getClient } = require('../config/database');
const { authenticate, requireCompany } = require('../middleware/auth');

router.use(authenticate, requireCompany);

router.get('/', async (req, res) => {
  try {
    const cid = req.user.company_id;
    const { page = 1, limit = 20, search } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);
    const params = [cid];
    let cond = ['t.company_id = $1'];
    if (search) { cond.push('t.transfer_number ILIKE $2'); params.push(`%${search}%`); }

    const { rows } = await query(`
      SELECT t.*, fs.name AS from_store_name, ts.name AS to_store_name
      FROM transfers t
      JOIN stores fs ON fs.id = t.from_store_id
      JOIN stores ts ON ts.id = t.to_store_id
      WHERE ${cond.join(' AND ')}
      ORDER BY t.created_at DESC
      LIMIT $${params.length+1} OFFSET $${params.length+2}
    `, [...params, parseInt(limit), offset]);

    res.json({ data: rows });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.post('/', async (req, res) => {
  const client = await getClient();
  try {
    await client.query('BEGIN');
    const cid = req.user.company_id;
    const { from_store_id, to_store_id, items, note } = req.body;
    if (!from_store_id || !to_store_id) return res.status(400).json({ message: 'Магазины обязательны' });

    const num = `${1000000 + Math.floor(Math.random() * 999999)}`;
    const { rows: tr } = await client.query(
      'INSERT INTO transfers (company_id, transfer_number, from_store_id, to_store_id, note, status, created_by) VALUES ($1,$2,$3,$4,$5,\'pending\',$6) RETURNING *',
      [cid, num, from_store_id, to_store_id, note || null, req.user.id]
    );
    const transferId = tr[0].id;
    let totalQty = 0;

    for (const item of (items || [])) {
      const qty = parseFloat(item.quantity);
      totalQty += qty;
      const { rows: prod } = await client.query('SELECT name FROM products WHERE id = $1', [item.product_id]);
      await client.query(
        'INSERT INTO transfer_items (transfer_id, product_id, product_name, qty_sent, qty_received) VALUES ($1,$2,$3,$4,0)',
        [transferId, item.product_id, prod[0]?.name || '', qty]
      );
      // Deduct from source
      await client.query(
        'UPDATE product_stock SET quantity = GREATEST(0, quantity - $1) WHERE product_id = $2 AND store_id = $3',
        [qty, item.product_id, from_store_id]
      );
    }

    await client.query('UPDATE transfers SET total_qty_sent = $1 WHERE id = $2', [totalQty, transferId]);
    await client.query('COMMIT');
    res.status(201).json(tr[0]);
  } catch (e) {
    await client.query('ROLLBACK');
    res.status(500).json({ message: e.message });
  } finally { client.release(); }
});

router.put('/:id/receive', async (req, res) => {
  const client = await getClient();
  try {
    await client.query('BEGIN');
    const { items } = req.body;
    const { rows: tr } = await client.query(
      'SELECT * FROM transfers WHERE id = $1 AND company_id = $2 AND status = \'pending\'',
      [req.params.id, req.user.company_id]
    );
    if (!tr.length) return res.status(404).json({ message: 'Трансфер не найден' });

    let totalReceived = 0;
    for (const item of (items || [])) {
      const qty = parseFloat(item.quantity);
      totalReceived += qty;
      await client.query(
        'UPDATE transfer_items SET qty_received = $1 WHERE transfer_id = $2 AND product_id = $3',
        [qty, req.params.id, item.product_id]
      );
      await client.query(
        'INSERT INTO product_stock (product_id, store_id, quantity) VALUES ($1,$2,$3) ON CONFLICT (product_id, store_id) DO UPDATE SET quantity = product_stock.quantity + $3',
        [item.product_id, tr[0].to_store_id, qty]
      );
    }

    const { rows } = await client.query(
      'UPDATE transfers SET status=\'completed\', total_qty_received=$1, updated_at=NOW() WHERE id=$2 RETURNING *',
      [totalReceived, req.params.id]
    );
    await client.query('COMMIT');
    res.json(rows[0]);
  } catch (e) {
    await client.query('ROLLBACK');
    res.status(500).json({ message: e.message });
  } finally { client.release(); }
});

module.exports = router;
