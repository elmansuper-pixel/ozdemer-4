const express = require('express');
const router = express.Router();
const { query } = require('../config/database');
const { authenticate, requireCompany } = require('../middleware/auth');

router.use(authenticate, requireCompany);

router.get('/', async (req, res) => {
  try {
    const cid = req.user.company_id;
    const { status, page=1, limit=5 } = req.query;
    const offset = (parseInt(page)-1)*parseInt(limit);
    const params = [cid];
    let cond = ['d.company_id=$1'];
    let idx = 2;

    if (status === 'overdue') { cond.push('d.due_date < NOW() AND d.status != \'paid\''); }
    else if (status === 'unpaid') { cond.push("d.status = 'unpaid'"); }
    else if (status === 'paid') { cond.push("d.status = 'paid'"); }
    else if (status === 'partial') { cond.push("d.status = 'partial'"); }

    const { rows: countRows } = await query(`SELECT COUNT(*) FROM customer_debts d WHERE ${cond.join(' AND ')}`, params);
    const { rows } = await query(`
      SELECT d.*, c.first_name||' '||COALESCE(c.last_name,'') AS customer_name, c.phone AS customer_phone
      FROM customer_debts d
      JOIN customers c ON c.id = d.customer_id
      WHERE ${cond.join(' AND ')}
      ORDER BY d.created_at DESC
      LIMIT $${idx} OFFSET $${idx+1}
    `, [...params, parseInt(limit), offset]);

    const { rows: stats } = await query(`
      SELECT
        COALESCE(SUM(amount - paid_amount),0) AS total_debt,
        COALESCE(SUM(paid_amount),0) AS total_paid,
        0 AS system_payments,
        COALESCE(SUM(CASE WHEN status='partial' THEN amount-paid_amount ELSE 0 END),0) AS remaining,
        COUNT(*) AS total_debtors,
        COUNT(*) FILTER (WHERE status='paid') AS paid_count,
        COUNT(*) FILTER (WHERE status='unpaid' OR status='partial') AS unpaid_count,
        COUNT(*) FILTER (WHERE due_date < NOW() AND status!='paid') AS overdue_count
      FROM customer_debts WHERE company_id=$1
    `, [cid]);

    res.json({
      data: rows,
      pagination: { total: parseInt(countRows[0].count), page: parseInt(page), limit: parseInt(limit) },
      stats: stats[0]
    });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.post('/', async (req, res) => {
  try {
    const { customer_id, sale_id, store_id, amount, due_date, note } = req.body;
    if (!customer_id || !amount) return res.status(400).json({ message: 'Клиент и сумма обязательны' });
    const { rows } = await query(
      'INSERT INTO customer_debts (company_id, customer_id, sale_id, store_id, cashier_id, amount, due_date, note) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *',
      [req.user.company_id, customer_id, sale_id||null, store_id||null, req.user.id, parseFloat(amount), due_date||null, note||null]
    );
    res.status(201).json(rows[0]);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.put('/:id/pay', async (req, res) => {
  try {
    const { amount } = req.body;
    const { rows: debt } = await query('SELECT * FROM customer_debts WHERE id=$1 AND company_id=$2', [req.params.id, req.user.company_id]);
    if (!debt.length) return res.status(404).json({ message: 'Долг не найден' });

    const newPaid = Math.min(parseFloat(debt[0].amount), parseFloat(debt[0].paid_amount) + parseFloat(amount));
    const newStatus = newPaid >= parseFloat(debt[0].amount) ? 'paid' : 'partial';

    const { rows } = await query(
      'UPDATE customer_debts SET paid_amount=$1, status=$2, updated_at=NOW() WHERE id=$3 RETURNING *',
      [newPaid, newStatus, req.params.id]
    );
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

module.exports = router;
