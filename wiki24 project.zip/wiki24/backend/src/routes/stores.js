const express = require('express');
const router = express.Router();
const { query } = require('../config/database');
const { authenticate, requireCompany } = require('../middleware/auth');

router.use(authenticate, requireCompany);

router.get('/', async (req, res) => {
  try {
    const { rows } = await query(
      'SELECT * FROM stores WHERE company_id = $1 AND is_archived = false ORDER BY id',
      [req.user.company_id]
    );
    res.json({ data: rows });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.get('/:id', async (req, res) => {
  try {
    const { rows } = await query(
      'SELECT * FROM stores WHERE id=$1 AND company_id=$2',
      [req.params.id, req.user.company_id]
    );
    if (!rows.length) return res.status(404).json({ message: 'Не найдено' });

    const { rows: employees } = await query(`
      SELECT u.id, u.first_name, u.last_name, u.email, u.phone, r.name AS role_name, se.is_primary
      FROM store_employees se
      JOIN users u ON u.id = se.user_id
      LEFT JOIN roles r ON r.id = se.role_id
      WHERE se.store_id = $1 AND se.status = 'active'
    `, [req.params.id]);

    const { rows: registers } = await query(
      'SELECT * FROM cash_registers WHERE store_id = $1',
      [req.params.id]
    );

    res.json({ ...rows[0], employees, registers });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.post('/', async (req, res) => {
  try {
    const { name, address, phone, schedule } = req.body;
    if (!name) return res.status(400).json({ message: 'Название обязательно' });
    const { rows } = await query(
      'INSERT INTO stores (company_id, name, address, phone, schedule) VALUES ($1,$2,$3,$4,$5) RETURNING *',
      [req.user.company_id, name, address||null, phone||null, schedule||null]
    );
    // Create stock records for existing products
    await query(`
      INSERT INTO product_stock (product_id, store_id, quantity)
      SELECT p.id, $1, 0 FROM products p WHERE p.company_id = $2 AND p.is_deleted = false
      ON CONFLICT DO NOTHING
    `, [rows[0].id, req.user.company_id]);

    res.status(201).json(rows[0]);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.put('/:id', async (req, res) => {
  try {
    const { name, address, phone, schedule, status } = req.body;
    const { rows } = await query(
      'UPDATE stores SET name=COALESCE($1,name), address=$2, phone=$3, schedule=$4, status=COALESCE($5,status), updated_at=NOW() WHERE id=$6 AND company_id=$7 RETURNING *',
      [name, address||null, phone||null, schedule||null, status, req.params.id, req.user.company_id]
    );
    if (!rows.length) return res.status(404).json({ message: 'Не найдено' });
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.post('/:id/employees', async (req, res) => {
  try {
    const { user_id, role_id } = req.body;
    await query(
      'INSERT INTO store_employees (store_id, user_id, role_id, status) VALUES ($1,$2,$3,\'active\') ON CONFLICT (store_id, user_id) DO UPDATE SET role_id=$3, status=\'active\'',
      [req.params.id, user_id, role_id||null]
    );
    res.json({ message: 'Сотрудник назначен' });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.delete('/:id/employees/:userId', async (req, res) => {
  try {
    await query('DELETE FROM store_employees WHERE store_id=$1 AND user_id=$2', [req.params.id, req.params.userId]);
    res.json({ message: 'Сотрудник откреплён' });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.post('/:id/registers', async (req, res) => {
  try {
    const { name } = req.body;
    const { rows } = await query(
      'INSERT INTO cash_registers (store_id, name) VALUES ($1,$2) RETURNING *',
      [req.params.id, name || 'Касса']
    );
    res.status(201).json(rows[0]);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

module.exports = router;
