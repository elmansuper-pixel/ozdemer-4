const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const app = express();

// ─── Middleware ────────────────────────────────────────────
app.use(cors({
  origin: process.env.CORS_ORIGIN || 'http://localhost:3000',
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Static files (uploads)
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ─── Routes ───────────────────────────────────────────────
const authRoutes       = require('./routes/auth');
const productsRoutes   = require('./routes/products');
const categoriesRoutes = require('./routes/categories');
const brandsRoutes     = require('./routes/brands');
const unitsRoutes      = require('./routes/units');
const suppliersRoutes  = require('./routes/suppliers');
const salesRoutes      = require('./routes/sales');
const customersRoutes  = require('./routes/customers');
const customerGroupsRoutes = require('./routes/customerGroups');
const shiftsRoutes     = require('./routes/shifts');
const cashOpsRoutes    = require('./routes/cashOperations');
const inventoriesRoutes = require('./routes/inventories');
const transfersRoutes  = require('./routes/transfers');
const purchasesRoutes  = require('./routes/purchases');
const writeoffsRoutes  = require('./routes/writeoffs');
const repricingsRoutes = require('./routes/repricings');
const employeesRoutes  = require('./routes/employees');
const rolesRoutes      = require('./routes/roles');
const storesRoutes     = require('./routes/stores');
const settingsRoutes   = require('./routes/settings');
const debtsRoutes      = require('./routes/debts');
const loyaltyRoutes    = require('./routes/loyalty');
const paymentMethodsRoutes = require('./routes/paymentMethods');
const profileRoutes    = require('./routes/profile');
const importsRoutes    = require('./routes/imports');
const reportsRoutes    = require('./routes/reports');

app.use('/api/auth',            authRoutes);
app.use('/api/products',        productsRoutes);
app.use('/api/categories',      categoriesRoutes);
app.use('/api/brands',          brandsRoutes);
app.use('/api/units',           unitsRoutes);
app.use('/api/suppliers',       suppliersRoutes);
app.use('/api/sales',           salesRoutes);
app.use('/api/customers',       customersRoutes);
app.use('/api/customer-groups', customerGroupsRoutes);
app.use('/api/shifts',          shiftsRoutes);
app.use('/api/cash-operations', cashOpsRoutes);
app.use('/api/inventories',     inventoriesRoutes);
app.use('/api/transfers',       transfersRoutes);
app.use('/api/purchases',       purchasesRoutes);
app.use('/api/writeoffs',       writeoffsRoutes);
app.use('/api/repricings',      repricingsRoutes);
app.use('/api/employees',       employeesRoutes);
app.use('/api/roles',           rolesRoutes);
app.use('/api/stores',          storesRoutes);
app.use('/api/settings',        settingsRoutes);
app.use('/api/debts',           debtsRoutes);
app.use('/api/loyalty',         loyaltyRoutes);
app.use('/api/payment-methods', paymentMethodsRoutes);
app.use('/api/profile',         profileRoutes);
app.use('/api/imports',         importsRoutes);
app.use('/api/reports',         reportsRoutes);

// ─── Health check ─────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    app: 'WIKI24 API',
    version: '1.0.0',
    timestamp: new Date().toISOString() 
  });
});

// ─── 404 Handler ──────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ message: `Route ${req.path} not found` });
});

// ─── Error Handler ────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('Error:', err.message);
  const status = err.status || 500;
  res.status(status).json({
    message: err.message || 'Internal Server Error',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
  });
});

// ─── Start Server ─────────────────────────────────────────
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 WIKI24 API running on http://localhost:${PORT}`);
  console.log(`📊 Environment: ${process.env.NODE_ENV || 'development'}`);
});

module.exports = app;
