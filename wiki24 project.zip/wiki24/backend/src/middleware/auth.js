const jwt = require('jsonwebtoken');
const { query } = require('../config/database');

const authenticate = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ message: 'Токен авторизации не предоставлен' });
    }

    const token = authHeader.substring(7);
    
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (err) {
      if (err.name === 'TokenExpiredError') {
        return res.status(401).json({ message: 'Токен истёк', code: 'TOKEN_EXPIRED' });
      }
      return res.status(401).json({ message: 'Неверный токен', code: 'INVALID_TOKEN' });
    }

    const { rows } = await query(
      `SELECT u.id, u.email, u.first_name, u.last_name, u.phone, u.avatar_url,
              u.role, u.theme, u.language, u.is_active, u.company_id,
              c.name AS company_name, c.base_currency, c.sales_currency
       FROM users u
       LEFT JOIN companies c ON c.id = u.company_id
       WHERE u.id = $1 AND u.is_active = true`,
      [decoded.userId]
    );

    if (rows.length === 0) {
      return res.status(401).json({ message: 'Пользователь не найден или заблокирован' });
    }

    req.user = rows[0];
    next();
  } catch (error) {
    console.error('Auth middleware error:', error.message);
    res.status(500).json({ message: 'Ошибка сервера при авторизации' });
  }
};

const requireRole = (...roles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ message: 'Не авторизован' });
    }
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ 
        message: `Доступ запрещён. Требуется роль: ${roles.join(' или ')}` 
      });
    }
    next();
  };
};

const requireCompany = (req, res, next) => {
  if (!req.user?.company_id) {
    return res.status(403).json({ message: 'Пользователь не привязан к компании' });
  }
  next();
};

module.exports = { authenticate, requireRole, requireCompany };
