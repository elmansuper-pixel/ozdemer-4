const fs = require('fs');
const path = require('path');
const { pool } = require('./database');
require('dotenv').config();

const MIGRATIONS_DIR = path.join(__dirname, '../../../database');

async function migrate(fresh = false) {
  const client = await pool.connect();
  
  try {
    console.log('🗄️  Starting database migration...');
    
    // Create migrations table if not exists
    await client.query(`
      CREATE TABLE IF NOT EXISTS _migrations (
        id SERIAL PRIMARY KEY,
        filename VARCHAR(255) UNIQUE NOT NULL,
        executed_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    if (fresh) {
      console.log('⚠️  Fresh migration — dropping all tables...');
      // For fresh migration, just run all SQL files
      await client.query(`
        DROP TABLE IF EXISTS _migrations;
        CREATE TABLE _migrations (
          id SERIAL PRIMARY KEY,
          filename VARCHAR(255) UNIQUE NOT NULL,
          executed_at TIMESTAMPTZ DEFAULT NOW()
        )
      `);
    }

    // Get executed migrations
    const { rows: executed } = await client.query(
      'SELECT filename FROM _migrations ORDER BY filename'
    );
    const executedFiles = new Set(executed.map(r => r.filename));

    // Read migration files
    const files = fs.readdirSync(MIGRATIONS_DIR)
      .filter(f => f.endsWith('.sql'))
      .sort();

    for (const file of files) {
      if (!fresh && executedFiles.has(file)) {
        console.log(`  ⏭️  Skipping ${file} (already executed)`);
        continue;
      }

      const filePath = path.join(MIGRATIONS_DIR, file);
      const sql = fs.readFileSync(filePath, 'utf8');

      console.log(`  ▶️  Executing ${file}...`);
      
      await client.query('BEGIN');
      try {
        await client.query(sql);
        await client.query(
          'INSERT INTO _migrations (filename) VALUES ($1) ON CONFLICT (filename) DO NOTHING',
          [file]
        );
        await client.query('COMMIT');
        console.log(`  ✅ ${file} executed successfully`);
      } catch (err) {
        await client.query('ROLLBACK');
        console.error(`  ❌ Error in ${file}:`, err.message);
        throw err;
      }
    }

    console.log('✅ Migration completed successfully!');
    
    // Create default data
    await createDefaultData(client);
    
  } finally {
    client.release();
    await pool.end();
  }
}

async function createDefaultData(client) {
  try {
    // Check if default user exists
    const { rows } = await client.query(
      "SELECT id FROM users WHERE email = 'test@wiki.com'"
    );
    
    if (rows.length === 0) {
      console.log('📝 Creating default test data...');
      
      const bcrypt = require('bcryptjs');
      const hashedPassword = await bcrypt.hash('Test1234!', 12);
      
      // Create owner user
      const userResult = await client.query(`
        INSERT INTO users (email, password, first_name, last_name, phone, role)
        VALUES ('test@wiki.com', $1, 'Test', 'Owner', '+7 (700) 100-00-01', 'owner')
        RETURNING id
      `, [hashedPassword]);
      
      const userId = userResult.rows[0].id;
      
      // Create company
      const companyResult = await client.query(`
        INSERT INTO companies (name, physical_address, owner_id)
        VALUES ('Главный магазин', 'ул. Абая 150, Алматы', $1)
        RETURNING id
      `, [userId]);
      
      const companyId = companyResult.rows[0].id;
      
      // Update user with company
      await client.query(
        'UPDATE users SET company_id = $1 WHERE id = $2',
        [companyId, userId]
      );
      
      // Create main store
      const storeResult = await client.query(`
        INSERT INTO stores (company_id, name, address, status)
        VALUES ($1, 'Главный магазин', 'ул. Абая 150, Алматы', 'active')
        RETURNING id
      `, [companyId]);
      
      const storeId = storeResult.rows[0].id;
      
      // Assign employee to store
      await client.query(`
        INSERT INTO store_employees (store_id, user_id, is_primary, status)
        VALUES ($1, $2, true, 'active')
      `, [storeId, userId]);
      
      // Create subscription (Pro)
      const { rows: plans } = await client.query(
        "SELECT id FROM subscription_plans WHERE name = 'Pro'"
      );
      if (plans.length > 0) {
        await client.query(`
          INSERT INTO company_subscriptions (company_id, plan_id, status, period_start, period_end)
          VALUES ($1, $2, 'active', '2026-04-17', '2026-06-26')
        `, [companyId, plans[0].id]);
      }
      
      // Create default roles
      const roles = [
        { name: 'Владелец', description: 'Владелец компании с полным доступом ко всем функциям' },
        { name: 'Администратор', description: 'Администратор с широкими правами управления' },
        { name: 'Кассир', description: 'Кассир с ограниченным доступом к кассовым операциям' },
        { name: 'Менеджер', description: 'Менеджер с доступом к отчетам и инвентаризации' },
      ];
      
      for (const role of roles) {
        await client.query(`
          INSERT INTO roles (company_id, name, description, is_system)
          VALUES ($1, $2, $3, true)
        `, [companyId, role.name, role.description]);
      }
      
      // Create payment methods
      const paymentMethods = [
        { name: 'Наличные', icon: 'cash' },
        { name: 'Карта', icon: 'card' },
        { name: 'Kaspi', icon: 'card' },
        { name: 'Halyk Bank', icon: 'card' },
        { name: 'Перевод', icon: 'transfer' },
      ];
      
      for (let i = 0; i < paymentMethods.length; i++) {
        await client.query(`
          INSERT INTO payment_methods (company_id, name, icon, type, is_active, sort_order)
          VALUES ($1, $2, $3, 'custom', true, $4)
        `, [companyId, paymentMethods[i].name, paymentMethods[i].icon, i]);
      }
      
      // Create units of measure
      const units = [
        { name: 'Штука', abbreviation: 'шт', precision: 0 },
        { name: 'Килограмм', abbreviation: 'кг', precision: 3 },
        { name: 'Литр', abbreviation: 'л', precision: 3 },
        { name: 'Метр', abbreviation: 'м', precision: 2 },
        { name: 'Упаковка', abbreviation: 'уп', precision: 0 },
      ];
      
      for (const unit of units) {
        await client.query(`
          INSERT INTO units_of_measure (company_id, name, abbreviation, precision, type)
          VALUES ($1, $2, $3, $4, 'system')
        `, [companyId, unit.name, unit.abbreviation, unit.precision]);
      }
      
      // Create categories
      const categories = ['Одежда', 'Обувь', 'Аксессуары', 'Электроника', 'Книги', 'Спорт', 'Красота', 'Дом и сад'];
      for (const cat of categories) {
        await client.query(`
          INSERT INTO categories (company_id, name, status) VALUES ($1, $2, 'active')
        `, [companyId, cat]);
      }
      
      // Create receipt settings
      await client.query(`
        INSERT INTO receipt_settings (store_id, tape_width, show_logo, show_store_info,
          show_store_name, show_address, show_contacts, show_schedule)
        VALUES ($1, '80mm', false, true, true, true, true, false)
      `, [storeId]);
      
      // Create catalog settings
      await client.query(`
        INSERT INTO catalog_settings (company_id, sell_at_zero_stock,
          quick_discount_1, quick_discount_2, quick_discount_3, quick_discount_4)
        VALUES ($1, true, 15, 30, 50, 75)
      `, [companyId]);
      
      // Create product attributes
      const attrs = ['Название', 'Бренд', 'Фото', 'Категория', 'Цена продажи', 'Штрихкод'];
      for (let i = 0; i < attrs.length; i++) {
        const fieldType = attrs[i] === 'Фото' ? 'image' : attrs[i] === 'Цена продажи' ? 'number' : 'text';
        await client.query(`
          INSERT INTO product_attributes (company_id, name, field_type, type, is_visible, sort_order)
          VALUES ($1, $2, $3, 'system', true, $4)
        `, [companyId, attrs[i], fieldType, i]);
      }
      
      // Create loyalty program
      await client.query(`
        INSERT INTO loyalty_programs (company_id, type, is_active)
        VALUES ($1, 'discount', true)
      `, [companyId]);
      
      // Create customer group
      await client.query(`
        INSERT INTO customer_groups (company_id, name, status)
        VALUES ($1, 'группа 1', 'active')
      `, [companyId]);
      
      // Create customer tag
      await client.query(`
        INSERT INTO customer_tags (company_id, name)
        VALUES ($1, 'VIP')
      `, [companyId]);
      
      // Create brand
      await client.query(`
        INSERT INTO brands (company_id, name, slug)
        VALUES ($1, 'Jazz', 'jazz')
      `, [companyId]);
      
      // Create supplier
      await client.query(`
        INSERT INTO suppliers (company_id, name)
        VALUES ($1, 'Nike')
      `, [companyId]);
      
      // Create open cash shift
      await client.query(`
        INSERT INTO cash_shifts (
          shift_number, store_id, cashier_id, status, opening_amount, revenue, opened_at
        ) VALUES (
          'SHIFT-20260522-1', $1, $2, 'open', 50, 5980, '2026-05-22 13:36:00'
        )
      `, [storeId, userId]);
      
      console.log('✅ Default test data created successfully!');
      console.log('📧 Login: test@wiki.com');
      console.log('🔑 Password: Test1234!');
    } else {
      console.log('ℹ️  Default data already exists, skipping...');
    }
  } catch (err) {
    console.error('Error creating default data:', err.message);
  }
}

const args = process.argv.slice(2);
const isFresh = args.includes('--fresh');

migrate(isFresh).catch((err) => {
  console.error('Migration failed:', err);
  process.exit(1);
});
