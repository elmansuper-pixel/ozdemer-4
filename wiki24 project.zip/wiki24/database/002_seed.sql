-- ============================================================
-- WIKI24 — Начальные данные (seed)
-- ============================================================

-- Тарифные планы
INSERT INTO subscription_plans (name, price_monthly, stores_limit, employees_limit, customers_limit, products_limit) VALUES
('Free', 0, 1, 3, 100, 100),
('Basic', 9990, 2, 10, 1000, 1000),
('Pro', 49990, NULL, NULL, NULL, NULL);

-- Системные разрешения
INSERT INTO permissions (code, name, module) VALUES
('sales.view', 'Просмотр продаж', 'sales'),
('sales.create', 'Создание продаж', 'sales'),
('sales.refund', 'Возвраты', 'sales'),
('sales.reports', 'Отчёты по продажам', 'sales'),
('shifts.manage', 'Управление сменами', 'sales'),
('cash.operations', 'Кассовые операции', 'sales'),
('products.view', 'Просмотр товаров', 'warehouse'),
('products.create', 'Создание товаров', 'warehouse'),
('products.edit', 'Редактирование товаров', 'warehouse'),
('products.delete', 'Удаление товаров', 'warehouse'),
('inventory.manage', 'Инвентаризация', 'warehouse'),
('transfers.manage', 'Перемещения', 'warehouse'),
('purchases.manage', 'Закупки', 'warehouse'),
('writeoffs.manage', 'Списания', 'warehouse'),
('repricings.manage', 'Переоценка', 'warehouse'),
('customers.view', 'Просмотр клиентов', 'customers'),
('customers.create', 'Создание клиентов', 'customers'),
('customers.edit', 'Редактирование клиентов', 'customers'),
('debts.manage', 'Долги клиентов', 'customers'),
('employees.manage', 'Управление персоналом', 'management'),
('roles.manage', 'Управление ролями', 'management'),
('settings.view', 'Просмотр настроек', 'settings'),
('settings.edit', 'Редактирование настроек', 'settings');

-- Единицы измерения (системные, без привязки к компании)
-- (Будут добавлены при создании компании через seed)

-- Примечание: основные данные создаются через API при регистрации компании
