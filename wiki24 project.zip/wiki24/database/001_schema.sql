-- ============================================================
-- WIKI24 — Полная схема базы данных
-- PostgreSQL 14+
-- ============================================================

-- Очистка (при необходимости пересоздания)
DROP TABLE IF EXISTS cash_register_operations CASCADE;
DROP TABLE IF EXISTS cash_shift_items CASCADE;
DROP TABLE IF EXISTS cash_shifts CASCADE;
DROP TABLE IF EXISTS cash_registers CASCADE;
DROP TABLE IF EXISTS sale_items CASCADE;
DROP TABLE IF EXISTS sales CASCADE;
DROP TABLE IF EXISTS writeoff_items CASCADE;
DROP TABLE IF EXISTS writeoffs CASCADE;
DROP TABLE IF EXISTS repricing_items CASCADE;
DROP TABLE IF EXISTS repricings CASCADE;
DROP TABLE IF EXISTS transfer_items CASCADE;
DROP TABLE IF EXISTS transfers CASCADE;
DROP TABLE IF EXISTS inventory_items CASCADE;
DROP TABLE IF EXISTS inventories CASCADE;
DROP TABLE IF EXISTS purchase_order_items CASCADE;
DROP TABLE IF EXISTS purchase_orders CASCADE;
DROP TABLE IF EXISTS customer_debts CASCADE;
DROP TABLE IF EXISTS customer_group_members CASCADE;
DROP TABLE IF EXISTS customer_tags CASCADE;
DROP TABLE IF EXISTS customer_groups CASCADE;
DROP TABLE IF EXISTS loyalty_levels CASCADE;
DROP TABLE IF EXISTS loyalty_programs CASCADE;
DROP TABLE IF EXISTS customers CASCADE;
DROP TABLE IF EXISTS product_stock CASCADE;
DROP TABLE IF EXISTS product_variants CASCADE;
DROP TABLE IF EXISTS product_images CASCADE;
DROP TABLE IF EXISTS products CASCADE;
DROP TABLE IF EXISTS product_attributes CASCADE;
DROP TABLE IF EXISTS brands CASCADE;
DROP TABLE IF EXISTS categories CASCADE;
DROP TABLE IF EXISTS units_of_measure CASCADE;
DROP TABLE IF EXISTS suppliers CASCADE;
DROP TABLE IF EXISTS payment_methods CASCADE;
DROP TABLE IF EXISTS receipt_settings CASCADE;
DROP TABLE IF EXISTS catalog_settings CASCADE;
DROP TABLE IF EXISTS store_employees CASCADE;
DROP TABLE IF EXISTS stores CASCADE;
DROP TABLE IF EXISTS role_permissions CASCADE;
DROP TABLE IF EXISTS permissions CASCADE;
DROP TABLE IF EXISTS roles CASCADE;
DROP TABLE IF EXISTS subscription_plans CASCADE;
DROP TABLE IF EXISTS company_subscriptions CASCADE;
DROP TABLE IF EXISTS companies CASCADE;
DROP TABLE IF EXISTS bank_accounts CASCADE;
DROP TABLE IF EXISTS users CASCADE;
DROP TABLE IF EXISTS refresh_tokens CASCADE;

-- ============================================================
-- ПОЛЬЗОВАТЕЛИ И АУТЕНТИФИКАЦИЯ
-- ============================================================

CREATE TABLE users (
    id          SERIAL PRIMARY KEY,
    email       VARCHAR(255) UNIQUE NOT NULL,
    password    VARCHAR(255) NOT NULL,
    first_name  VARCHAR(100) NOT NULL,
    last_name   VARCHAR(100) NOT NULL DEFAULT '',
    phone       VARCHAR(30),
    avatar_url  VARCHAR(500),
    role        VARCHAR(50) NOT NULL DEFAULT 'cashier',
    theme       VARCHAR(20) NOT NULL DEFAULT 'auto',
    language    VARCHAR(10) NOT NULL DEFAULT 'ru',
    is_active   BOOLEAN NOT NULL DEFAULT true,
    company_id  INTEGER,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE refresh_tokens (
    id          SERIAL PRIMARY KEY,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token       VARCHAR(500) UNIQUE NOT NULL,
    expires_at  TIMESTAMPTZ NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- КОМПАНИИ И ПОДПИСКИ
-- ============================================================

CREATE TABLE companies (
    id                  SERIAL PRIMARY KEY,
    name                VARCHAR(255) NOT NULL DEFAULT '',
    legal_name          VARCHAR(255),
    bin_inn             VARCHAR(20),
    legal_address       TEXT,
    physical_address    VARCHAR(500),
    country             VARCHAR(100) DEFAULT 'Казахстан',
    region              VARCHAR(100),
    postal_code         VARCHAR(20),
    timezone            VARCHAR(100) DEFAULT 'Asia/Almaty',
    public_email        VARCHAR(255),
    phone               VARCHAR(30),
    subdomain           VARCHAR(100),
    base_currency       VARCHAR(10) DEFAULT 'KZT',
    sales_currency      VARCHAR(10) DEFAULT 'KZT',
    logo_url            VARCHAR(500),
    owner_id            INTEGER NOT NULL,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Добавить внешний ключ company_id в users после создания companies
ALTER TABLE users ADD CONSTRAINT fk_users_company
    FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE SET NULL;

CREATE TABLE bank_accounts (
    id          SERIAL PRIMARY KEY,
    company_id  INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    bank_name   VARCHAR(255),
    account_no  VARCHAR(50),
    bik         VARCHAR(50),
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE subscription_plans (
    id              SERIAL PRIMARY KEY,
    name            VARCHAR(100) NOT NULL,
    price_monthly   NUMERIC(12,2) NOT NULL DEFAULT 0,
    stores_limit    INTEGER DEFAULT NULL,
    employees_limit INTEGER DEFAULT NULL,
    customers_limit INTEGER DEFAULT NULL,
    products_limit  INTEGER DEFAULT NULL,
    is_active       BOOLEAN DEFAULT true,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE company_subscriptions (
    id              SERIAL PRIMARY KEY,
    company_id      INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    plan_id         INTEGER NOT NULL REFERENCES subscription_plans(id),
    status          VARCHAR(30) NOT NULL DEFAULT 'active',
    period_start    DATE NOT NULL,
    period_end      DATE NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- РОЛИ И ПРАВА ДОСТУПА
-- ============================================================

CREATE TABLE roles (
    id          SERIAL PRIMARY KEY,
    company_id  INTEGER REFERENCES companies(id) ON DELETE CASCADE,
    name        VARCHAR(100) NOT NULL,
    description TEXT,
    is_system   BOOLEAN DEFAULT false,
    is_deleted  BOOLEAN DEFAULT false,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE permissions (
    id          SERIAL PRIMARY KEY,
    code        VARCHAR(100) UNIQUE NOT NULL,
    name        VARCHAR(200) NOT NULL,
    module      VARCHAR(50),
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE role_permissions (
    role_id         INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    permission_id   INTEGER NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
    PRIMARY KEY (role_id, permission_id)
);

-- ============================================================
-- МАГАЗИНЫ
-- ============================================================

CREATE TABLE stores (
    id              SERIAL PRIMARY KEY,
    company_id      INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    name            VARCHAR(255) NOT NULL,
    address         VARCHAR(500),
    phone           VARCHAR(30),
    schedule        TEXT,
    stock_source    VARCHAR(30) DEFAULT 'local',
    status          VARCHAR(20) NOT NULL DEFAULT 'active',
    is_archived     BOOLEAN DEFAULT false,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE store_employees (
    id          SERIAL PRIMARY KEY,
    store_id    INTEGER NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role_id     INTEGER REFERENCES roles(id) ON DELETE SET NULL,
    is_primary  BOOLEAN DEFAULT false,
    status      VARCHAR(20) DEFAULT 'active',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(store_id, user_id)
);

-- ============================================================
-- НАСТРОЙКИ КАССЫ И ЧЕКА
-- ============================================================

CREATE TABLE cash_registers (
    id          SERIAL PRIMARY KEY,
    store_id    INTEGER NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
    name        VARCHAR(100) NOT NULL DEFAULT 'Касса 1',
    is_active   BOOLEAN DEFAULT true,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE payment_methods (
    id          SERIAL PRIMARY KEY,
    company_id  INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    name        VARCHAR(100) NOT NULL,
    icon        VARCHAR(50) DEFAULT 'card',
    type        VARCHAR(30) DEFAULT 'custom',
    is_active   BOOLEAN DEFAULT true,
    sort_order  INTEGER DEFAULT 0,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE receipt_settings (
    id                      SERIAL PRIMARY KEY,
    store_id                INTEGER NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
    tape_width              VARCHAR(10) DEFAULT '80mm',
    show_logo               BOOLEAN DEFAULT false,
    show_store_info         BOOLEAN DEFAULT true,
    show_store_name         BOOLEAN DEFAULT true,
    show_address            BOOLEAN DEFAULT true,
    show_contacts           BOOLEAN DEFAULT true,
    show_schedule           BOOLEAN DEFAULT false,
    footer_text             TEXT DEFAULT 'СПАСИБО ЗА ПОКУПКУ!',
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(store_id)
);

-- ============================================================
-- СПРАВОЧНИКИ (каталог)
-- ============================================================

CREATE TABLE catalog_settings (
    id                          SERIAL PRIMARY KEY,
    company_id                  INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    wholesale_price_enabled     BOOLEAN DEFAULT false,
    low_stock_warning           BOOLEAN DEFAULT false,
    quick_add_enabled           BOOLEAN DEFAULT false,
    negative_margin_allowed     BOOLEAN DEFAULT false,
    free_price_enabled          BOOLEAN DEFAULT false,
    sell_at_zero_stock          BOOLEAN DEFAULT true,
    quick_discount_1            INTEGER DEFAULT 10,
    quick_discount_2            INTEGER DEFAULT 20,
    quick_discount_3            INTEGER DEFAULT 30,
    quick_discount_4            INTEGER DEFAULT 50,
    card_fields                 JSONB DEFAULT '[]',
    updated_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(company_id)
);

CREATE TABLE categories (
    id              SERIAL PRIMARY KEY,
    company_id      INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    name            VARCHAR(255) NOT NULL,
    parent_id       INTEGER REFERENCES categories(id) ON DELETE SET NULL,
    status          VARCHAR(20) DEFAULT 'active',
    sort_order      INTEGER DEFAULT 0,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE brands (
    id          SERIAL PRIMARY KEY,
    company_id  INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    name        VARCHAR(255) NOT NULL,
    slug        VARCHAR(255),
    description TEXT,
    logo_url    VARCHAR(500),
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE units_of_measure (
    id          SERIAL PRIMARY KEY,
    company_id  INTEGER REFERENCES companies(id) ON DELETE CASCADE,
    name        VARCHAR(100) NOT NULL,
    abbreviation VARCHAR(20) NOT NULL,
    precision   INTEGER DEFAULT 0,
    type        VARCHAR(20) DEFAULT 'system',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE product_attributes (
    id          SERIAL PRIMARY KEY,
    company_id  INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    name        VARCHAR(100) NOT NULL,
    field_type  VARCHAR(30) DEFAULT 'text',
    type        VARCHAR(20) DEFAULT 'system',
    is_visible  BOOLEAN DEFAULT true,
    sort_order  INTEGER DEFAULT 0,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- ТОВАРЫ
-- ============================================================

CREATE TABLE products (
    id              SERIAL PRIMARY KEY,
    company_id      INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    article         VARCHAR(100),
    name            VARCHAR(500) NOT NULL,
    barcode         VARCHAR(200),
    category_id     INTEGER REFERENCES categories(id) ON DELETE SET NULL,
    brand_id        INTEGER REFERENCES brands(id) ON DELETE SET NULL,
    unit_id         INTEGER REFERENCES units_of_measure(id) ON DELETE SET NULL,
    purchase_price  NUMERIC(15,2) DEFAULT 0,
    sale_price      NUMERIC(15,2) DEFAULT 0,
    wholesale_price NUMERIC(15,2) DEFAULT 0,
    description     TEXT,
    is_variant      BOOLEAN DEFAULT false,
    parent_id       INTEGER REFERENCES products(id) ON DELETE CASCADE,
    status          VARCHAR(20) DEFAULT 'active',
    is_deleted      BOOLEAN DEFAULT false,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_products_company ON products(company_id);
CREATE INDEX idx_products_barcode ON products(barcode);
CREATE INDEX idx_products_article ON products(article);
CREATE INDEX idx_products_name ON products USING gin(to_tsvector('russian', name));

CREATE TABLE product_images (
    id          SERIAL PRIMARY KEY,
    product_id  INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    url         VARCHAR(500) NOT NULL,
    is_primary  BOOLEAN DEFAULT false,
    sort_order  INTEGER DEFAULT 0,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE product_stock (
    id          SERIAL PRIMARY KEY,
    product_id  INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    store_id    INTEGER NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
    quantity    NUMERIC(15,3) DEFAULT 0,
    low_stock_threshold NUMERIC(15,3) DEFAULT 5,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(product_id, store_id)
);

CREATE TABLE product_variants (
    id              SERIAL PRIMARY KEY,
    product_id      INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    attribute_name  VARCHAR(100) NOT NULL,
    attribute_value VARCHAR(200) NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- ПОСТАВЩИКИ
-- ============================================================

CREATE TABLE suppliers (
    id          SERIAL PRIMARY KEY,
    company_id  INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    name        VARCHAR(255) NOT NULL,
    phone       VARCHAR(30),
    email       VARCHAR(255),
    address     TEXT,
    balance     NUMERIC(15,2) DEFAULT 0,
    is_archived BOOLEAN DEFAULT false,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- КАССОВЫЕ СМЕНЫ И ОПЕРАЦИИ
-- ============================================================

CREATE TABLE cash_shifts (
    id              SERIAL PRIMARY KEY,
    shift_number    VARCHAR(50) UNIQUE NOT NULL,
    store_id        INTEGER NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
    cashier_id      INTEGER NOT NULL REFERENCES users(id),
    register_id     INTEGER REFERENCES cash_registers(id),
    status          VARCHAR(20) NOT NULL DEFAULT 'open',
    opening_amount  NUMERIC(15,2) DEFAULT 0,
    closing_amount  NUMERIC(15,2),
    expected_amount NUMERIC(15,2),
    discrepancy     NUMERIC(15,2) DEFAULT 0,
    revenue         NUMERIC(15,2) DEFAULT 0,
    opened_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    closed_at       TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE cash_register_operations (
    id              SERIAL PRIMARY KEY,
    shift_id        INTEGER NOT NULL REFERENCES cash_shifts(id) ON DELETE CASCADE,
    store_id        INTEGER NOT NULL REFERENCES stores(id),
    user_id         INTEGER NOT NULL REFERENCES users(id),
    type            VARCHAR(20) NOT NULL,
    amount          NUMERIC(15,2) NOT NULL,
    category        VARCHAR(100),
    comment         TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- ПРОДАЖИ / ТРАНЗАКЦИИ
-- ============================================================

CREATE TABLE sales (
    id              SERIAL PRIMARY KEY,
    transaction_no  VARCHAR(100) UNIQUE NOT NULL,
    store_id        INTEGER NOT NULL REFERENCES stores(id),
    shift_id        INTEGER REFERENCES cash_shifts(id),
    cashier_id      INTEGER NOT NULL REFERENCES users(id),
    customer_id     INTEGER REFERENCES customers(id) ON DELETE SET NULL,
    type            VARCHAR(20) NOT NULL DEFAULT 'sale',
    status          VARCHAR(20) NOT NULL DEFAULT 'completed',
    subtotal        NUMERIC(15,2) NOT NULL DEFAULT 0,
    discount_amount NUMERIC(15,2) DEFAULT 0,
    discount_type   VARCHAR(20) DEFAULT 'percent',
    discount_value  NUMERIC(10,2) DEFAULT 0,
    total           NUMERIC(15,2) NOT NULL DEFAULT 0,
    payment_method  VARCHAR(50),
    payment_data    JSONB DEFAULT '{}',
    note            TEXT,
    is_draft        BOOLEAN DEFAULT false,
    original_sale_id INTEGER REFERENCES sales(id) ON DELETE SET NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_sales_store ON sales(store_id);
CREATE INDEX idx_sales_created ON sales(created_at);
CREATE INDEX idx_sales_transaction ON sales(transaction_no);
CREATE INDEX idx_sales_customer ON sales(customer_id);

-- Нужно создать таблицу customers раньше sales, добавим ссылку позже
-- Для PostgreSQL это решается через ALTER TABLE

CREATE TABLE sale_items (
    id              SERIAL PRIMARY KEY,
    sale_id         INTEGER NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
    product_id      INTEGER NOT NULL REFERENCES products(id),
    product_name    VARCHAR(500) NOT NULL,
    article         VARCHAR(100),
    quantity        NUMERIC(15,3) NOT NULL,
    unit_price      NUMERIC(15,2) NOT NULL,
    discount_amount NUMERIC(15,2) DEFAULT 0,
    total           NUMERIC(15,2) NOT NULL,
    purchase_price  NUMERIC(15,2) DEFAULT 0,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- КЛИЕНТЫ
-- ============================================================

CREATE TABLE customers (
    id              SERIAL PRIMARY KEY,
    company_id      INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    first_name      VARCHAR(100) NOT NULL,
    last_name       VARCHAR(100),
    phone           VARCHAR(30),
    email           VARCHAR(255),
    birthday        DATE,
    gender          VARCHAR(10),
    address         TEXT,
    discount_percent NUMERIC(5,2) DEFAULT 0,
    bonus_balance   NUMERIC(15,2) DEFAULT 0,
    total_spent     NUMERIC(15,2) DEFAULT 0,
    last_purchase_at TIMESTAMPTZ,
    is_active       BOOLEAN DEFAULT true,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_customers_company ON customers(company_id);
CREATE INDEX idx_customers_phone ON customers(phone);

-- Восстановить FK в sales
ALTER TABLE sales ADD CONSTRAINT fk_sales_customer
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL;

CREATE TABLE customer_groups (
    id          SERIAL PRIMARY KEY,
    company_id  INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    name        VARCHAR(255) NOT NULL,
    bonus_percent NUMERIC(5,2) DEFAULT 0,
    status      VARCHAR(20) DEFAULT 'active',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE customer_group_members (
    customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    group_id    INTEGER NOT NULL REFERENCES customer_groups(id) ON DELETE CASCADE,
    PRIMARY KEY (customer_id, group_id)
);

CREATE TABLE customer_tags (
    id          SERIAL PRIMARY KEY,
    company_id  INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    name        VARCHAR(100) NOT NULL,
    color       VARCHAR(20) DEFAULT '#E8763A',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE customer_debts (
    id              SERIAL PRIMARY KEY,
    company_id      INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    customer_id     INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    sale_id         INTEGER REFERENCES sales(id) ON DELETE SET NULL,
    store_id        INTEGER REFERENCES stores(id),
    cashier_id      INTEGER REFERENCES users(id),
    amount          NUMERIC(15,2) NOT NULL,
    paid_amount     NUMERIC(15,2) DEFAULT 0,
    status          VARCHAR(30) DEFAULT 'unpaid',
    due_date        DATE,
    note            TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- ПРОГРАММА ЛОЯЛЬНОСТИ
-- ============================================================

CREATE TABLE loyalty_programs (
    id          SERIAL PRIMARY KEY,
    company_id  INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    type        VARCHAR(30) DEFAULT 'discount',
    is_active   BOOLEAN DEFAULT true,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(company_id)
);

CREATE TABLE loyalty_levels (
    id              SERIAL PRIMARY KEY,
    program_id      INTEGER NOT NULL REFERENCES loyalty_programs(id) ON DELETE CASCADE,
    name            VARCHAR(100) NOT NULL,
    min_amount      NUMERIC(15,2) DEFAULT 0,
    discount_percent NUMERIC(5,2) DEFAULT 0,
    bonus_percent   NUMERIC(5,2) DEFAULT 0,
    sort_order      INTEGER DEFAULT 0,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- ЗАКУПКИ (ЗАКАЗЫ ПОСТАВЩИКОВ)
-- ============================================================

CREATE TABLE purchase_orders (
    id              SERIAL PRIMARY KEY,
    company_id      INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    store_id        INTEGER NOT NULL REFERENCES stores(id),
    supplier_id     INTEGER REFERENCES suppliers(id) ON DELETE SET NULL,
    order_number    VARCHAR(100) UNIQUE NOT NULL,
    status          VARCHAR(30) DEFAULT 'unpaid',
    total           NUMERIC(15,2) DEFAULT 0,
    paid_amount     NUMERIC(15,2) DEFAULT 0,
    note            TEXT,
    expected_date   DATE,
    created_by      INTEGER REFERENCES users(id),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE purchase_order_items (
    id              SERIAL PRIMARY KEY,
    order_id        INTEGER NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
    product_id      INTEGER NOT NULL REFERENCES products(id),
    product_name    VARCHAR(500) NOT NULL,
    quantity        NUMERIC(15,3) NOT NULL,
    unit_price      NUMERIC(15,2) NOT NULL,
    total           NUMERIC(15,2) NOT NULL,
    received_qty    NUMERIC(15,3) DEFAULT 0,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- ИНВЕНТАРИЗАЦИЯ (РЕВИЗИЯ)
-- ============================================================

CREATE TABLE inventories (
    id              SERIAL PRIMARY KEY,
    company_id      INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    store_id        INTEGER NOT NULL REFERENCES stores(id),
    name            VARCHAR(255) NOT NULL,
    type            VARCHAR(30) DEFAULT 'inventory',
    status          VARCHAR(20) DEFAULT 'in_progress',
    total_qty       NUMERIC(15,3) DEFAULT 0,
    diff_plus       NUMERIC(15,3) DEFAULT 0,
    diff_minus      NUMERIC(15,3) DEFAULT 0,
    diff_amount     NUMERIC(15,2) DEFAULT 0,
    created_by      INTEGER REFERENCES users(id),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE inventory_items (
    id                  SERIAL PRIMARY KEY,
    inventory_id        INTEGER NOT NULL REFERENCES inventories(id) ON DELETE CASCADE,
    product_id          INTEGER NOT NULL REFERENCES products(id),
    product_name        VARCHAR(500) NOT NULL,
    expected_qty        NUMERIC(15,3) DEFAULT 0,
    actual_qty          NUMERIC(15,3) DEFAULT 0,
    difference          NUMERIC(15,3) DEFAULT 0,
    unit_price          NUMERIC(15,2) DEFAULT 0,
    diff_amount         NUMERIC(15,2) DEFAULT 0,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- ПЕРЕМЕЩЕНИЯ (ТРАНСФЕР)
-- ============================================================

CREATE TABLE transfers (
    id              SERIAL PRIMARY KEY,
    company_id      INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    transfer_number VARCHAR(100) UNIQUE NOT NULL,
    from_store_id   INTEGER NOT NULL REFERENCES stores(id),
    to_store_id     INTEGER NOT NULL REFERENCES stores(id),
    status          VARCHAR(20) DEFAULT 'pending',
    total_qty_sent  NUMERIC(15,3) DEFAULT 0,
    total_qty_received NUMERIC(15,3) DEFAULT 0,
    note            TEXT,
    created_by      INTEGER REFERENCES users(id),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE transfer_items (
    id              SERIAL PRIMARY KEY,
    transfer_id     INTEGER NOT NULL REFERENCES transfers(id) ON DELETE CASCADE,
    product_id      INTEGER NOT NULL REFERENCES products(id),
    product_name    VARCHAR(500) NOT NULL,
    qty_sent        NUMERIC(15,3) NOT NULL,
    qty_received    NUMERIC(15,3) DEFAULT 0,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- ПЕРЕОЦЕНКА
-- ============================================================

CREATE TABLE repricings (
    id              SERIAL PRIMARY KEY,
    company_id      INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    store_id        INTEGER NOT NULL REFERENCES stores(id),
    repricing_number VARCHAR(100) UNIQUE NOT NULL,
    name            VARCHAR(255),
    type            VARCHAR(30) DEFAULT 'fixed',
    status          VARCHAR(20) DEFAULT 'completed',
    total_qty       INTEGER DEFAULT 0,
    note            TEXT,
    created_by      INTEGER REFERENCES users(id),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE repricing_items (
    id              SERIAL PRIMARY KEY,
    repricing_id    INTEGER NOT NULL REFERENCES repricings(id) ON DELETE CASCADE,
    product_id      INTEGER NOT NULL REFERENCES products(id),
    product_name    VARCHAR(500) NOT NULL,
    old_price       NUMERIC(15,2) NOT NULL,
    new_price       NUMERIC(15,2) NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- СПИСАНИЕ
-- ============================================================

CREATE TABLE writeoffs (
    id              SERIAL PRIMARY KEY,
    company_id      INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    store_id        INTEGER NOT NULL REFERENCES stores(id),
    writeoff_number VARCHAR(100) UNIQUE NOT NULL,
    name            VARCHAR(255),
    type            VARCHAR(50) DEFAULT 'defect',
    status          VARCHAR(20) DEFAULT 'completed',
    total_qty       NUMERIC(15,3) DEFAULT 0,
    total_amount    NUMERIC(15,2) DEFAULT 0,
    note            TEXT,
    created_by      INTEGER REFERENCES users(id),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE writeoff_items (
    id              SERIAL PRIMARY KEY,
    writeoff_id     INTEGER NOT NULL REFERENCES writeoffs(id) ON DELETE CASCADE,
    product_id      INTEGER NOT NULL REFERENCES products(id),
    product_name    VARCHAR(500) NOT NULL,
    quantity        NUMERIC(15,3) NOT NULL,
    unit_price      NUMERIC(15,2) DEFAULT 0,
    total_amount    NUMERIC(15,2) DEFAULT 0,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- ФИНАЛЬНЫЕ ИНДЕКСЫ
-- ============================================================

CREATE INDEX idx_product_stock_product ON product_stock(product_id);
CREATE INDEX idx_product_stock_store ON product_stock(store_id);
CREATE INDEX idx_sale_items_sale ON sale_items(sale_id);
CREATE INDEX idx_sale_items_product ON sale_items(product_id);
CREATE INDEX idx_customer_debts_customer ON customer_debts(customer_id);
CREATE INDEX idx_cash_shifts_store ON cash_shifts(store_id);
CREATE INDEX idx_purchase_orders_company ON purchase_orders(company_id);

-- ============================================================
-- ПРЕДСТАВЛЕНИЯ (VIEWS)
-- ============================================================

-- Сводка по складу компании
CREATE OR REPLACE VIEW v_catalog_summary AS
SELECT
    p.company_id,
    COUNT(DISTINCT p.id) AS total_products,
    SUM(COALESCE(ps.quantity, 0)) AS total_stock_units,
    SUM(COALESCE(ps.quantity, 0) * COALESCE(p.purchase_price, 0)) AS total_purchase_value,
    SUM(COALESCE(ps.quantity, 0) * COALESCE(p.sale_price, 0)) AS total_sale_value
FROM products p
LEFT JOIN product_stock ps ON ps.product_id = p.id
WHERE p.is_deleted = false
GROUP BY p.company_id;

-- Активные товары с остатком
CREATE OR REPLACE VIEW v_products_with_stock AS
SELECT
    p.*,
    c.name AS category_name,
    b.name AS brand_name,
    u.name AS unit_name,
    u.abbreviation AS unit_abbr,
    COALESCE(SUM(ps.quantity), 0) AS total_stock
FROM products p
LEFT JOIN categories c ON c.id = p.category_id
LEFT JOIN brands b ON b.id = p.brand_id
LEFT JOIN units_of_measure u ON u.id = p.unit_id
LEFT JOIN product_stock ps ON ps.product_id = p.id
WHERE p.is_deleted = false
GROUP BY p.id, c.name, b.name, u.name, u.abbreviation;
